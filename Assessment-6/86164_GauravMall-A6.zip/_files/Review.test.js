import React from 'react';
import { shallow } from  'enzyme';
import Review from './Review';

describe('<Review />', () => {
	const mockProps = {
		item: {
			author: "gmall@sapient.com",
			body: "Review comments by gaurav",
			stars: 2,
		}
	};
	const wrapper = shallow(<Review {...mockProps} />);

	test('should render review body', () => {
		const para = wrapper.find('p');
		expect(para.text()).toBe(mockProps.item.body);
	});

	test('should render expected stars', () => {
		const star = wrapper.find('.fa-star');
		expect(star.length).toBe(mockProps.item.stars);
	});

	test('should render author as expected', () => {
		const author = wrapper.find('.author');
		expect(author.text()).toBe(mockProps.item.author);
	});
});
