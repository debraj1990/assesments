



export const LOAD_PRODUCTS = "LOAD_PRODUCTS"
export const LOAD_REVIEWS = "LOAD_REVIEWS"
export const ADD_NEW_REVIEW = "ADD_NEW_REVIEW"
export const BUY = "BUY"
export const CHECKOUT = "CHECKOUT"
