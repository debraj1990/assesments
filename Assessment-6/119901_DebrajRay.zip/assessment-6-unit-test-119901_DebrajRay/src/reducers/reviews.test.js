import { LOAD_REVIEWS, ADD_NEW_REVIEW } from '../constant'
import {reviewsReducer} from './reviews';

const mockData = {
    productId: "pID1",
    reviews: [{
        author: "debraj.ray@publicissapient.com",
        body: "review body",
        id: "reviewID1",
        productId: "productID1",
        stars: 3
    }],
    type: LOAD_REVIEWS
}

const mockDataNew = {
    productId: "pID2",
    review:{
        author: "dray@sapient.com",
        body: "review body",
        id: "reviewID2",
        productId: "productID2",
        stars: 5
    },
    type: ADD_NEW_REVIEW
}

describe('Review Reducer', () => {
    test('validating reviewReducer for LOAD_REVIEWS', () => {
        expect(
            reviewsReducer(
                {},
                mockData
            )
        ).toEqual({ [mockData.productId]: mockData.reviews });
    });
    test('validating reviewReducer for ADD_NEW_REVIEW', () => {
        expect(
            reviewsReducer(
                {},
                mockDataNew
            )
        ).toEqual({[mockDataNew.productId]: [mockDataNew.review] });
    });
});