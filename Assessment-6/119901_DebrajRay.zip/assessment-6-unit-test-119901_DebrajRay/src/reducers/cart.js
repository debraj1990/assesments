import { BUY } from "../constant";



export default function cartReducer( cart = {}, action ){
    console.log("--cart reducer--");
    
    switch (action.type) {
        case BUY:
                let {item,qty} = action;
                let {id} = item;
                //let {cart} = state;
                //  let {name,price,id,quantity} = item; 
                //  let { cart } = this.state;
                let obj = cart[ id ] ? cart [ id ] : item;
                obj.qty = obj.qty ? obj.qty : 0;
                obj.qty = parseInt( obj.qty ) + parseInt(qty);
                // cart[id].quantity = parseInt( cart[id].quantity )  + parseInt( qty );
                // this.setState(
                // {cart}
                // )  
                return Object.assign({},cart, {[id]:obj});
    
        default:
            return cart;
    }
}