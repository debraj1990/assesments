
let ProductData = [
    {
      id: 111,
      name: 'Laptop',
      price: 198000.00,
      canBuy: true,
      image: 'images/Laptop.png',
      description: 'New Mac pro'
    },
    {
      id: 222,
      name: 'Mobile',
      price: 18000.00,
      canBuy: true,
      image: 'images/Mobile.png',
      description: 'New Mac pro'
    }
]

export default ProductData;
