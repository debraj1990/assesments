import { BUY } from "../constant";


export default function buy( item, qty ){
    return {type:BUY, item, qty}
}