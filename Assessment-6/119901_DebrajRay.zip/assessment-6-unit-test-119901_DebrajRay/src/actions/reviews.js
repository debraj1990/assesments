import { LOAD_REVIEWS, ADD_NEW_REVIEW } from "../constant";

export function loadReviews( producutId ){
    let reviews = [{}, {}]
    return { type:LOAD_REVIEWS, producutId, reviews };
}

export function addNewReview( productId, review ){
    
    return { type: ADD_NEW_REVIEW, productId, review }
}