import React, { Component } from 'react';

import Product from './Product';
import loadProducts from '../actions/products';
import store from '../store';

class ProductList extends Component {

    constructor(){
        super();
        this.state = {
            products: [],
        }
    }

    componentDidMount(){
        // fetch( 'http://localhost:8080/api/products' )
        // .then( ( response )=>response.json() )
        // .then( products => this.setState({
        //     products
        // }))
        this.unsubscribe = store.subscribe( ()=>{
            let products = store.getState().products;
            this.setState( {products} ); 
        } );

        let action = loadProducts();
        store.dispatch( action );
    }

    componentWillUnmount(){
        this.unsubscribe();
    }

    buyBtnClickHandler( data, id, qty ){            
        let updateCart = new CustomEvent('updateCart', {detail:{data,id,qty}})
        document.dispatchEvent( updateCart );
      }
    

    componentDidUpdate(){
        let {match} = this.props;        
    }

    renderProducts(){
        let { products }  = this.state;
        return products.map( ( product, index ) => {
          return (
            <div key={index} className="list-group-item">
                  <Product data={product} onBuyClick={(data,qty,id)=>this.buyBtnClickHandler(data,id,qty)}/>
                  <button onClick={e=>this.props.history.goBack()}>Go Back</button>
            </div>
          )
        } )
      }

    render() {
        return this.renderProducts();
    }
}

export default ProductList;