import React, { Component } from 'react';
import store from '../store';
import buy from '../actions/cart';

class Cartview extends Component {

    increment( item ){
        let { qty } = item;
        let action = buy( item, 1 );
        store.dispatch( action );
    }

    renderCartView(){                
        let { cart } = this.props;        
        let keys = Object.keys( cart );
        return keys.map( ( key, index )=>{
            let item = cart[key];
            
            return <tr key={index}>
                <td>{item.name}</td>
                <td>{item.price}</td>
                <td>{item.qty}</td>
                <td onClick={()=>this.increment( item )}>+</td>
            </tr>
        })
    }

    render() {
        return <table className="table">
            <thead>
              <tr>
                <th scope="col">Name</th>
                <th scope="col">Price</th>
                <th scope="col">Description</th>
              </tr>
            </thead>
            <tbody>
                {this.renderCartView()}
            </tbody>
        </table>
    }
}

export default Cartview;