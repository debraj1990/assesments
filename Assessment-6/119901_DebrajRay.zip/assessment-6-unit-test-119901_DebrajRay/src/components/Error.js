import React, { Component } from 'react';

class Error extends Component {
    render() {
        return (
            <div>
                This is error
            </div>
        );
    }
}

export default Error;