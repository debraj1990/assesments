import React, { Component } from 'react';

class Review extends Component {

    renderStars( stars ){
        let starsArr = [];
        for( let i = 0; i < stars; i++ ){
            starsArr.push( <i style={{ color: "red" }} className="fa fa-star" key={i}></i>);
        }
        return starsArr;
    }

    render() {
        let { data } = this.props;        
        return (
            <div className="alert alert-info">
                <span>{this.renderStars( data.stars )}</span>
                &nbsp;&nbsp;&nbsp;
                <span className="author">{data.author}</span>
                <hr/>
                <p>{data.body}</p>
            </div>
        )
    }
}

export default Review;