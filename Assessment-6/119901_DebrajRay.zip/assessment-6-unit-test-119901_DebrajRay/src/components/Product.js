import React, { Component } from 'react';
import Review from './Review';
import ReviewForm from './ReviewForm';
import store from '../store';
import { addNewReview } from '../actions/reviews';
import buy from '../actions/cart';

class Product extends Component {
    constructor(){
        super();
        this.state = {
            currentTab:2,
            reviews:[]
        };
    }

    componentDidMount(){
        // let {data} = this.props; 
        // if( data.id ){
        //     fetch( `http://localhost:8080/api/products/${data.id}/reviews` )
        //     .then( ( response )=>response.json() )
        //     .then( reviews => this.setState({ reviews }))
        // }

        this.unsubscribe = store.subscribe( ()=>{     
            let reviews = store.getState().reviews[this.props.data.id] || [];              
            this.setState( { reviews } );
        })
    }

    componentWillUnmount(){
        this.unsubscribe();
    }

    changeTab( num ){
        this.setState( {
            currentTab:num
        } )
    }

    addNewReview( data ){
        // let url = `http://localhost:8080/api/products/${this.props.data.id}/reviews`;
        // fetch( url, {
        //     method:'POST',
        //     headers:{
        //         'Content-Type': 'application/json'
        //     },
        //     body:JSON.stringify( data )
        // } )
        // .then( response=>response.json())
        // .then( responseReview=>{
        //     let {reviews} = this.state;
        //     reviews = reviews.concat(responseReview);
        //     this.setState({
        //         reviews
        //     })
        // })


        // let { reviews } = this.state;
        // reviews.push( data );
        
        // this.setState({
        //     reviews: reviews
        // })

        let action = addNewReview( this.props.data.id, data );
        store.dispatch( action );
        
    }

    renderReview( arr ){        
        return arr.map( ( item, index ) => {
            return <Review key={index} data={ item }/>
        } )
    }

    renderTabPanel(){
        let { currentTab,reviews } = this.state;
        let retStr = "";
        
        switch( currentTab ){
            case 1: 
            retStr = <div>This is Description</div>;
            break;

            case 2: 
            retStr = <div>
                {this.renderReview( reviews )}
                {/* <Review data={reviews}/> */}
                <ReviewForm newReview={( data ) =>this.addNewReview( data )}/>
                </div>;
            break;

            case 3:
            retStr = <div>This is Specification</div>;
            break;
        }
        return retStr;
    }

    buyBtnClickHandler(){
         let {data} = this.props;
         //let {name,price,quantity=0} = data;
         let qty = this.refs.qty.value ? this.refs.qty.value : 1;        
        // onBuyClick( {name,price,quantity}, qty, data.id );
        let action = buy( data, qty);
        store.dispatch( action );
    }

    renderBuyButton(){
        let { data } = this.props;
        
        return ( data.canBuy ? 
            <div>
                <button onClick={(e)=>this.buyBtnClickHandler()} className="btn btn-sm btn-primary"> Buy </button>
                &nbsp;
                <input ref="qty" type="number" min="1" max="10" />
            </div> 
             : null );
    }

    render() {
        let { data } = this.props;
        return (
            <div>
                <div className="row">
                    <div className="col col-sm-3 col-md-3">
                        <img src={data.image} alt={data.description}/>
                    </div>
                    <div className="col-9 col-sm-9 col-md-9">
                        <h5>{data.name}</h5>
                        <h6>&#8377;{data.price}</h6>
                        {this.renderBuyButton()}
                        <ul className="nav nav-tabs">
                            <li className="nav nav-item">
                                <a href="javascript:void(0)" onClick={ () => { this.setState( { currentTab:1 } ) }} className= { this.state.currentTab == 1 ? 'nav-link active' : 'nav-link' }>Description</a>
                            </li>
                            <li className="nav nav-item">
                                <a href="javascript:void(0)" onClick={ () => this.changeTab( 2 ) } className= { this.state.currentTab == 2 ? 'nav-link active' : 'nav-link' }>Reviews</a>
                            </li>
                            <li className="nav nav-item">
                            <a href="javascript:void(0)" onClick={ this.changeTab.bind( this, 3 ) } className= { this.state.currentTab == 3 ? 'nav-link active' : 'nav-link' }>Specification</a>
                            </li>
                        </ul>
                        {this.renderTabPanel()}
                    </div>
                </div>
            </div>
        );
    }
}

export default Product;