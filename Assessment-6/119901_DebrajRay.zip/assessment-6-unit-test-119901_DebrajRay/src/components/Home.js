import React, { Component } from 'react';

class Home extends Component {

    
    componentDidUpdate(){
        let {match} = this.props;
        
    }

    render() {
        return (
            <div>
                This is home
            </div>
        );
    }
}

export default Home;