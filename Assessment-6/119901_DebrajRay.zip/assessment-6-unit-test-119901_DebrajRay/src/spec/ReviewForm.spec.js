import React from 'react';
import { shallow } from 'enzyme';
import ReviewForm, { rootClass } from './../components/ReviewForm';

describe('<ReviewForm />', () => {
	const mockProps = {
		newReview: jest.fn(),
	};

	test('component should render', () => {
        const wrapper = shallow(<ReviewForm {...mockProps} />);
        wrapper.setState({isvisible: true});        
		expect(wrapper.find('.review-form-container').exists()).toBeTruthy();
	});

	test('renderForm(), should render when component render', () => {
		jest.spyOn(ReviewForm.prototype, 'renderForm');
        const wrapper = shallow(<ReviewForm {...mockProps} />);
        wrapper.setState({isvisible: true});
		expect(wrapper.instance().renderForm.mock.calls).toHaveLength(1);
	});

	test('renderForm, should render form when state isvisible is true', () => {
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.setState({isvisible: true});
		expect(wrapper.find('.review-form-container').exists()).toBeTruthy();
		expect(wrapper.find('.toggle-btn').exists()).toBeFalsy();
	});

	test('renderForm, should render form when state isvisible is false', () => {
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.setState({isvisible: false});
		expect(wrapper.find('.review-form-container').exists()).toBeFalsy();
		expect(wrapper.find('.toggle-btn').exists()).toBeTruthy();
	});

	test('addNewReview(), should run on button click', () => {
		jest.spyOn(ReviewForm.prototype, 'cancelHandler');
        const wrapper = shallow(<ReviewForm {...mockProps} />);
        wrapper.setState({isvisible: true});
        const button = wrapper.find('button.btn-danger');
        
		button.simulate('click', { preventDefault: jest.fn()});

		expect(wrapper.instance().cancelHandler.mock.calls).toHaveLength(1);
	});
});