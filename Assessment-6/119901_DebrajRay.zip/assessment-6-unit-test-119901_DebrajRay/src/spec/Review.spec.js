import React from 'react';
import { shallow } from  'enzyme';
import Review from '../components/Review';

describe('<Review />', () => {
	const mockProps = {
		data: {
			author: "debraj.ray@publicissapient.com",
			body: "My sample review",
			stars:5,
		}
	};
	const wrapper = shallow(<Review {...mockProps} />);

	test('should render review body', () => {
		const para = wrapper.find('p');
		expect(para.text()).toBe(mockProps.data.body);
	});

	test('should render expected stars', () => {
		const star = wrapper.find('.fa-star');
		expect(star.length).toBe(mockProps.data.stars);
	});

	test('should render author as expected', () => {
		const author = wrapper.find('.author');
		expect(author.text()).toBe(mockProps.data.author);
	});
});
