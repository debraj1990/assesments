import React from 'react';
import { shallow } from 'enzyme';
import ReviewForm from '../components/ReviewForm';

describe('<ReviewForm />', () => {
	const propData = {
		onNewReview: jest.fn(),
	};

	const reviewWrapper = shallow(<ReviewForm {...propData} />);
	const reviewForm = reviewWrapper.find('.review-form');
	const reviewContainer = reviewWrapper.find('.review-form-container');
	const toggleBtn = reviewWrapper.find('.toggle-btn');

	jest.spyOn(ReviewForm.prototype, 'renderForm');
	jest.spyOn(ReviewForm.prototype, 'toggleForm');

	test('should render review form without fail', () => {
		expect(reviewForm.length).toBe(1);
	});

	test('should render review form', () => {
		let wrapper = shallow(<ReviewForm {...propData} />);
		expect(wrapper.instance().renderForm.mock.calls).toHaveLength(1);
	});

	test('should hide toggle button and render form when state isOpen is true', () => {
		reviewWrapper.setState({ isOpen: true });
		expect(reviewContainer.exists()).toBeTruthy;
		expect(toggleBtn.exists()).toBeFalsy;
	});

	test('should show toggle button and hide review form when isOpen is false', () => {
		reviewWrapper.setState({ isOpen: false });
		expect(reviewContainer.exists()).toBeFalsy;
		expect(toggleBtn.exists()).toBeTruthy;
	});

	test('Should handle form values on submit the review form', () => {
		jest.spyOn(ReviewForm.prototype, 'handleForm');
		const wrapper = shallow(<ReviewForm {...propData} />);
		const form = wrapper.find('form');
		form.simulate('submit', { preventDefault: jest.fn() });
		expect(wrapper.instance().handleForm.mock.calls.length).toBeGreaterThan(0);
	});

	test('should hide form on submit', () => {
		reviewWrapper.setState({ isOpen: false });
		const toggleBtn = reviewWrapper.find('.toggle-btn');
		toggleBtn.simulate('click');
		expect(reviewWrapper.instance().toggleForm.mock.calls.length).toBeGreaterThan(0);
	});
});