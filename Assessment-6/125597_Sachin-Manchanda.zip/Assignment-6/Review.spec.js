import React from 'react';
import { shallow } from 'enzyme';
import Review, { renderStars } from '../components/Review';

// Test for stars
describe('Render ratings', () => {
	test('Ratings should render as stars', () => {
		const stars = renderStars(5);
		expect(stars.length).toBe(5);
	});
});

// Test for reviews
describe('<Review />', () => {
	const propData = {
		item: {
			author: "shashank@gmail.com",
			body: "I am loving it",
			stars: 5,
		}
	};
	const wrapper = shallow(<Review {...propData} />);
	const reviewAuthor = wrapper.find('.author').text();
	const reviewBody = wrapper.find('p').text();
	const reviewStars = wrapper.find('.fa-star')

	test('should render author as expected', () => {
		expect(reviewAuthor).toBe(propData.item.author);
	});

	test('should render review body', () => {
		expect(reviewBody).toBe(propData.item.body);
	});

	test('should render expected stars', () => {
		expect(reviewStars.length).toBe(propData.item.stars);
	});
});


