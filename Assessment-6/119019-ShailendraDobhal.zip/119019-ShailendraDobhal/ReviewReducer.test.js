import { review } from "../reviews";
import { LOAD_REVIEWS, ADD_NEW_REVIEW } from "../../constants";

describe("review reducer", () => {
  it("should return initial state", () => {
    expect(review(undefined, {})).toEqual({});
  });

  it("should handle LOAD_REVIEWS", () => {
    const action = {
      productId: "p1",
      reviews: [
        {
          author: "Author 1",
          body: "This is a body",
          id: "id1",
          stars: 3
        }
      ],
      type: LOAD_REVIEWS
    };
    expect(review({}, action)).toEqual({
      p1: action.reviews
    });
  });

  it("should handle ADD_NEW_REVIEW", () => {
    const state = {
      p1: [
        {
          author: "Author 1",
          body: "This is a body",
          id: "id1",
          stars: 3
        }
      ]
    };

    const action = {
      productId: "p1",
      reviews: {
        author: "Author 2",
        body: "This is a body",
        id: "id2",
        stars: 3
      },
      type: ADD_NEW_REVIEW
    };

    expect(review(state, action)).toEqual({
      p1: [...state, action.reviews]
    });
  });
});
