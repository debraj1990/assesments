import React from "react";
import { shallow } from "enzyme";
import ReviewForm from "./ReviewForm";

function setup() {
  const props = {
    onNewReview: jest.fn()
  };

  const wrapper = shallow(<ReviewForm {...props} />);

  return {
    props,
    wrapper
  };
}

describe("ReviewForm", () => {
  it("toogle review form", () => {
    const { wrapper } = setup();

    wrapper.setState({ isOpen: true });
    expect(wrapper.find(".toggle-btn").exists()).toBeFalsy();
    wrapper.setState({ isOpen: false });
    expect(wrapper.exists()).toBeFalsy;
    expect(wrapper.find(".toggle-btn").exists()).toBeTruthy;
  });

  test("should render expected stars", () => {
    const { wrapper } = setup();

    const star = wrapper.find(".fa-star");
    expect(star.length).toBe(props.item.stars);
  });

  it("handle form submit", () => {
    const { wrapper } = setup();

    jest.spyOn(ReviewForm.prototype, "handleForm");
    const form = wrapper.find("form");
    form.simulate("submit", { preventDefault: jest.fn() });
    expect(wrapper.instance().handleForm.mock.calls).toHaveLength(1);
  });

  it("close form on submit", () => {
    const { wrapper } = setup();

    jest.spyOn(ReviewForm.prototype, "toggleForm");
    wrapper.setState({ isOpen: false });
    const toggleBtn = wrapper.find(".toggle-btn");
    toggleBtn.simulate("click");
    expect(wrapper.instance().toggleForm.mock.calls).toHaveLength(1);
  });
});
