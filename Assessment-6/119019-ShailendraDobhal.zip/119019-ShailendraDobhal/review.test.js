import React from "react";
import { shallow } from "enzyme";
import Review from "./Review";

describe("<Review />", () => {
  const props = {
    item: {
      author: "Author 1",
      body: "This is a review comment",
      stars: 5
    }
  };
  const wrapper = shallow(<Review {...props} />);

  test("should render body", () => {
    expect(wrapper.find("p").text()).toBe(props.item.body);
  });

  test("should render stars", () => {
    expect(wrapper.find(".fa-star").length).toBe(props.item.stars);
  });

  test("should render author", () => {
    expect(wrapper.find(".author").text()).toBe(props.item.author);
  });
});
