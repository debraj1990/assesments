import React from 'react';
import { shallow } from 'enzyme';
import renderer from 'react-test-renderer';
import ReviewForm from './ReviewForm_v2';

describe('<ReviewForm/>', () => {
	test('should render correctly in open state', () => {
		const reviewForm = renderer.create(<ReviewForm onNewReview={() => {}} />);
		const tree = reviewForm.toJSON();
		expect(tree).toMatchSnapshot();
	});

	test('should render correctly in close state', () => {
		const reviewForm = renderer.create(<ReviewForm onNewReview={() => {}} />);
		const reviewFormInstance = reviewForm.getInstance();
		reviewFormInstance.setState({
			isOpen: false,
		})
		const tree = reviewForm.toJSON();
		expect(tree).toMatchSnapshot();
	});
});

describe('Review Form Instance', () => {
	let reviewForm;
	let onNewReviewMock;
	beforeEach(() => {
		onNewReviewMock = jest.fn();
		reviewForm = shallow(<ReviewForm onNewReview={onNewReviewMock} />);
	});

	test('should disable submit button if stars are less than 3', () => {
		reviewForm.find('#stars').simulate('change', {
			target: {
				id: 'stars',
				value: 2,
			}
		});
		expect(reviewForm.find('.btn-primary').is('button[disabled=true]')).toBe(true);
	});

	test('should set isOpen state to true on toggleBtn', () => {
		reviewForm.setState({
			isOpen: false,
		});
		reviewForm.find('.toggleBtn').simulate('click');
		expect(reviewForm.state('isOpen')).toBe(true)
	});

	test('should call onNewReview prop with current state on submit', () => {
		const newState = {
			author: 'gaurav@kakkar.com',
			body:'test',
			stars: 4,

		};
		reviewForm.find('#stars').simulate('change', {
			target: {
				id: 'stars',
				value: 4,
			}
		});
		reviewForm.find('#author').simulate('change', {
			target: {
				id: 'author',
				value: 'gaurav@kakkar.com',
			}
		});
		reviewForm.find('#body').simulate('change', {
			target: {
				id: 'body',
				value: 'test',
			}
		});
		reviewForm.find('form').simulate('submit', {
			preventDefault: () => {}
		});
		expect(onNewReviewMock).toBeCalledWith(newState);
	});
})
