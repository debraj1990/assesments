

import React from 'react';
export const rootClass = 'jumbotron'

export default () => {
    return (
        <div className={rootClass}>
            <h1 className="display-4">shop-IT!</h1>
            <hr className="my-4" />
            <a className="btn btn-primary btn-lg" href="/#" role="button">Learn react</a>
        </div>
    )
}