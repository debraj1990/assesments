import { LOAD_REVIEWS, ADD_NEW_REVIEW } from '../constants'
import {reviewsReducer} from '../reducers/reviews';

describe('Review Reducer', () => {
    test('on LOAD_REVIEWS action, it should update state with new reviews', () => {
        const state = {"product_1": [{}]};
        const action = {
            type: LOAD_REVIEWS,
            productId: "product_1",
            reviews: [{}, {}]
        };
        expect(reviewsReducer(state, action).product_1.length).toBe(3);
    });

    test('on ADD_NEW_REVIEW action, it should update state with new reviews', () => {
        const state = {"product_1": [{}]};
        const action = {
            type: ADD_NEW_REVIEW,
            productId: "product_1",
            review: {}
        };
        expect(reviewsReducer(state, action).product_1.length).toBe(2);
    });
});
