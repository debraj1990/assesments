import React from 'react';
import { shallow } from 'enzyme';
import Review from '../components/Review';

describe('<Review />', () => {
	const reviewProps = {
		item: {
			author: "test@test.com",
			body: "Test comment",
			stars: 3,
		}
	};
	const wrapper = shallow(<Review {...reviewProps} />);

	test('should render stars correctly', () => {
		expect(wrapper.find('.fa-star').length).toBe(reviewProps.item.stars);
	});

	test('should render author correctly', () => {
		expect(wrapper.find('.author').text()).toBe(reviewProps.item.author);
	});

	test('should render review body correctly', () => {
		expect(wrapper.find('.body').text()).toBe(reviewProps.item.body);
	});
});
