import React from 'react';
import { shallow } from 'enzyme';
import { ProductList, rootClass } from './../../components/ProductList';

describe('<ProductList />', () => {
	const mockProps = {
		actions: {
			loadProducts: jest.fn(),
		},
		products: [
			{
				canBuy:true,
				description: "New Mac pro",
				id: 111,
				image: "images/Laptop.png",
				name: "Laptop",
				price: 198000,
			},
			{
				canBuy:true,
				description: "New Mobile pro",
				id: 1121,
				image: "images/Mobile.png",
				name: "MObile",
				price: 2900,
			}
		],
	};

	test('Component should render', () => {
		const wrapper = shallow(<ProductList  {...mockProps} />);
		expect(wrapper.find(`.${rootClass}`)).toBeTruthy();
	});

	test('renderProducts, should run when expected ', () => {
		jest.spyOn(ProductList.prototype, 'renderProducts');
		const wrapper = shallow(<ProductList  {...mockProps} />);
		expect(wrapper.instance().renderProducts.mock.calls).toHaveLength(1);
	});

	test('renderProducts, should return same produts as passed props', () => {
		const wrapper = shallow(<ProductList  {...mockProps} />);
		const products = wrapper.instance().renderProducts();
		expect(products).toHaveLength(mockProps.products.length);
	});

	test('component should render same number same number of items as passed', () => {
		const wrapper = shallow(<ProductList  {...mockProps} />);
		expect(wrapper.find('.list-group-item')).toHaveLength(mockProps.products.length);
	});

	test('loadProducts(), should trigger on component mount', () => {
		jest.useFakeTimers();
		const wrapper = shallow(<ProductList {...mockProps} />);
		jest.runOnlyPendingTimers();;
		expect(wrapper.instance().props.actions.loadProducts.mock.calls.length).toBe(1);
	});
});