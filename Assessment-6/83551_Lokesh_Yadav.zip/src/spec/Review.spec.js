import React from 'react';
import {shallow} from 'enzyme';
import Review, {renderStars} from './../components/Review';

describe('<Review />', () => {
	const mockProps = {
		item: {
			author: 'nag@gmail.com',
			body: 'sdad',
			stars: 4
		}
	};
	const wrapper = shallow(<Review {...mockProps} />);

	test('should render review body', () => {
		const para = wrapper.find('p');
		expect(para.text()).toBe(mockProps.item.body);
	});

	test('should render expected stars', () => {
		const star = wrapper.find('.fa-star');
		expect(star.length).toBe(mockProps.item.stars);
	});

	test('should render author as expected', () => {
		const author = wrapper.find('.author');
		expect(author.text()).toBe(mockProps.item.author);
	});
});

describe('renderStar', () => {
	test('renderStar should run as expected', () => {
		const stars = renderStars(4);
		expect(stars.length).toBe(4);
	});
});
