


import { BUY } from '../constants'


export function buy(item, qty) {
    //
    return { type: BUY, item, qty }
}