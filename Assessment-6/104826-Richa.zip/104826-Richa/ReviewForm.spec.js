import React from 'react';
import { shallow } from 'enzyme';
import ReviewForm, { rootClass } from './../../components/ReviewForm';

describe('<ReviewForm />', () => {
	const mockPropData = {
		onNewReview: jest.fn(),
	};

	test('component should render', () => {
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		expect(wrapper.find(`.${rootClass}`).exists()).toBeTruthy();
	});

	test('renderForm(), should render when component render', () => {
		jest.spyOn(ReviewForm.prototype, 'renderForm');
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		expect(wrapper.instance().renderForm.mock.calls).toHaveLength(1);
	});

	test('renderForm, should render form when state isOpen is true', () => {
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		wrapper.setState({isOpen: true});
		expect(wrapper.find('.review-form-container').exists()).toBeTruthy();
		expect(wrapper.find('.toggle-btn').exists()).toBeFalsy();
	});

	test('renderForm, should render form when state isOpen is false', () => {
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		wrapper.setState({isOpen: false});
		expect(wrapper.find('.review-form-container').exists()).toBeFalsy();
		expect(wrapper.find('.toggle-btn').exists()).toBeTruthy();
	});

	test('handleForm(), should run on form submit', () => {
		jest.spyOn(ReviewForm.prototype, 'handleForm');
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		const form = wrapper.find('form');
		form.simulate('submit', { preventDefault: jest.fn()});

		expect(wrapper.instance().handleForm.mock.calls).toHaveLength(1);
	});

	test('toggleForm(), should run on form submit', () => {
		jest.spyOn(ReviewForm.prototype, 'toggleForm');
		const wrapper = shallow(<ReviewForm {...mockPropData} />);
		wrapper.setState({ isOpen: false });
		const toggleBtn = wrapper.find('.toggle-btn');
		toggleBtn.simulate('click');
		expect(wrapper.instance().toggleForm.mock.calls).toHaveLength(1);
	});
});