import React from 'react';
import { shallow } from 'enzyme';
import { reviewsReducer } from './../../reducers/reviews';

describe('test for review reducer', () => {

  test('should return the initial state', () => {
    expect(reviewsReducer(undefined, {})).toEqual({});
  });

  test('should load existing reviews', () => {
    const loadReviews = {
      type: 'LOAD_REVIEWS',
      productId: 1,
      reviews: []
    };
    expect(reviewsReducer({}, loadReviews)).toEqual({ 1: [] });
  });

  test('should add new review', () => {
    const newReview = {
      type: 'ADD_NEW_REVIEW',
      productId: 1,
      review:
      {
        author: "rich@gmail.com",
        body: "hello",
        stars: 5,
      }
    };
    const state = { 1: [] };
    expect(reviewsReducer(state, newReview)).toEqual({
      1: [
        {
          author: "rich@gmail.com",
          body: "hello",
          stars: 5,
        }
      ]
    });

  })
});