import React from 'react';
import { shallow } from  'enzyme';
import Review, { renderStars } from './../../components/Review';

describe('<Review />', () => {
	const mockPropData = {
		item: {
			author: "rich@gmail.com",
			body: "Hello",
			stars:4,
		}
	};
	const wrapper = shallow(<Review {...mockPropData} />);

	test('should render review body', () => {
		const para = wrapper.find('p');
		expect(para.text()).toBe(mockPropData.item.body);
	});

	test('should render expected stars', () => {
		const star = wrapper.find('.fa-star');
		expect(star.length).toBe(mockPropData.item.stars);
	});

	test('should render author as expected', () => {
		const author = wrapper.find('.author');
		expect(author.text()).toBe(mockPropData.item.author);
	});
});

describe('renderStar', () => {
	test('renderStar should run as expected', () => {
		const stars = renderStars(5);
		expect(stars.length).toBe(5);
	});
});
