import React from "react";
import { shallow } from "enzyme";
import ReviewForm from "../ReviewForm_v2";

describe(__filename, () => {
  let onNewReview;
  let wrapperComponent;
  beforeEach(() => {
    onNewReview = jest.fn();
    wrapperComponent = shallow(<ReviewForm onNewReview={onNewReview} />);
  });

  test("should render ReviewForm component", () => {
    expect(wrapperComponent).toMatchSnapshot();
  });

  test("handleForm", () => {
    jest.spyOn(ReviewForm.prototype, "handleForm");
    wrapperComponent
      .find("form")
      .simulate("submit", { preventDefault: jest.fn() });
    expect(wrapperComponent.instance().handleForm.mock.calls).toHaveLength(1);
  });

  test("toggleForm", () => {
    jest.spyOn(ReviewForm.prototype, "toggleForm");
    wrapperComponent.setState({ isOpen: false });
    wrapperComponent.find(".toggleBtn").simulate("click");
    expect(wrapperComponent.instance().toggleForm.mock.calls).toHaveLength(1);
  });

  test("isOpen = true", () => {
    wrapperComponent.setState({ isOpen: true });
    expect(wrapperComponent.find(".card").exists()).toBeTruthy();
  });

  test("isOpen = false", () => {
    wrapperComponent.setState({ isOpen: false });
    expect(wrapperComponent.find(".card").exists()).toBeFalsy();
  });
});
