import React from "react";
import { shallow } from "enzyme";
import Review from "../Review";

describe(__filename, () => {
  let item;
  let wrapperComponent;
  beforeAll(() => {
    item = {
      author: "Sunil",
      body: "Dummy comment",
      stars: 5
    };
    wrapperComponent = shallow(<Review item={item} />);
  });

  test("should render Review component", () => {
    expect(wrapperComponent).toMatchSnapshot();
  });

  test("Review should have review body", () => {
    const { body } = item;
    expect(wrapperComponent.find("p").text()).toBe(body);
  });

  test("Review should have expected stars", () => {
    const { stars } = item;
    expect(wrapperComponent.find(".fa-star").length).toBe(stars);
  });

  test("Review should have author as expected", () => {
    const { author } = item;
    expect(wrapperComponent.find(".author").text()).toBe(author);
  });
});
