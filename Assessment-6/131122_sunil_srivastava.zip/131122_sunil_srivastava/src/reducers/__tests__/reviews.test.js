import { LOAD_REVIEWS, ADD_NEW_REVIEW } from "../../constants";
import { reviewsReducer } from "../reviews";

describe("Review Reducer", () => {
  test("capture LOAD_REVIEWS", () => {
    const action = {
      productId: "PDCT_001",
      reviews: [
        {
          author: "dummy author",
          body: "dummy body"
        }
      ],
      type: LOAD_REVIEWS
    };
    expect(reviewsReducer({}, action)).toEqual({
      [action.productId]: action.reviews
    });
  });

  test("capture ADD_NEW_REVIEW", () => {
    const action = {
      productId: "PDCT_001",
      reviews: [
        {
          author: "dummy author",
          body: "dummy body"
        }
      ],
      type: ADD_NEW_REVIEW
    };

    expect(reviewsReducer({}, action)).toEqual({
      [action.productId]: [action.review]
    });
  });
});
