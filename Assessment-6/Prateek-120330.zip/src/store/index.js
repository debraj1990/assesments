import { createStore, applyMiddleware } from "redux";
import rootReducer from "../reducers";
import { devToolsEnhancer } from 'redux-devtools-extension';
import thunk from "redux-thunk";
 
let initialState = {
    products:[],
    reviews:{},
    cart:{}
}

const store = createStore( rootReducer,initialState, applyMiddleware(thunk) );

export default store;