import React, { Component } from 'react';

export const rootClass = 'review-form-container';

class ReviewForm extends Component {

    constructor(){
        super();
        this.state = {
            'review-form-stars':5,
            'isvisible':false
        };
    }

    addNewReview(event){
        event.preventDefault();
        let { stars, email, review } = this.refs;
        let newReviewObj = {
            stars: stars.value,
            author: email.value,
            body: review.value
        }
        let { newReview } = this.props;
        
        if( newReview ){
            newReview( newReviewObj );
        }
        this.setState({
            isvisible: false
        })
    }

    cancelHandler(){
        this.setState({ isvisible: false });
    }

    renderPlusIcon(){
        return <button onClick={()=>{
            this.setState({
                isvisible: true
            })  
        }} className="btn btn-info toggle-btn">Click me</button>
    }

    renderForm(){
        return (
            <div className="col-8 col-sm-8 col-md-8 review-form-container">
                <div className="card card-default">
                    <div className="card-header">
                        Review Form
                    </div>
                    <div className="card-body">
                    <form>
                        <div className="form-group">
                            <label htmlFor="review-form-stars">Name</label>
                            <select value={this.state['review-form-stars']} className="form-control" id="review-form-stars" ref="stars"
                            onChange={(e)=>this.changeHandler( e )}>
                               {[1,2,3,4,5].map( ( value, index )=><option key={index}>{value}</option>)}
                            </select>
                        </div>
                        <div className="form-group">
                            <label htmlFor="review-form-email">Email</label>
                            <input className="form-control" type="email"
                             id="review-form-email" defaultValue="psinghal@123.com"
                             ref="email"/>
                        </div>
                        <div className="form-group">
                            <label htmlFor="review-form-review">Review</label>
                            <textarea className="form-control" id="review-form-review" ref="review"/>
                        </div>
                        <button onClick={(e) =>this.addNewReview(e)} className="btn btn-primary">Submit</button>
                        &nbsp;
                        <button onClick={(e)=>this.cancelHandler(e)} className="btn btn-danger">Cancel</button>
                    </form>
                    </div>
                </div>
            </div>
        )
    }

    changeHandler(e){
        let fieldId  = e.target.id;
        let fieldValue  = e.target.value;

        this.setState( {
            [fieldId]:fieldValue
        } )
    }

    render() {
        return this.state.isvisible ? this.renderForm() : this.renderPlusIcon();
    }
}

export default ReviewForm;