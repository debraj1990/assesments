import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css';
import 'font-awesome/css/font-awesome.css';
import Navbar from './components/Navbar';
import Cartview from './components/Cartview';
import { BrowserRouter as Router, Route, Link, Switch } from 'react-router-dom'
import Error from './components/Error';
import Home from './components/Home';
import ProductList from './components/ProductList';
import store from './store';

class App extends Component {
  constructor(){
    super();
    this.state = {
      cart:{},
    }

    // document.addEventListener( 'updateCart', (params)=>{   
    //   let {data,id,qty} = params.detail; 
    //   console.log(params);
      
    //   let { cart } = this.state;
    //     let obj = cart[ id ] ? cart [ id ] : data;
    //     cart[ id ] = obj;
    //     cart[id].quantity = parseInt( cart[id].quantity )  + parseInt( qty );
    //     this.setState(
    //       {cart}
    //     )     
    // } )
  }

  componentDidMount(){
    store.subscribe( ()=>{
      let {cart} = store.getState();
      this.setState({cart});
    })
  }

  renderCartView(){
    return <Cartview cart={this.state.cart}/>
  }

  render() {
    let {cart} = this.state;
    return (
        <div className="container">
            <Navbar title="Online-Shopping Prateek"/>
            <hr/>
            <div>
              <i className="fa fa-shopping-cart"></i>
              &nbsp;
              <span className="badge badge-danger">{Object.keys(cart).length}</span>
              &nbsp;
              <span>item(s) in cart</span>
            </div>
            <hr/>

            <Router>
                <div>
                    <Link to="/cart">View-Cart</Link>
                    &nbsp;&nbsp;&nbsp;
                    <Link to="/product/elec">View-elec-Products</Link>
                    &nbsp;&nbsp;&nbsp;
                    <Link to="/product/other">View-other-Products</Link>
                    &nbsp;&nbsp;&nbsp;
                    <Link to="/error">View-Orders</Link>
                    <hr/>
                    <Switch>
                    <Route path="/" exact component={Home} />
                    <Route path="/cart" render={()=> this.renderCartView() } />
                    <Route path="/product/:type" component={ProductList} />
                    <Route component={Error} />
                    </Switch>
                </div>
            </Router>
        </div>
    );
  }
}

export default App;
