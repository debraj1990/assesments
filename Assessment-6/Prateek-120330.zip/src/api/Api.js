import Axios from "axios";


export default function loadProductsAsync(){
    let url = "http://localhost:8080/api/products"
    return Axios.get( url );
}