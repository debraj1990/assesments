import { LOAD_REVIEWS, ADD_NEW_REVIEW } from "../constant";



export default function reviewsReducer( state = {}, action ){
    switch (action.type) {
        case LOAD_REVIEWS:{
            let { productId, reviews } = action;
            let existingReviews = state[ productId ] || [];
            reviews = [...existingReviews,...reviews];
            return Object.assign( {}, state, { [productId]: reviews} );
        }
        case ADD_NEW_REVIEW:{
            let { productId, review } = action;
            
            let existingReviews = state[ productId ] || []; 
                       
            review = [...existingReviews,review];
            return Object.assign( {}, state, { [productId]: review} );
        }
        default:
            return state;
    }
}