import React from 'react';
import { shallow } from 'enzyme';
import { Product, rootClass } from './../../components/Product';

describe('<Product />', () => {
	const mockProps = {
		item: {
			canBuy: true,
			description: "New Mac pro",
			id: 111,
			image: "images/Laptop.png",
			name: "Laptop",
			price: 198000,
		},
		actions: {
			addNewReview: jest.fn(),
			buy: jest.fn(),
			loadReviews: jest.fn(),
		},
		reviews:[],
	};


	test('renderTabPanel(), should run when component render', () => {
		jest.spyOn(Product.prototype, 'renderTabPanel');
		const wrapper = shallow(<Product {...mockProps} />);
		expect(wrapper.instance().renderTabPanel.mock.calls).toHaveLength(1);
	});


	test('renderBuyBtn(), should run when component render ', () => {
		jest.spyOn(Product.prototype, 'renderBuyBtn');
		const wrapper = shallow(<Product {...mockProps} />);
		expect(wrapper.instance().renderBuyBtn.mock.calls).toHaveLength(1);
	});


	test('changeTab(), should run when expected', () => {
		jest.spyOn(Product.prototype, 'changeTab');
		const wrapper = shallow(<Product {...mockProps} />);
		const navLink = wrapper.find('.reviews');
		navLink.simulate('click', {...mockProps.item});
		expect(wrapper.instance().changeTab.mock.calls).toHaveLength(1);
	});

	test('changeTab(), should run as expected', () => {
		const wrapper = shallow(<Product {...mockProps} />);
		wrapper.instance().changeTab(2);
		expect(wrapper.state().currentTab).toBe(2);
	});

	test('loadReviews(), should run when review tab is selected', () => {
		const wrapper = shallow(<Product {...mockProps} />);
		wrapper.instance().props.actions.loadReviews.mockClear();
		wrapper.instance().changeTab(3);
		expect(wrapper.instance().props.actions.loadReviews.mock.calls).toHaveLength(1);
	});

	test('handleBuy(), should run when click on Buy Button', () => {
		jest.spyOn(Product.prototype, 'handleBuy');
		const wrapper = shallow(<Product {...mockProps} />);
		const buyButton = wrapper.find('.btn-primary');
		wrapper.instance().refs = {qty: { value: 2}};
		buyButton.simulate('click');
		expect(wrapper.instance().handleBuy.mock.calls).toHaveLength(1);
	});

	test('renderReviews(), should run when expected', () => {
		jest.spyOn(Product.prototype, 'renderReviews');
		const wrapper = shallow(<Product {...mockProps} />);
		wrapper.instance().renderReviews.mockClear();
		wrapper.setState({currentTab: 3});
		expect(wrapper.instance().renderReviews.mock.calls).toHaveLength(1);
	});

	test('addNewReview(), should run when expected', () => {
		jest.spyOn(Product.prototype, 'addNewReview');
		const wrapper = shallow(<Product {...mockProps} />);
		wrapper.setState({currentTab: 3});
		const reviewForm = wrapper.find('ReviewForm');
		reviewForm.props().onNewReview({});
		expect(wrapper.instance().addNewReview.mock.calls).toHaveLength(1);
	});
});
