# written test for

- ReviewForm_v2.test.js (component)
- Review.test.js (component)
- reviews.test.js (reducer)

#Please Note: test files are lying with the original files (with .test.js extensions)