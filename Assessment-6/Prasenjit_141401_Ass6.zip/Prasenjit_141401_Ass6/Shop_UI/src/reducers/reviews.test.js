import { LOAD_REVIEWS, ADD_NEW_REVIEW } from '../constants'
import {reviewsReducer} from './reviews';

const mockData = {
    productId: "productID1",
    reviews: [{
        author: "gaurav@gmail.com",
        body: "body text gaurav",
        id: "SomeOtherID1",
        productId: "productID1",
        stars: 3
    }],
    type: "LOAD_REVIEWS"
}

const mockDataNew = {
    productId: "productID2",
    review:{
        author: "gyan@gmail.com",
        body: "body for gyan2",
        id: "SomeOtherID2",
        productId: "productID2",
        stars: 5
    },
    type: "ADD_NEW_REVIEW"
}

describe('Review Reducer', () => {
    test('validating reviewReducer for LOAD_REVIEWS', () => {
        expect(
            reviewsReducer(
                {},
                mockData
            )
        ).toEqual({ [mockData.productId]: mockData.reviews });
    });
    test('validating reviewReducer for ADD_NEW_REVIEW', () => {
        expect(
            reviewsReducer(
                {},
                mockDataNew
            )
        ).toEqual({[mockDataNew.productId]: [mockDataNew.review] });
    });
});