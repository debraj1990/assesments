import React from 'react';
import { shallow } from 'enzyme';
import ReviewForm from './ReviewForm_v2';

describe('Review Form test scenarios', () => {
	const mockProps = {
		onNewReview: jest.fn(),
	};

	test('render', () => {
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		expect(wrapper.find('.review-form').exists()).toBeTruthy();
	});

	test('render when state isOpen is true', () => {
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.setState({isOpen: true});
		expect(wrapper.find('.card').exists()).toBeTruthy();
	});

	test('render when state isOpen is false', () => {
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.setState({isOpen: false});
		expect(wrapper.find('.card').exists()).toBeFalsy();
	});

	test('form submit call', () => {
		jest.spyOn(ReviewForm.prototype, 'handleForm');
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.find('form').simulate('submit', { preventDefault: jest.fn()});
		expect(wrapper.instance().handleForm.mock.calls).toHaveLength(1);
	});

	test('close container on form submit', () => {
		jest.spyOn(ReviewForm.prototype, 'toggleForm');
		const wrapper = shallow(<ReviewForm {...mockProps} />);
		wrapper.setState({ isOpen: false });
		wrapper.find('.toggleBtn').simulate('click');
		expect(wrapper.instance().toggleForm.mock.calls).toHaveLength(1);
	});
});