/**
 * returns service promise
 */
function serviceFunc() {
  let promise = new Promise((resolve, reject) => {
    console.log("service execution starts");
    setTimeout(() => {
      let response = "service execution ends";
      resolve(response)
    }, 1000);
  });
  return promise;
}

/**
 * Vendor class
 */
class Vendor {

  doAppointment() {
    let _self = this;
    _self.executionStartTime = new Date();
    console.log(`Vendor appointment started at : ${_self.executionStartTime}`);
    let servicePromise = serviceFunc();
    servicePromise.then(
      result => {
        console.log(result)
        _self.executionEndTime = new Date();
        console.log(`Vendor appointment ended at: ${_self.executionEndTime}`);
        console.log(`Appointment execution time is : ${_self.executionEndTime - _self.executionStartTime} ms`);
      },
      error => {
        console.log(error)
        _self.executionEndTime = new Date();
        console.log(`Vendor appointment ended at: ${_self.executionEndTime}`);
        console.log(`Appointment execution time is : ${_self.executionEndTime - _self.executionStartTime} ms`);
      });
  }
}

let vendorObj = new Vendor();
vendorObj.doAppointment();