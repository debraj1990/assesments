// Light class
class Lights {
  // constructor() {

  // }
  // Should log msg to console
  switchOn() {
      console.log("Lights are switched on");
    }
    // Should log msg to console
  switchOff() {
    console.log("Lights are switched off");

  }
}

export default Lights;