import { Subject } from 'rxjs';
import { pipe, filter, map } from 'rxjs/operators';

// Event stream is setup to subscribe & push events to/from stream
let eventStream = new Subject();

export { eventStream };