import { eventStream } from './stream';
import Door from './door';
import Fan from './fan';
import Lights from './light';

// create objects  
let doorListner = new Door('6th', 'key1');
let fanListner = new Fan();
let lightListner = new Lights();

// Listner setup on stream
eventStream.subscribe(
  eventOccured => {
    if (eventOccured === 'opened') {
      lightListner.switchOn();
      fanListner.switchOn();

    }
    if (eventOccured === 'closed') {
      lightListner.switchOff();
      fanListner.switchOff();
    }
  }
)

// method called out
doorListner.openDoor();

// method called out with some delay
let timer = setTimeout(() => {
  doorListner.openDoor();
  clearTimeout(timer);
}, 2000);