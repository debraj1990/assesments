// Fan class
class Fan {
  // constructor() {

  // }
  // Should log msg to console
  switchOn() {
      console.log("Fans are switched on");
    }
    // Should log msg to console
  switchOff() {
    console.log("Fans are switched off");

  }
}
export default Fan;