import { eventStream } from './stream';

// class
class Door {
  // constructors can be used in future
  constructor(floor, key) {
      this.floor = floor;
      this.key = key;
    }
    // method will push 'opened' event in stream
  openDoor() {
      console.log('=====================')
      console.log('Doors are opened now');
      eventStream.next('opened');
    }
    // method will push 'closed' event in stream
  closeDoor() {
    console.log('=====================')
    console.log('Doors are closed now');
    eventStream.next('closed');
  }
}
export default Door;