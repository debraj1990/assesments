class MusicPlayer{
    constructor(){
        this.lastPlayedSongIndex = 0;
    }
    getNextSong (schedulingMethod, playList){
        let nextSongIndex;
        switch(schedulingMethod){
            case 'SDNS' :
                nextSongIndex = this.shortestSongFinder(playList);
                break;
            case 'LDNS' :
                nextSongIndex = this.longestSongFinder(playList);
                break;
            case 'FINS' :
                nextSongIndex = this.nextSongFinder(playList);
                break;
            default :
                this.lastPlayedSongIndex = nextSongIndex;
                  
        }

        this.play(playList , nextSongIndex);
        
    }
    shortestSongFinder (playList){
        let i,
            temp = playList[0].time,
            shortestSongIndex = 0,
            playListLength = playList.length;
        for(i=0; i<playListLength; i++){
            if(temp > playList[i].time){
                temp = playList[i];
                shortestSongIndex = i;
            }
        }
        return shortestSongIndex;
    }

    longestSongFinder (playList){
        let i,
            temp = playList[0].time,
            longestestSongIndex = 0,
            playListLength = playList.length;
        for(i=0; i<playListLength; i++){
            if(temp < playList[i].time){
                temp = playList[i];
                longestestSongIndex = i;
            }
        }
        return longestestSongIndex;
    }

    firstInNextSongFinder (playList){
        let i,
            playListLength = playList.length,
            nextsongIndex;
        if(this.lastPlayedSongIndex == playListLength-1){
            nextsongIndex = 0;
        }
        else{
            nextsongIndex = this.lastPlayedSongIndex + 1;
        }
        return nextsongIndex;
    }
    play(playList , nextSongIndex) {
        console.log('Song playing - ' + playList[nextSongIndex].song);
    }
}
module.exports = MusicPlayer;