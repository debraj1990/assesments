class MusicPlayer{
    constructor(){
        this.playList;
        this.lastPlayedSongIndex = 0;
        this.selectedStrategy;
    }
    getNextSong (schedulingMethod){
        let nextSong;
        nextSong = schedulingMethod();
        this.play(nextSong);
        
    }
    play(nextSong) {
        console.log(nextSong.song);
    }
}

module.exports = MusicPlayer;