class NonUniqueArrayfinder {
    findNonUniqueItem(arr){
        let tempArr = [],
            nonUniqArr = [],
            finalArr = [],
            i = 0;
        for(i = 0; i< arr.length; i++){
            if(tempArr.indexOf(arr[i]) < 0){
                tempArr.push(arr[i]);
            }
            else{
                nonUniqArr.push(arr[i]);
            }
        }
        finalArr = arr.filter(elem =>{
            return nonUniqArr.indexOf(elem) >= 0
        });
        console.log('nonUniqArr '+finalArr);
        tempArr = null;
        nonUniqArr = null;
        return finalArr;
    }
}
module.exports = NonUniqueArrayfinder;