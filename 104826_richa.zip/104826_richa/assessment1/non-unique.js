class NonUniqueArrayfinder {
    findNonUniqueItem(arr){
        const uniqueElements = {};
                        
        arr.forEach(elm => {
                    let count = uniqueElements[elm];
                    uniqueElements[elm] = count ? (++count) : 1;
        });
        
        const output = arr.filter(elm => {
                    return uniqueElements[elm] !== 1
        });
        
        return output;
    }
}
module.exports = NonUniqueArrayfinder;