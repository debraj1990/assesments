class ServiceModule{
    execute(){
        console.log('Inside service');
        throw new Error('Service error');
    }
}
module.exports = ServiceModule;