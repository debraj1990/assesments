class MostWantedLetterfinder {
    /*findMostWantedLetter method takes complete string as parameter
    and returns most repeated letter*/
    findMostWantedLetter(str){
        let countArr = [],
            largestCount = 0,
            largestCountElemsArr = [],
            mostRepeated,
            arr = str.split(''),
            arrLen = arr.length,
            regexLetter = /[a-zA-z]/,
            i;
        for(i = 0; i< arrLen; i++){
            if(regexLetter.test(arr[i])){
                countArr.push(this.countInArray(arr, arr[i]));
            }
            else{
                countArr.push(0);
            }
        }
        largestCount = Math.max.apply(null, countArr);
        largestCountElemsArr = this.findLargestCountElems(arr, countArr, largestCount);
        mostRepeated = largestCountElemsArr[0];
        for(i=0; i<largestCountElemsArr.length; i++){
            if(mostRepeated > largestCountElemsArr[i]){
                mostRepeated = largestCountElemsArr[i];
            }
        }
        return mostRepeated;
    }

    /* countInArray takes array of characters of string and particular character
    returns the count of that charater */
    countInArray(array, val) {
        let count = 0,
            arrLen = array.length,
            i;
        for (i = 0; i < arrLen; i++) {
            if (array[i].toLowerCase() === val.toLowerCase()) {
                count++;
            }
        }
        return count;
    }

    /*findLargestCountElems method takes
    array of characters of string, countarray and maximum count as parameter
    returns array of elements with maximum count */ 
    findLargestCountElems(arr, countArr, largestCount){
        let i,
            arrLen = arr.length,
            largestCountElems = [];
        for(i =0; i< arrLen; i++){
            if(largestCount == countArr[i]){
                largestCountElems.push(arr[i].toLowerCase());
            }
        }
        return largestCountElems;
    }
}
module.exports = MostWantedLetterfinder;