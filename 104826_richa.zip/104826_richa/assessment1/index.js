console.log('-index.js-')

const NonUnique = require('./non-unique');

//Testing Non- unique elements returning class
let nonUniqueArrayfinder = new NonUnique();
let arr1 = [10, 9, 10, 10, 9, 8];
let resultarr = nonUniqueArrayfinder.findNonUniqueItem(arr1);
console.log(resultarr);

//Testing Most Wanted Letter
const MostWantedLetter =  require('./most-wanted-letter');
let MostWantedLetterFinder = new MostWantedLetter();
console.log(MostWantedLetterFinder.findMostWantedLetter('How do you do?'));


//Testing Appoint vendor
const Vendor =  require('./vendor');
const Service = require('./service-module');
let vendorModule = new Vendor();
let serviceModule = new Service();
vendorModule.executeService(serviceModule);

//Testing Music Player module
const MusicPlayer = require('./music-player');
let musicPlayerModule = new MusicPlayer();
let songList = [
    {
    "song": "Abhi na jao",
    "time": 2.3
    },
    {
    "song": "Naa hum tumhe Jane",
    "time": 3
    },
    {
    "song": "Humko sirf tumse pyar hai",
    "time": 4
    }
  ];
  musicPlayerModule.getNextSong('SDNS' , songList);