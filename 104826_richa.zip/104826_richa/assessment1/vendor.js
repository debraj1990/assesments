class Vendor{
    executeService (serv){
        try {
            console.log('Before service');
            console.time('Service function');
            serv.execute();
            console.timeEnd('Service function');
            console.log('After service');
        } catch (e) {
            console.log("Vendor caught - " + e.message);
        }
    }
}
module.exports = Vendor;