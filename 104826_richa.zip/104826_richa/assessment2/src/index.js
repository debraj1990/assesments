console.log('-index.js-')

const Door = require('./door-module');
const Light =  require('./light-module');
let door1 = new Door();
let light1 = new Light();
door1.addListener(light1);
door1.open();
door1.close();



