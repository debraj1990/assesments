class Door{
    constructor () {
        this.floorNum = 3;
        this.doorNum = 2;
        this.listeners = [];
    }

    addListener(listener) {
       this.listeners.push(listener);
    }
    open () {
        console.log('Door open');
        this.listeners.forEach ( (listener) =>{
            listener.on();
        });

    }
    close () {
        console.log('Door close');
        this.listeners.forEach ( (listener) =>{
            listener.off();
        });
    }
}
module.exports = Door;
