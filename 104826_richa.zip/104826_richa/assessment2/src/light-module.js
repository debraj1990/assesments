class lightModule {
    on () {
        console.log('lights on');
    }
    off () {
        console.log('lights off');
    }

}
module.exports = lightModule;