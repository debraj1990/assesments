class Lights {
    constructor(){
        
    }

    turnOn( floor, number ){
        // turn on the lights
        console.log('lights turned on for floor ' + floor );
        console.log('lights turned on for number ' + number );
    }

    turnOff( floor, number ){
        console.log('lights turned off for floor ' + floor );
        console.log('lights turned off for number ' + number );
    }
}

module.exports = Lights;

