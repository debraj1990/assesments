class Door {
    constructor( floor, number){
        this.floor = floor;
        this.number = number;
        this.instance = [];
    }

    open(){
        // door opened
        this.instance.map( ( value, index, arr ) =>{
           value.turnOn(this.floor,this.number);
        } )
    }

    close(){
        //door closed
        this.instance.map( ( value, index, arr ) =>{
            value.turnOff(this.floor,this.number);
         } )
    }

    registerOpenAndCloseEvent( instance ){
        this.instance.push( instance );
    }
}

module.exports = Door;