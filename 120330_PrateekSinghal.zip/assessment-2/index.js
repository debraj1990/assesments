
const Door = require('./Door');
const Lights = require('./Lights');

const door = new Door( "1", "1" );

const lights = new Lights();


door.registerOpenAndCloseEvent( lights );
door.open();
door.close();