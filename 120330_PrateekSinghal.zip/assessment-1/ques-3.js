function executeAndCheckPerformace(func, ...arguments) {
    let retVal;
    console.log("function execution will start- " + func.name)
    console.time("Execution Time");
    try {
        retVal = func(...arguments);
        console.log("Function Completed!");
    } catch(e) {
        console.error("Error- " + e.message);
    }
    console.timeEnd("Execution Time");
    console.log(" Execution Done");
    return retVal;
}