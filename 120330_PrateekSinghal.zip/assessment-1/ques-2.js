var str = "This is a sample piece of code";// change this string

str = str.toLowerCase();// convert to lower case
var strArr = str.split("");// create array of characters of string
var newArr = [];
newArr = strArr.map( function ( value, index, array ){// create an array of charcodes
var charCode = value.charCodeAt(0);
    //this is the range where charCodes of all small case alphabets lie
	if( charCode >=97 && charCode <=122 ){
		return charCode;
	}
	else{
	return -1;// if not in this range, mark it as -1. It mean this is some other character.
}	
} ) 
newArr = newArr.sort();//sort the charCode array. Now all the same characters should be together.
var charCodeMaxOccured = -1;
var maxDiff = 0;
for( var i =0 ; i < newArr.length; i++ ){
    // the one which for which this difference is greatest has max occurence. Ignore the -1 
	if( ( newArr.lastIndexOf( newArr[i] ) - newArr.indexOf( newArr[i] ) > maxDiff ) && newArr[i] != -1 ){
		maxDiff = newArr.lastIndexOf( newArr[i] ) - newArr.indexOf( newArr[i] );
		charCodeMaxOccured = newArr[i];
		
}
	//console.log( newArr.indexOf( newArr[i] ), newArr.lastIndexOf( newArr[i] ) )
	
}
// no max occuring like in 'one'. Return the last character as the array was already sorted.
if( charCodeMaxOccured == -1 ){
newArr = newArr.slice( newArr.lastIndexOf( -1 ) + 1)
charCodeMaxOccured = newArr[0]
}
console.log( String.fromCharCode(charCodeMaxOccured) )// here is your letter. Enjoy!!!