var arr = [1,2,3,4,5,6,7,8,9,1,2,3,6,7,2,3,4];

var clonedArr = arr.slice().values();// create a cloned array
getArr( clonedArr.next().value );
function getArr( value ){
    /* check if the index of the value is same from start and last , if so it means this value is alone in the array. Remove it */
	if( arr.indexOf( value ) == arr.lastIndexOf( value ) ){
		arr.splice( arr.indexOf( value ), 1 );
    }
    // next value
	value = clonedArr.next().value;
	if( !value ){ // return if reached end of array
		return;
	}
	else{
		getArr( value );// keep going
	}
}
console.log( arr );// final array
