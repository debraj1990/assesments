var songList = [
    { 'title': 'ABC', 'duration': 5.1 },
    { 'title': 'DEF', 'duration': 4.1 },
    { 'title': 'XYZ', 'duration': 3.1 },
    { 'title': 'QWE', 'duration': 5.21 },
    { 'title': 'RTY', 'duration': 6.1 },
    { 'title': 'MNO', 'duration': 7.1 },
    { 'title': 'QRS', 'duration': 3.41 }
    ]
    function getSong( type, currentIndex ){
        type = type.toUpperCase();
        var song = {};
        switch( type ){
            case 'LDNS':{
                song = getLongestNextSong( currentIndex + 1 );
                break;
            }
            case 'SDNS':{
                song = getShortestNextSong( currentIndex + 1 );
                break;
            }
            default:{
                song = getNextSong( currentIndex + 1 );
                break;
            }
    
        }
        return song;
        
        function getLongestNextSong( index ){
            var arr = songList.slice( index );
            if( arr.length == 0 ){
                // start from index 0
                arr = songList;
            }
    
            var targetIndex = 0;
            var currentDuration = 0;
            for( var obj of arr ){
                if( currentDuration < obj.duration ){
                    targetIndex = arr.indexOf( obj );
                    currentDuration = obj.duration;
                }
            }
            return arr[targetIndex];
        }
        
        
        function getShortestNextSong( index ){
            var arr = songList.slice( index );
            if( arr.length == 0 ){
                arr = songList;
            }
    
            var targetIndex = 0;
            var currentDuration = arr[0].duration;
            for( var obj of arr ){
                if( currentDuration > obj.duration ){
                    targetIndex = arr.indexOf( obj );
                    currentDuration = obj.duration;
                }
            }
            return arr[targetIndex];
        }
        
        function getNextSong( index ){
            var arr = songList.slice( index );
            if( arr.length == 0 ){
                arr = songList;
            }
            return arr[0];
        }
    }
    
    getSong( 'SDNS', 2 );
    
    getSong( 'SDNS', 6 );
    
    getSong( 'SDNS', 7 );
    
    getSong( 'LDNS', 2 );
    
    getSong( 'LDNS', 6 );
    
    getSong( 'LDNS', 7 );
    
    getSong( '', 2 );
    
    getSong( '', 7 );