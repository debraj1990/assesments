//Redux lib starts

const createStore = (reducer) => {
    let state;
    let listeners = [];

    const getState = () => state;

    const subscribe = (listener) => {
        listeners.push(listener);
        return () => {
            listeners = listeners.filter((listen) => listen !== listener);
        }
    }

    const dispatch = (action) => {
        state = reducer(state, action);
        listeners.forEach((listener) => listener());
    }

    return {
        getState,
        subscribe,
        dispatch,

    };
}

const combineReducer = (reducers) => {
    return (state = {}, action) => {
        return Object.keys(reducers).reduce(
            (nextState, key) => {
                nextState[key] = reducers[key](state[key], action);
                return nextState;
            }, {}
        )
    }
}

// Redux lib ends



// action
const ADD_TODO = 'ADD_TODO';
const REMOVE_TODO = 'REMOVE_TODO';

//action creator
function addTodo(todo) {
    return {
        type: ADD_TODO,
        todo
    }
}

function removeTodo(id) {
    return {
        type: REMOVE_TODO,
        id
    }
}

//Reducers
function todos(state = [], action) {
    switch(action.type) {
        case ADD_TODO:
            return state.concat([action.todo]);
        case REMOVE_TODO:
            return state.filter((todo) => todo.id !== action.id);
        default:
            return state;    
    }
}

// combine reducer
const reducers = combineReducer({ todos });


const store = createStore(reducers);


//subscribe to the store, trigger when store changes
store.subscribe(() => {
    console.log('Current State: ', store.getState());
})

//dispatch an action
store.dispatch(addTodo({
    text: 'Learn React',
    id: 0,
    completed: true
}));

store.dispatch(addTodo({
    text: 'Learn Redux',
    id: 1,
    completed: false
}));

store.dispatch(addTodo({
    text: 'Run Run',
    id: 2,
    completed: false
}));

store.dispatch(removeTodo(2));
