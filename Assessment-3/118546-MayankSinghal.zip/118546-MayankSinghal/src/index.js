import React from 'react';
import ReactDOM from 'react-dom';
import Count from './Count'
import CustomReducer from './CustomReducer';
import CustomStore from './CustomStore';

let store = new CustomStore(CustomReducer);

ReactDOM.render(<Count store={store} />, document.getElementById('root'));
