run 'npm i'
run 'npm start'
and observe the chrome dev console