// createStore method
const createStore = (reducer, preloadedState) => {
    let state; // initialization
    let listeners = [];
    if(preloadedState) {
        state = preloadedState;
    }
    const getState = () => state;

    const dispatch = (action) => {
        state = reducer(state, action);
        listeners.forEach(listener => listener(state));
    }

    const subscribe = (listener) => {
        listeners.push(listener);
    }

    dispatch({});

    return {
        getState,
        dispatch,
        subscribe
    }
}

// combineReducer method
const combineReducers = (reducers) => {
    return (state={}, action) => {
        return Object.keys(reducers).reduce(
            (nextState, reducerKey) => {
                nextState[reducerKey] = reducers[reducerKey](state[reducerKey], action);
                return nextState;
            },
            {}//initialValue i.e. for nextState
        )
    }
}

export { createStore, combineReducers };