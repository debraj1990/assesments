import globalConstants from './globalConstants';
import { combineReducers } from "./redux-cutom";

//a reducer takes in 2 things

// 1. the action (info about what happened)
// 2. copy of current state

const shoppingCart = (state=[], action) => {
    console.log(state, action);
    switch(action.type) {
        case globalConstants.ADD_TO_CART:
            return state.concat(action.productID);
        case globalConstants.REMOVE_FROM_CART:
            let capturedProductID = action.productID;
            return state.filter((individualProductID)=> individualProductID !== capturedProductID);
        case globalConstants.RESET_CART:
            return [];
        default:
            return state;
    }
}
// const resetCart = (state=[], action) => {
//     console.log(state, action);
//     switch(action.type) {
//         case globalConstants.RESET_CART:
//             return defaultState;
//         default:
//             return state;
//     }
// }

const rootReducer = combineReducers({
    shoppingCart,
    // resetCart    // reducer keys to be same as the state keys
})

export default rootReducer;