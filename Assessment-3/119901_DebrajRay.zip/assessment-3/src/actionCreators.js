import globalConstants from './globalConstants';

const resetCartAction = () => ({ type:globalConstants.RESET_CART })
const addToCartAction = (productID) => ({ type:globalConstants.ADD_TO_CART, productID})
const removeFromCartAction = (productID) => ({ type:globalConstants.REMOVE_FROM_CART, productID})
const checkoutCartAction = (productID) => ({ type:globalConstants.CHECKOUT_CART, productID})

export { resetCartAction, addToCartAction, removeFromCartAction, checkoutCartAction }