import React from 'react';
import { getInfo } from './actions';
import { getInfoReducer } from './reducer';
import Store from './store';

const App = () => {
  const reducers = {
    info: getInfoReducer
  };

  const store = new Store(reducers);
  store.dispatch(getInfo({ title: 'hello how  are you' }));
  const storeData = store.getState;
  console.log(storeData);

  return <h1>Custom store</h1>;
};

export default App;
