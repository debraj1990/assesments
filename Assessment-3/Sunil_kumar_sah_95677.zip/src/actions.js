export const getInfo = data => ({ type: 'GET_INFO', data });
