export const getInfoReducer = (state = {}, action) => {
  switch (action.type) {
    case 'GET_INFO':
      return { ...state, ...action.data };
    default:
      return state;
  }
};
