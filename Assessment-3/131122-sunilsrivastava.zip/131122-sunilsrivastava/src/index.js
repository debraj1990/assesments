import { createStore, combineReducers } from "./reduxfunc";
import { PLCACE_ORDER, STATUS } from './constants';


/*
------------------------------
    Component 1 - Place Order
-------------------------------
*/

// Reducer
const orderReducer = (state = 0, action) => {
  switch (action.type) {
    case PLCACE_ORDER:
      return state + 1;
    default:
      return state;
  }
}
// Actions
const dispatchOrder = () => {
  return { type: PLCACE_ORDER };
}


/*
------------------------------
    Component 2 - Order status
-------------------------------
*/

// Reducer
function orderStatusReducer(state = "", action) {
  const { status, type } = action;
  switch (type) {
    case STATUS:
      return { status };
    default:
      return state;
  }
}

// Actions
function getOrderStatus(status) {
  return {
    type: STATUS,
    status
  };
}

/*
------------------------------
    UTIL function
-------------------------------
*/

function newOrder() {
  store.dispatch(getOrderStatus("Order Initated!"));
  store.dispatch(dispatchOrder());
  store.dispatch(getOrderStatus("Order completed!"));
}

/*
------------------------------
    App Initialize
-------------------------------
*/

let rootReducer = combineReducers({
  order: orderReducer,
  status: orderStatusReducer
})
let store = createStore(rootReducer);
store.subscribe(state => console.log(state));

// 1st order
newOrder();
// 2nd order
newOrder();




