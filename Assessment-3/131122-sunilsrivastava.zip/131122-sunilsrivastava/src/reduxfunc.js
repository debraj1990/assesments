// Redux initialisation
export const createStore = (dispathcerCallback) => {
  let state = {};
  const listeners = [];

  const getState = () => state;

  const dispatch = (action) => {
    state = dispathcerCallback(state, action);
    listeners.forEach(listener => listener(getState()));
  };

  const subscribe = (listener) => {
    listeners.push(listener);
  };

  dispatch({});

  return { dispatch, getState, subscribe }
}

// Combining states
export const combineReducers = reducers => {
	return (state = {}, action) => {
		return Object.keys(reducers).reduce(
      (nextState, key) => {
				nextState[key] = reducers[key](state[key], action);
				return nextState;
			},{});
	};
}
