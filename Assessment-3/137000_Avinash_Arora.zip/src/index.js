import { createStore, combineReducers } from "./redux";

// counter reducer
const initialCounterState = 0;
function counter(state = initialCounterState, action) {
  switch (action.type) {
    case "INCREMENT":
      return state + 1;
    case "DECREMENT":
      return state - 1;
    default:
      return state;
  }
}

// lastAction reducer
const initialMsgState = {
  msg: ""
};

function setMsg(state = initialMsgState, action) {
  const { msg, type } = action;
  switch (type) {
    case "MSG":
      return { msg };
    default:
      return state;
  }
}

//

// action creator
function increase() {
  return {
    type: "INCREMENT"
  };
}

function decrease() {
  return {
    type: "DECREMENT"
  };
}

function msgAction(msg) {
  return {
    type: "MSG",
    msg
  };
}

const store = createStore(
  combineReducers({
    counter,
    setMsg
  })
);

store.subscribe(state => console.log(state));

store.dispatch(increase());
store.dispatch(decrease());
store.dispatch(msgAction("Hi"));
