import {createStore, combineReducers} from './redux'
import counterReducer from './counterReducer'
import { incrementAction, decrementAction } from "./counterReducer";
import 'bootstrap/dist/css/bootstrap.css';

const rootReducer = combineReducers({
  counter: counterReducer
});
const store = createStore(rootReducer);
store.dispatch(incrementAction()); //increament here + 1
store.dispatch(incrementAction()); //increament here + 1 
store.dispatch(incrementAction()); //increament here + 1
store.dispatch(incrementAction()); //increament here + 1
store.dispatch(decrementAction()); //decreament here -1
console.log(store.getState()); // getting the current state of the store
