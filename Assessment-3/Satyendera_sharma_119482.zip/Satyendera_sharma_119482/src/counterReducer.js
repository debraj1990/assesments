const incrementAction = () => ({ type: "INCREAMENT_COUNT", data:1 }); // increament action
const decrementAction = () => ({ type: "DECREAMENT_COUNT", data:1 }); // decrement action

const reducer = (state = 0, action) => {
  if (action.type === "INCREAMENT_COUNT") {
    return state + action.data;
  }

  if (action.type === "DECREAMENT_COUNT") {
    return state - action.data;
  }

  return state;
};

export default reducer;
export { incrementAction, decrementAction };
