import React from 'react';
import ReactDOM from 'react-dom';
import Store from './store';
import Counter from './components/Counter'

// Reducer function 
// Can be imported from another file
const reducer = (state = { value: 0 }, action) => {
    switch (action.type) {
        case 'INCREMENT':
            return { value: state.value + 1 };
        case 'DECREMENT':
            return { value: state.value - 1 };
        default:
            return state;
    }
}

//Creating a store
let store = new Store(reducer);

ReactDOM.render(<Counter store={store} />, document.getElementById('root'));
