import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css'

class Counter extends Component {
    constructor(props) {
        super(props)
        let {store} = props;
        this.state = store.dispatch({type: ''});   
    }
    
    increment = () => {
        let {store} = this.props;
        store.dispatch({ type: 'INCREMENT' });
        this.setState(store.getState());
    };
    
    decrement = () => {
        let {store} = this.props;
        store.dispatch({ type: 'DECREMENT' });
        this.setState(store.getState());
    };
    render() {
        return (
            <div className='jumbotron'>
                <h1>Current counter : {this.state.value}</h1>
                <button className='btn btn-primary' onClick={this.increment}>+</button>
                <button className='btn btn-danger' onClick={this.decrement}>-</button>
            </div>
        )
    }
}

export default Counter;