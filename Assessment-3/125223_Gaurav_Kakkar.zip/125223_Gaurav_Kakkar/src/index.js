import { createStore, combineReducers } from "./redux";
import { INCREMENT_COUNTER, DECREMENT_COUNTER, GREET } from './constants';


/* ------------------------------
    Component 1 - Counter 
-------------------------------*/

// Reducer
const counterReducer = (state = 0, action) => {
  switch (action.type) {
    case INCREMENT_COUNTER:
      return state + 1;
    case DECREMENT_COUNTER:
      return state - 1;
    default:
      return state;
  }
}
// Actions 
const counterIncrease = () => {
  return { type: INCREMENT_COUNTER };
}
const counterDecrease = () => {
  return { type: DECREMENT_COUNTER };
}


/* ------------------------------
    Component 2 - Greet 
-------------------------------*/
// Reducer
function greetReducer(state = "", action) {
  const { greet, type } = action;
  switch (type) {
    case "GREET":
      return { greet };
    default:
      return state;
  }
}

// Actions
function greetUser(greet) {
  return {
    type: GREET,
    greet
  };
}

/* ------------------------------
    App Initialize  
-------------------------------*/

let rootReducer = combineReducers({
  counter: counterReducer,
  greet: greetReducer
})
let store = createStore(rootReducer);
store.subscribe(state => console.log(state));

store.dispatch(counterIncrease());
store.dispatch(counterDecrease());
store.dispatch(counterIncrease());
store.dispatch(greetUser("Hi"));
store.dispatch(counterIncrease());
store.dispatch(greetUser("Namaste!"));
