import {createStore} from './src/redux';

// Reducer
function counter(state = 0, action) {
  switch(action.type) {
    case 'INCREMENT':
      return state + 1;
    case 'DECREMENT':
      return state - 1;
    default:
      return state;
  }
}

// Action Creator
function increaseCounter(){
  return {
    type: 'INCREMENT'
  };
}
// Action Creator
function decreaseCounter(){
  return {
    type: 'DECREMENT'
  };
}

// Create Store
const store = createStore(counter);

// Subscribe to store
store.subscribe(() => console.log(store.getState()));

// Disptach Actions
store.dispatch(increaseCounter());
store.dispatch(increaseCounter());
store.dispatch(increaseCounter());
store.dispatch(decreaseCounter());