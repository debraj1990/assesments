import {createStore, combineReducers} from './redux'
import counterReducer from './counterReducer'
import { incrementAction, decrementAction } from "./counterReducer";

const rootReducer = combineReducers({
  counter: counterReducer
});
const store = createStore(rootReducer);
store.dispatch(incrementAction()); //increament store + 1
store.dispatch(incrementAction()); //increament store + 1 
store.dispatch(incrementAction()); //increament store + 1
store.dispatch(incrementAction()); //increament store + 1
store.dispatch(decrementAction()); //decreament store + 1
console.log(store.getState()); // getting the current state of the store
