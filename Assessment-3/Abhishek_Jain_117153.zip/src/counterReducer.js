
//action can be more re-usable if send the type and data object from the place where these actins beign called.
// but for now we have defined the actions here only based on increament or decreament.
const incrementAction = () => ({ type: "INCREAMENT_COUNT", data:1 });
const decrementAction = () => ({ type: "DECREAMENT_COUNT", data:1 });

const reducer = (state = 0, action) => {
  if (action.type === "INCREAMENT_COUNT") {
    return state + action.data;
  }

  if (action.type === "DECREAMENT_COUNT") {
    return state - action.data;
  }

  return state;
};

export default reducer;
export { incrementAction, decrementAction };
