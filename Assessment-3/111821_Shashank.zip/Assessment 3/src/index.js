

import { store } from './store';

console.log('--index.js--');

store.subscribe(() => {
  let currentNum = store.getState().num;
  console.log("currentState ", currentNum);
})

let incAction = { type: 'INC' };
let decAction = { type: 'DEC' };

console.log('======Initial State====== ', store.getState());


let timer1 = setTimeout(() => {
  console.log('=========Triggering Increment======');
  store.dispatch(incAction);
  clearTimeout(timer1);
}, 1000);

let timer2 = setTimeout(() => {
  console.log('=========Triggering Decrement======');
  store.dispatch(decAction);
  clearTimeout(timer2);
}, 2000);





