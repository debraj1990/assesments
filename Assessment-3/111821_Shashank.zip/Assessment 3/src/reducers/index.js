/**
 * Root Reducer
 */

import incrementReducer from './increment';
import decrementReducer from './decrement';

/**
 * [Combine multiple reducers]
 * @param  {[function]} reducers [description]
 * @return {[Object]}          [description]
 */
function combineReducers(reducers) {
    // First get an array with all the keys of the reducers (the reducer names)
    const reducerKeys = Object.keys(reducers);

    return function combination(state = {}, action) {
        // This is the object we are going to return.
        let nextState = {}

        // Loop through all the reducer keys
        reducerKeys.forEach((val, i) => {
            // Get the current key name 
            let key = reducerKeys[i];
            // Get the current reducer
            let reducer = reducers[key];
            // Get the next state by running the reducer
            let nextStateForKey = reducer(action, state)
            // Update the new state for the current reducer
            nextState[key] = nextStateForKey;
        });
        nextState = action.type === 'INC' ? nextState.increment : nextState.decrement;
        return nextState;
    }
}

// Root reducer created by combining all reducers
const rootReducer = combineReducers({
    increment: incrementReducer,
    decrement: decrementReducer
});

export { rootReducer }