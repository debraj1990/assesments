import {createStore, combineReducers} from './src/redux';

// counter reducer
const initialCounterState = 0;
function counter(state = initialCounterState, action) {
  switch(action.type) {
    case 'INCREMENT':
      return state + 1;
    case 'DECREMENT':
      return state - 1;
    default:
      return state;
  }
}

// lastAction reducer
const initialLastActionState = {
  lastAction: '',
};

function lastAction(state = initialLastActionState, action) {
  switch(action.type) {
    case 'INCREMENT':
      return {
        lastAction: 'INC'
      };
    case 'DECREMENT':
    return {
      lastAction: 'DEC'
    };
    default:
      return state;
  }
}

//

// action creator
function increase(){
  return {
    type: 'INCREMENT'
  };
}

function decrease(){
  return {
    type: 'DECREMENT'
  };
}

const store = createStore(combineReducers({
  counter,
  lastAction
}));

store.subscribe(state => console.log(state));

store.dispatch(increase());
store.dispatch(increase());
store.dispatch(increase());
store.dispatch(decrease());


