import typeConstants from './typeConstants'

const countReducer = (state = 0, action) => {
  switch (action.type) {
    case typeConstants.INCREAMENT_COUNT:
      return state + action.data
    case typeConstants.DECREAMENT_COUNT:
      return state - action.data
    default:
      return state
  }

}

export default countReducer
