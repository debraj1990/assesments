import { createStore, combineReducers } from './redux'
import countReducer from './countReducer'
import greetReducer from './greetReducer'
import { incrementAction, decrementAction, changeGreetingAction } from "./Actions"

const rootReducer = combineReducers({
  greeting: greetReducer,
  counter: countReducer
})

const store = createStore(rootReducer)
store.dispatch(incrementAction())
store.dispatch(incrementAction())
console.log(store.getState())  // Greeting null & Counter 2
store.dispatch(incrementAction())
store.dispatch(incrementAction())
store.dispatch(changeGreetingAction("SOME GREETING"))  // Greeting "SOME GREETING" & Counter 4
console.log(store.getState())
store.dispatch(decrementAction())
store.dispatch(changeGreetingAction("NEW GREETING"))   // Greeting "NEW GREETING" & Counter 3
console.log(store.getState())
