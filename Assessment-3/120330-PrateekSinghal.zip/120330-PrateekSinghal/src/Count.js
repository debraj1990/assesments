import React, { Component } from 'react';
import {INCREMENT_COUNT, DECREMENT_COUNT} from './Constant';

class Counter extends Component {
    constructor(props) {
        super(props);
        this.state = {
            count : 0
        }
    }
    
    dispatchCount = ( strType ) => {
        let {store} = this.props;        
        store.dispatchAction({ type: strType });
        this.setState(store.getLatestState());
    };
    
    render() {
        return (
            <section>
                <button onClick={this.dispatchCount.bind(this,INCREMENT_COUNT)}>Increment by 1</button>
                &nbsp;
                <button onClick={this.dispatchCount.bind(this,DECREMENT_COUNT)}>Decrement by 1</button>
                <p>Count is {this.state.count}</p>
            </section>
        )
    }
}

export default Counter;