const CustomStore = (customReducer) => {
    let state = undefined;
    return {
        dispatchAction: (action) => {
            state = customReducer(state, action);
        },
        getLatestState: () => state
    };
};

export default CustomStore;