import {INCREMENT_COUNT,DECREMENT_COUNT} from './Constant';

const CustomReducer = function ( state, action ){
    if( !state ){
        state = {};
        state.count = 0;
    } 
    switch (action.type) {
        case INCREMENT_COUNT:
            return { 
                count: state.count + 1
            };
        case DECREMENT_COUNT:
            return { 
                count: state.count - 1
            };
        default:
            return state;
    }
} 

export default CustomReducer;