import React, { Component } from 'react';

export default class ComponentList extends Component {
  renderComments = () =>
    this.props.comment &&
    this.props.comment.map(item => <li key={item}>{item}</li>);

  render() {
    return (
      <div>
        <h3>Comments </h3>
        <ul>{this.renderComments()}</ul>
      </div>
    );
  }
}
