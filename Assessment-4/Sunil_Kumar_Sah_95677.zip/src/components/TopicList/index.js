import React, { Component } from 'react';
import { getInfo } from '../../actions';
import mockData from '../../comments';
import CommentList from '../ComponentList';

export default class TopicList extends Component {
  state = {
    comments: []
  };
  showComments = topic => {
    this.props.store.dispatch(getInfo(topic));
  };

  getComments = () => {
    this.props.store.subscribe(store => {
      const topic = store.topic;
      if (Object.keys(topic).length !== 0) {
        this.setState({ comments: mockData[topic].map(item => item.comment) });
      }
    });
  };

  componentDidMount() {
    this.getComments();
  }

  render() {
    return (
      <div>
        <ul>
          <li>
            <a
              href="/"
              onClick={e => {
                e.preventDefault();
                this.showComments('Java');
              }}
            >
              Java
            </a>
          </li>
          <li>
            <a
              href="/"
              onClick={e => {
                e.preventDefault();
                this.showComments('JavaScript');
              }}
            >
              JavaScript
            </a>
          </li>
          <li>
            <a
              href="/"
              onClick={e => {
                e.preventDefault();
                this.showComments('ReactJS');
              }}
            >
              ReactJS
            </a>
          </li>
        </ul>
        <CommentList comment={this.state.comments} />
      </div>
    );
  }
}
