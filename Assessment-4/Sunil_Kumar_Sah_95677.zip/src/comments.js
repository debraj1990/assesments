export default {
  Java: [
    {
      author: 'abc',
      comment: 'Java is multithreading multitasking language'
    },
    {
      author: 'cda',
      comment: 'Java is awesome'
    }
  ],
  JavaScript: [
    {
      author: 'abc',
      comment: 'JavaScript is singlethreaded non-blocking I/O language'
    },
    {
      author: 'cda',
      comment: 'JavaScript is unique'
    }
  ],
  ReactJS: [
    {
      author: 'abc',
      comment: 'ReactJS is javaScript lib'
    },
    {
      author: 'cda',
      comment: 'ReactJS with Redux is unique'
    }
  ]
};
