export const getInfo = data => ({ type: 'ACTIVE_TOPIC', data });
