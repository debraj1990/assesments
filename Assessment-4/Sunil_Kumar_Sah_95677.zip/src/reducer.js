export const getInfoReducer = (state = {}, action) => {
  switch (action.type) {
    case 'ACTIVE_TOPIC':
      return action.data;
    default:
      return state;
  }
};
