import React from 'react';
import TopicList from './components/TopicList';
import { getInfoReducer } from './reducer';
import Store from './store';

const App = () => {
  const reducers = {
    topic: getInfoReducer
  };

  const store = new Store(reducers);

  return (
    <div>
      <TopicList store={store} />
    </div>
  );
};

export default App;
