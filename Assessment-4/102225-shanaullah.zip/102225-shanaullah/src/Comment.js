import React from 'react';
import { connect } from './redux/react-redux';

const Comment = (props) => {
	const {comments} = props;

	const commentList = comments.map((comment, id)=>(
		<li key={id} className="list-item">{comment.comment}</li>
	));
	
	return(
		<div className="list-group">
			{commentList}
		</div>
	);
}

const mapStateToProps = (state)=>({comments: state.comments});

export default connect(mapStateToProps, null)(Comment);