import store from './store';
import React from 'react';
import PropTypes from 'prop-types';

export function connect(mapStateToProps, mapDispatchToProps) {
	return function (WrappedComponent) {
		return class WrapperComponent extends React.Component {
			
			constructor(props) {
				super(props);
				this.state = {
					storeState: store.getState(),
				}
			}

			componentDidMount() {
				this.unsubscribe = store.subscribe(() => {
					this.setState({
						storeState: store.getState()
					});
				});
			}

			componentWillUnmount() {
				this.unsubscribe();
			}

			render() {
				this.oldProps = typeof mapStateToProps === 'function' ? mapStateToProps(this.state.storeState, this.props) : {};
				const newProps = Object.assign({},this.oldProps,mapDispatchToProps ? mapDispatchToProps(store.dispatch.bind(this)) : null,);
				return <WrappedComponent {...newProps} />
			}
			
		}
	}
}