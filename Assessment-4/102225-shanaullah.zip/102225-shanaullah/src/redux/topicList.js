export const topicList = [{
	"topic": "React",
	"comments": [{
		"comment": "React is a Great Library"
	},{
		"comment": "Faster performance"
	},{
		"comment": "Diffing Algorithm"
	}]
},{
	"topic": "Angular",
	"comments": [{
		"comment": "Angular is a Framework"
	},{
		"comment": "Created by google"
	},{
		"comment": "Good for reactive programming"
	}]
}];