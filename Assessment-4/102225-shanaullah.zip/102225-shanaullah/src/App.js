import React, { Component } from 'react';
import {connect} from './redux/react-redux';
import TopicList from './TopicList';
import Comment from './Comment';
import { loadTopic } from './redux/action';
import { topicList } from './redux/topicList';
import 'bootstrap/dist/css/bootstrap.css';
import './App.css';

class App extends Component {
  componentDidMount() {
    const {loadTopics} = this.props;
    loadTopics(topicList);
  }
  render() {
    return (
      <div className="container">
        <h2>Assignment - 4 | Redux Connect | Shanaullah</h2>
        <hr/>
        <div className="row">
          <div className="col-sm-12">
            <TopicList />
          </div>

          <div className="col-sm-12">
          <br></br>
            <Comment />
          </div>
        </div>
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => ({
  loadTopics: (list) => dispatch(loadTopic(list))
});

export default connect(null, mapDispatchToProps)(App);
