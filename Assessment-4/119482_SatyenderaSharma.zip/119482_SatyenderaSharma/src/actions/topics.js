const loadTopics = () => {
    let topics = [
        { id: 1, title: "React", comments: [] },
        { id: 2, title: "TypeScript", comments: [] }
    ]

    return { type: 'LOAD_TOPICS', topics: topics }
}
export { loadTopics }