

const loadComments = () => {
    let comments = [
        { id: 1, author: "Satya", description: "React comment" },
        { id: 2, author: "Sharma", description: "TypeScript comment" }
    ]

    return { type: 'LOAD_COMMENTS', comments: comments }
}

export { loadComments }