export const LOAD_PRODUCTS = "LOAD_PRODUCTS"
export const BUY = "BUY"

