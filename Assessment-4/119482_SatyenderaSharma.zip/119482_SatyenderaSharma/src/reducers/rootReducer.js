
import { topicsReducer } from './topics'
import { commentsReducer } from './comments'
import combineReducers from '../redux-lib/src/combineReducers'

// root reducer 
const rootReducer = combineReducers({

    topics: topicsReducer,
    comments: commentsReducer
});


export default rootReducer;

