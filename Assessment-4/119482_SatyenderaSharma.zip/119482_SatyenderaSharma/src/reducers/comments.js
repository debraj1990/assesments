
export function commentsReducer(state = [], action) {
    //
    console.log("-comments-reducer-");
    switch (action.type) {
        case 'LOAD_COMMENTS': {
            let { comments } = action
            return [...state, ...comments]
        }
        default:
            return state;
    }
}