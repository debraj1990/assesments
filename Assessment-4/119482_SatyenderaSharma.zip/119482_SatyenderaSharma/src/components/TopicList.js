import React, { Component } from 'react';
import { loadTopics } from "../actions/topics";
import { bindActionCreators } from "../redux-lib/src";
import { connect } from "../react-redux-lib/src";


class TopicList extends Component {

    componentDidMount() {

        let { actions } = this.props;

        setTimeout(() => {
            actions.loadTopics();
        }, 1000)

    }
    componentWillUnmount() {
        console.log("Topic list component unmounted successfully");
        //this.unsubscribe();
    }
    render() {

        let { topics } = this.props;
        return (
            <div>
                <h1>Topics</h1>
                {
                    topics.map((item, idx) => {
                        return (<p key={idx}>{item.title}</p>)
                    })
                }

            </div>
        );
    }
}

const mapStateToProps = (state, ownProps) => ({
    // ... computed data from state and optionally ownProps
    topics: state.topics
})

const mapDispatchToProps = dispatch => ({
    // ... normally is an object full of action creators
    actions: bindActionCreators({ loadTopics }, dispatch)
})

// `connect` returns a new function that accepts the component to wrap:
const connectToStore = connect(
    mapStateToProps,
    mapDispatchToProps
)

export default connectToStore(TopicList);

