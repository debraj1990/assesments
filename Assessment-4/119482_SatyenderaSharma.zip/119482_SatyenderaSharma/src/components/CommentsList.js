import React, { Component } from 'react';
import { loadComments } from "../actions/comments";
import { bindActionCreators } from "../redux-lib/src";
import { connect } from "../react-redux-lib/src";

class CommentsList extends Component {
    constructor() {
        super();
    }
    componentDidMount() {

        let { actions } = this.props;
        setTimeout(() => {
            actions.loadComments();
        }, 1000)

    }
    componentWillUnmount() {
        console.log("Comments list component unmounted successfully");

    }
    render() {
        let { comments } = this.props;
        return (
            <div>
                <h1>Comments</h1>
                {
                    comments.map((item, idx) => {
                        return (<div key={idx}><h5 >{item.author}</h5><p>{item.description}</p></div>)
                    })
                }

            </div>
        );
    }
}


const mapStateToProps = (state, ownProps) => ({
    // ... computed data from state and optionally ownProps
    comments: state.comments
})

const mapDispatchToProps = dispatch => ({
    // ... normally is an object full of action creators
    actions: bindActionCreators({ loadComments }, dispatch)
})

// `connect` returns a new function that accepts the component to wrap:
const connectToStore = connect(
    mapStateToProps,
    mapDispatchToProps
)

export default connectToStore(CommentsList);

