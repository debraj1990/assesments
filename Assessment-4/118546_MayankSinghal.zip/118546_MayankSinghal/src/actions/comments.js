

const loadComments = () => {
    let comments = [
        { id: 1, author: "Neha", description: "React comment" },
        { id: 2, author: "Shashank", description: "Angular comment" }
    ]

    return { type: 'LOAD_COMMENTS', comments: comments }
}

export { loadComments }