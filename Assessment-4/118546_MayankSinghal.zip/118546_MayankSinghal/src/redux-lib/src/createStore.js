export default function createStore(reducer, initialState) {
    console.log('create store called');
    let state = initialState || {},
        listeners = [];

    /**
     * function to get current state of store
     */
    const getState = () => state;


    const dispatch = (action) => {
        state = reducer(state, action)
        listeners.forEach(listener => { listener() })
    }

    const subscribe = (listener) => {
        listeners.push(listener);
        return () => {
            const listnerIndex = listeners.indexOf(listener)
            listeners.splice(listnerIndex, 1)
        }
    }

    return {
        getState,
        dispatch,
        subscribe
    }

}