/**
 * 
 * 

Assesment-4

Connect React with your Redux store

Create 2 React UI components 

1.	TopicList component
2.	CommentList component


TopicList renders all topics like java,js,react,angular,etc..
when you click specific topic, should render user-comments using CommentList component

imp-note:
use ‘Assesment-3’ solution as state management library
( custom – Redux implementation)


conditions:

-	on ‘componentDidMount’ hook, both components should subscribe with ‘store’
-	on componentWillUnmount’ hook, should un-subscribe with store
-	and both UI components must not tightly coupled with redux store


give me a pattern , which can help react components can work with redux store  without tight-coupling 


 * 
 */

import 'bootstrap/dist/css/bootstrap.min.css';
// import $ from 'jquery';
// import Popper from 'popper.js';
import 'bootstrap/dist/js/bootstrap.bundle.min';
import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';

ReactDOM.render(<App />, document.getElementById('root'));

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: http://bit.ly/CRA-PWA
serviceWorker.unregister();
