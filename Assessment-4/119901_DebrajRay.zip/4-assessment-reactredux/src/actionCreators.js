import globalConstants from './globalConstants';

const loadTopicAction = () => {

    let topics = [
        {
            id: 101,
            topicName : 'JAVA',
            description: 'JAVA runs on JVM (Java Virtual Machine)'
        },
        {
            id: 102,
            topicName : 'JS',
            description: 'JS also known as ES (Echmascript)'
        },
        {
            id: 103,
            topicName : 'REACT',
            description: 'REACT is a JS libraby built by Facebook Developers community'
        },
        {
            id: 104,
            topicName : 'Angular',
            description: 'Angular is a JS libraby built by Google Developers community'
        },

    ];
    return { type:globalConstants.LOAD_TOPIC, topics }
}
const addTopicAction = (topic) => ({ type:globalConstants.ADD_TOPIC, topic})
const addCommentForTopicAction = (topicId, comment) => ({ type:globalConstants.ADD_COMMENT, topicId, comment})
const loadCommentAction = (topicId) => {
    //Logic to load comments for given topicId
    let comments = [{ ratingStar: 3, author: "Er. Debraj Ray", commentBody: 'default review comment for Topic ID #'+ topicId }]
    return { type:globalConstants.LOAD_COMMENT, topicId, comments}
}

export { loadTopicAction, addTopicAction, loadCommentAction, addCommentForTopicAction }