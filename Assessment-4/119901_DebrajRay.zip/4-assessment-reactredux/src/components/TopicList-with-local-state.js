import React, { Component } from 'react';
import store from '../store';
import { loadTopicAction } from '../actionCreators';

class TopicList extends Component {
  constructor(props){
    super(props)
    this.state = {
      topics: []
    }
  }
  componentDidMount() {
    store.dispatch(loadTopicAction())
      let topics = store.getState().topics;
      this.setState({
        topics
      })
    // store.subscribe(() => {
    //   store.dispatch(loadTopicAction())
    //   let topics = store.getState().topics;
    //   this.setState({
    //     topics
    //   })
    // })
  }
  render() {
    let { topics } = this.state; console.log(topics);
    
    return (
        // <ul className="topic-list list-group">
        //   {topics.map(topic => (
        //     <li className="list-group-item" key={topic.id} onClick="">{topic.topicName}</li>
        //   ))}
        // </ul>
        <div className="topic-list">
          <button className="btn btn-info btn-sm"><i className="fa fa-plus"></i>Add New Topic</button>
          <div id="accordion">
          {topics.map(topic => (
            <div className="card" key={topic.id}>
              <div className="card-header" id={'heading_'+topic.id}>
                <h5 className="mb-0">
                  <button className="btn btn-link" data-toggle="collapse" data-target={'#card_'+topic.id} aria-expanded="true" aria-controls={'card_'+topic.id} onClick={this.loadCommentsForTopic}>
                    {topic.topicName}
                  </button>
                    {topic.description}
                </h5>
              </div>
          
              <div id={'card_'+topic.id} className="collapse show" aria-labelledby={'heading_'+topic.id} data-parent="#accordion">
                <div className="card-body">
                  <div className="card">
                    <div className="card-body">
                      <h5 className="card-title">ratingStar star(s)</h5>
                      <h6 className="card-subtitle mb-2 text-muted">By: author</h6>
                      <hr/>
                      <p className="card-text">commentBody</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            ))}
          </div>
        </div>
    );
  }
}

export default TopicList;