import React from 'react';
import { connect } from '../react-redux';

const CommentList = (props) => {
    const {comments, topicId} = props; console.log(props); //comments is an obj and not a map
    let commentCardsList = 'No Comments recorded.';
    if(comments !== {}) {
        const commentsArr = comments[topicId] || []; console.log(commentsArr);
        commentCardsList = commentsArr.map((comment, idIterator)=>(
            <div key={idIterator} className="card-body">
                <div className="card">
                <div className="card-body">
                    <h5 className="card-title">{comment.ratingStar} star(s)</h5>
                    <h6 className="card-subtitle mb-2 text-muted">By: {comment.author}</h6>
                    <hr/>
                    <p className="card-text">{comment.commentBody}</p>
                </div>
                </div>
            </div>
        ));
    }
    
    return(
        <div id={'card_'+topicId} className="collapse show" aria-labelledby={'heading_'+topicId} data-parent="#accordion">
            {commentCardsList}
        </div>
    );
}
// mapStateToProps and mapDispatchToProps both take ownProps as the second argument.
const mapStateToProps = (state, ownProps)=>({comments: state.comments, topicId: ownProps.topicId});

export default connect(mapStateToProps, null)(CommentList);