import globalConstants from './globalConstants';
import { combineReducers } from "./redux-cutom";

//a reducer takes in 2 things

// 1. the action (info about what happened)
// 2. copy of current state

const topics = (state=[], action) => {
    console.log(state, action);
    switch(action.type) {
        case globalConstants.LOAD_TOPIC:
            return [...action.topics];
        case globalConstants.ADD_TOPIC:
            return state.concat(action.topic);
        default:
            return state;
    }
}
const comments = (state=[], action) => {
    console.log(state, action);
    switch(action.type) {
        case globalConstants.LOAD_COMMENT:{
            let { topicId, comments } = action;
            // let existingComments = state[topicId] || [];
            // comments = [...existingComments, ...comments]
            return Object.assign({}, state, { [topicId]: comments })
        }
        case globalConstants.ADD_COMMENT:{
            let { topicId, comment } = action;
            let existingComments = state[topicId];
            let comments = [...existingComments, comment]
            return Object.assign({}, state, { [topicId]: comments })
        }
        default:
            return state;
    }
}

const rootReducer = combineReducers({
    topics,
    comments    // reducer keys to be same as the state keys
})

export default rootReducer;