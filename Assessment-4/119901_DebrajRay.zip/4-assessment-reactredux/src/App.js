import React, { Component } from 'react';
import { connect } from './react-redux';
import { loadTopicAction } from './actionCreators';
import TopicList from './components/TopicList';

class App extends Component {
  componentDidMount() {
		const {loadTopics} = this.props;
		loadTopics();
  }
  render() {
    return (
      <div className="App">
          <h1>
            Technology Topics knowledge base
          </h1>
          <hr/>
          <div className="col-md-12">
            <TopicList/>
          </div>
      </div>
    );
  }
}

// export default App;
const mapDispatchToProps = dispatch => ({
  loadTopics: () => dispatch(loadTopicAction())
});

export default connect(null, mapDispatchToProps)(App);
