import React, {Component} from 'react';
import PropTypes from 'prop-types';
import store from './store';

const connect = (mapStateToProps=null, mapDispatchToProps) => {
    return function(WrappedComponent) {
        let connectHOC = class connectHOC extends Component {
            constructor(props) {
                super(props);
                this.state = {
                    storeState: store.getState()
                }
            }

            componentDidMount() {
                this.unsubscribe = store.subscribe(() => {
                    this.setState({
                        storeState: store.getState()
                    });
                });
            }

            componentWillUnmount() {
                this.unsubscribe();
            }

            render() {
                this.oldProps =  typeof mapStateToProps === 'function' ? mapStateToProps(this.state.storeState, this.props) : {};
                const newProps = Object.assign(
                    {},
                    this.oldProps,
                    mapDispatchToProps ? mapDispatchToProps(store.dispatch.bind(this)) : null
                );
				return <WrappedComponent {...newProps} />
            }
        }
        connectHOC.contextType = {
            store: PropTypes.object
        }
        return connectHOC;
    }
};
export { connect };