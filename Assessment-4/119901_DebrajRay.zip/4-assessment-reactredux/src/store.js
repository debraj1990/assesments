// import custom made redux lib
import { createStore } from "./redux-cutom";

// import the root reducer
import rootReducer from './reducer';

//create an object for the default data (similar to initial react component state)
// **But have to keep in mind that an individual reducer is needed for every redux state key
export const defaultState = {
  topics: [],
  comments: {}
};

  const store = createStore(rootReducer, defaultState);

  export default store;