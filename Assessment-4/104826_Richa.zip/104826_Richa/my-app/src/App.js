import React, { Component } from 'react';
import {connect} from './redux/react-redux';
import TopicList from './TopicList';
import Comment from './Comment';
import { loadTopic } from './redux/action';
import { dataJson } from './redux/data-const';
import 'bootstrap/dist/css/bootstrap.css';
import './App.css';

class App extends Component {
  componentDidMount() {
    const {loadTopics} = this.props;
    loadTopics(dataJson);
  }
  render() {
    return (
      <div className="container">
        <h2>Assignment - 4 </h2>
        <hr/>
        <div className="row">
            <TopicList />
		</div>
        <div className="row">
			<Comment />
		</div>
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => ({
  loadTopics: (list) => dispatch(loadTopic(list))
});

export default connect(null, mapDispatchToProps)(App);
