const topicReduer = (state=[], action) => {
	switch(action.type) {
		case 'LOAD_TOPIC':
			return [...state, ...action.data];
		default:
			return state;
	}
};

const commentReducer = (state=[], action) => {
	switch(action.type) {
		case 'LOAD_COMMENT':
			return [ ...action.data];
		default:
			return state;
	}
}

export {
	topicReduer,
	commentReducer
}