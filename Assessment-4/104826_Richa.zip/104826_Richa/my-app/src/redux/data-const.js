export const dataJson = 
[
  {
    "title": "Java",
    "comments": [
      {
        "title": " Java comment 1"
      },
      {
        "title": "Java comment 2"
      },
      {
        "title": "Java comment 3"
      }
    ]
  },
  {
    "title": "JS",
    "comments": [
      {
        "title": "JS comment 1"
      },
      {
        "title": "JS comment 2"
      },
      {
        "title": "JS comment 3"
      }
    ]
  },
  {
    "title": "React",
    "comments": [
      {
        "title": "React comment 1"
      },
      {
        "title": "React comment 2"
      },
      {
        "title": "React comment 3"
      }
    ]
  },
  {
    "title": "Angular",
    "comments": [
      {
        "title": "Angular comment 1"
      },
      {
        "title": "Angular comment 2"
      },
      {
        "title": "Angular comment 3"
      }
    ]
  }
];