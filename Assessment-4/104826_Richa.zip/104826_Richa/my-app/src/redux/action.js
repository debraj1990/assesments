export const loadTopic = (data) => ({ type: 'LOAD_TOPIC', data });

export const loadComment = data => ({ type: 'LOAD_COMMENT', data });