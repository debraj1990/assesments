import React, { Component } from 'react';
import { connect } from './redux/react-redux';
import {loadComment} from './redux/action';

class TopicList extends Component {
	constructor(){
		super();
		this.showComments = this.showComments.bind(this);
	}

	showComments(comments) {
		const {loadComments} = this.props;
		loadComments(comments);
	}

	render() {
		const { topics } = this.props;
		const topicList = topics.map((topic, idx) => (
			<li	className="list-group-item"
				onClick={e => this.showComments(topic.comments)}>{topic.title}</li>
		));
		return (
			<ul className="list-group">
				{topicList}
			</ul>
		)
	}
}

const mapStateToProps = (state) => ({ topics: state.topics });

const mapDispatchToProps = dispatch => ({
	loadComments: (comments)=> dispatch(loadComment(comments))
});

export default connect(mapStateToProps, mapDispatchToProps)(TopicList);