import React from 'react';
import {dispatchOrder, getOrderStatus} from './actions';
import 'bootstrap/dist/css/bootstrap.css';

class App extends React.Component {
  constructor(props) {
    super(props);

  }

  orderHandler() {
    const { store } = this.props;
    store.dispatch(getOrderStatus("Order Initated!"));
    store.dispatch(dispatchOrder());
    if(window) {
      setTimeout(()=>{
        store.dispatch(getOrderStatus("Order completed!"));
        this.forceUpdate();
      }, 3000)
    }
    this.forceUpdate();
  }

  render() {
    const { store } = this.props;
    const {order, status:notification} = store.getState();

    return (
    <div className="card">
      <div className="card-body">
      <div className={notification.status && `alert alert-success`}>{notification.status}</div>
      <p className="badge badge-info">Total order - {order}</p>
      <hr />
      <button className="btn btn-primary" onClick={()=>{this.orderHandler()}}>Order Now!</button>
      </div>
    </div>
    )
  }
}


export default App;
