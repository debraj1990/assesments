import React from "react";
import TopicList from "./TopicList";

class App extends React.Component {
  constructor(props) {
    super(props);
  }

  render() {
    const captionStyle = {
      marginTop: "2em"
    };
    return (
      <>
        <p style={captionStyle}>
          Below are the topic list. Click on topic to view comments for that
          topic
        </p>
        <TopicList />
      </>
    );
  }
}

export default App;
