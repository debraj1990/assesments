export const topicList = [
  {
    id: 'java',
    dispalyName: 'Java'
  },
  {
    id: 'javascript',
    dispalyName: 'Advance Javascript'
  },
  {
    id: 'reactJs',
    dispalyName: 'React JS'
  },
  {
    id: 'angularJs',
    dispalyName: 'Angular JS'
  },
  {
    id: 'vueJs',
    dispalyName: 'Vue JS'
  }
]

export const comments = {
  java: [
    {
      id: 'jhone-doe',
      author: 'Jhone Doe',
      message: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '20th Jan 2019'
    },
    {
      id:'foo-do',
      author: 'Foo do',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '25th Jan 2019'
    },
    {
      id: 'hena-rey',
      author: 'Hena Rey',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '2nd feb 2019'
    }
  ],
  javascript: [
    {
      id: 'jhone-doe',
      author: 'Jhone Doe',
      message: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '20th Jan 2019'
    },
    {
      id:'foo-do',
      author: 'Foo do',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '25th Jan 2019'
    },
    {
      id: 'hena-rey',
      author: 'Hena Rey',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '2nd feb 2019'
    }
  ],
  reactJs: [
    {
      id: 'jhone-doe',
      author: 'Jhone Doe',
      message: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '20th Jan 2019'
    },
    {
      id:'foo-do',
      author: 'Foo do',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '25th Jan 2019'
    },
    {
      id: 'hena-rey',
      author: 'Hena Rey',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '2nd feb 2019'
    }
  ],
  angularJs: [
    {
      id: 'jhone-doe',
      author: 'Jhone Doe',
      message: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '20th Jan 2019'
    },
    {
      id:'foo-do',
      author: 'Foo do',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '25th Jan 2019'
    },
    {
      id: 'hena-rey',
      author: 'Hena Rey',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '2nd feb 2019'
    }
  ],
  vueJs: [
    {
      id: 'hena-rey',
      author: 'Hena Rey',
      comment: 'Hic quoque suus est de summoque bono dissentiens dici vere Peripateticus non potest. Age nunc isti doceant, vel tu potius quis enim ista melius',
      commentDate: '2nd feb 2019'
    }
  ],

}
