import {combineReducers} from './reduxfunc';
import { PLCACE_ORDER, STATUS } from './constants';

/*
------------------------------
    Component 1 - Place Order
-------------------------------
*/

const orderReducer = (state = 0, action) => {
  switch (action.type) {
    case PLCACE_ORDER:
      return state + 1;
    default:
      return state;
  }
}

/*
------------------------------
    Component 2 - Order status
-------------------------------
*/

const orderStatusReducer = (state = "", action) => {
  const { status, type } = action;
  switch (type) {
    case STATUS:
      return { status };
    default:
      return state;
  }
}

const rootReducer = combineReducers({
  order: orderReducer,
  status: orderStatusReducer
})

export default rootReducer;
