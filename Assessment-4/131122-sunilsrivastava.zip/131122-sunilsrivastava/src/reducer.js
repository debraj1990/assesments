import { combineReducers } from "./reduxfunc";
import { SET_COMMENTS, SET_TOPICS } from "./constants";

/*
------------------------------
    topic list
-------------------------------
*/

const topicListReducer = (state = [], action) => {
  const { topics, type } = action;
  switch (type) {
    case SET_TOPICS:
      if (topics) {
        return topics;
      }

    default:
      return state;
  }
};

/*
------------------------------
    comment List
-------------------------------
*/

const commentsListReducer = (state = [], action) => {
  const { comments, type } = action;
  switch (type) {
    case SET_COMMENTS:
      if (comments) return comments;
    default:
      return state;
  }
};

const rootReducer = combineReducers({
  topics: topicListReducer,
  comments: commentsListReducer
});

export default rootReducer;
