import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import reducer from "./reducer";
import { createStore } from "./reduxfunc";
import "bootstrap/dist/css/bootstrap.css";
import { topicList, comments } from "./mockdata";
import { Provider } from "./Provider";
import { setTopicList, setComments } from "./actions";

const store = createStore(reducer);
store.dispatch(setTopicList(topicList));
store.dispatch(setComments(comments));

ReactDOM.render(
  <Provider store={store}>
    <App />
  </Provider>,
  document.getElementById("app")
);
