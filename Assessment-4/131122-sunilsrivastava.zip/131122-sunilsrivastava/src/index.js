import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import reducer from './reducer';
import {createStore} from './reduxfunc';
import 'bootstrap/dist/css/bootstrap.css';


const store = createStore(reducer);

ReactDOM.render(<App store={store} />, document.getElementById('app'));
