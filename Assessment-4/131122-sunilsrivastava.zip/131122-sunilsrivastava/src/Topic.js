import React, { PureComponent } from 'react';
import CommentList from './CommentList'

class Topic extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      isCommentOpen: false
    }
  }

  toggleCommentHandler() {
    this.setState({
      isCommentOpen: !this.state.isCommentOpen
    })
  }

  render () {
    const {data} = this.props;
    return (<>
    <a href={'#'} onClick={()=>{this.toggleCommentHandler()}}>{data.dispalyName} {this.state.isCommentOpen?(<span className='float-right'>&uarr;</span>):(<span className='float-right'>&darr;</span>)}</a>
    {this.state.isCommentOpen && <CommentList commentId={data.id} />}
    </>)
  }
}

export default Topic;
