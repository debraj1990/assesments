import React, { PureComponent } from "react";
const StoreContext = React.createContext({});

export class Provider extends PureComponent {
  constructor(props) {
    super(props);
    this.state = {
      reduxState: props.store.getState()
    };
  }
  componentDidMount() {
    this.props.store.subscribe(state => {
      this.setState({
        reduxState: state
      });
    });
  }
  render() {
    const { children, store } = this.props;
    return (
      <StoreContext.Provider
        value={{
          state: this.state.reduxState,
          dispatch: store.dispatch,
          subscribe: store.subscribe
        }}
      >
        {children}
      </StoreContext.Provider>
    );
  }
}

export const connect = (dispatchFunction, statetoPropsFunction) => {
  return WrappedComponent => {
    return class extends React.PureComponent {
      render() {
        return (
          <StoreContext.Consumer>
            {({ dispatch, state, subscribe }) => {
              const stateProps = statetoPropsFunction
                ? statetoPropsFunction(state)
                : {};
              const dispatchProps = dispatchFunction
                ? dispatchFunction(dispatch)
                : {};
              return (
                <WrappedComponent
                  {...this.props}
                  {...stateProps}
                  {...dispatchProps}
                  {...{ subscribe }}
                />
              );
            }}
          </StoreContext.Consumer>
        );
      }
    };
  };
};
