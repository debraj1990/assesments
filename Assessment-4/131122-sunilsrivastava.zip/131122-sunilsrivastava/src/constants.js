export const SET_COMMENTS = "set_comments";
export const SET_TOPICS = "set_comments";

