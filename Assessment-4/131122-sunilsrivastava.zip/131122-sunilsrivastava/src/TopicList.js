import React, { PureComponent } from "react";
import { connect } from "./Provider";
import Topic from "./Topic";
import { topicList } from "./mockdata";
import { setTopicList } from "./actions";

class TopicList extends PureComponent {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.setTopic(topicList);
    this.unsubscribe = () =>
      this.props.subscribe(state => {
        console.log("Inside TopicList  ===>", "Store value is ===>", state);
      });
  }

  componentWillUnmount() {
    this.unsubscribe();
  }

  render() {
    const { topics: AllTopics } = this.props;

    if (!AllTopics) {
      return null;
    }

    return (
      <ul className="list-group">
        {AllTopics.map(topic => {
          const { id } = topic;
          return (
            <li key={id} className="list-group-item">
              <Topic data={topic} />
            </li>
          );
        })}
      </ul>
    );
  }
}

const mapStateToProps = state => ({
  topics: state.topics ? [...state.topics] : []
});

const mapDispatchToProps = dispatch => ({
  setTopic: topic => {
    dispatch(setTopicList(topic));
  }
});

export default connect(
  mapDispatchToProps,
  mapStateToProps
)(TopicList);
