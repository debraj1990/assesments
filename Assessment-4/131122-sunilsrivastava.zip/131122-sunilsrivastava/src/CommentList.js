import React, { PureComponent } from "react";
import { connect } from "./Provider";
import { setComments } from "./actions";
import { comments } from "./mockdata";

class CommentList extends PureComponent {
  constructor(props) {
    super(props);
  }

  componentDidMount() {
    this.props.setComment(comments);
    this.unsubscribe = () =>
      this.props.subscribe(state => {
        console.log("Inside CommentList ===>", "Store value is ===>", state);
      });
  }

  componentWillUnmount() {
    this.unsubscribe();
  }

  renderCommnent(comment) {
    const { id, author, message, commentDate } = comment;
    return (
      <div key={id}>
        <hr />
        <h6 className="card-title">{author}</h6>
        <p className="text-small pull-right">{commentDate}</p>
        <p className="card-text">{message}</p>
      </div>
    );
  }

  render() {
    const { commentId, comments: AllComments } = this.props;
    if (commentId && AllComments && AllComments[commentId]) {
      return (
        <div>
          {AllComments[commentId].map((comment, index) => {
            return this.renderCommnent(comment);
          })}
        </div>
      );
    }
    return null;
  }
}

const mapStateToProps = state => ({
  comments: Object.assign({}, state.comments)
});

const mapDispatchToProps = dispatch => ({
  setComment: topic => {
    dispatch(setComments(comments));
  }
});

export default connect(
  mapDispatchToProps,
  mapStateToProps
)(CommentList);
