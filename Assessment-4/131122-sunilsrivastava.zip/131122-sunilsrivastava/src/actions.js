import {PLCACE_ORDER, STATUS} from './constants'

export function dispatchOrder() {
  return { type: PLCACE_ORDER };
}

export function getOrderStatus(status) {
  return {
    type: STATUS,
    status
  };
}
