import { SET_COMMENTS, SET_TOPICS} from './constants'

export function setComments(comments) {
  return {
    type: SET_COMMENTS,
    comments
  };
}

export function setTopicList(topics) {
  return {
    type: SET_TOPICS,
    topics
  };
}
