import typeConstants from '../constants/typeConstants'

const incrementAction = (count = 1) => ({ type: typeConstants.INCREAMENT_COUNT, data: count })
const decrementAction = (count = 1) => ({ type: typeConstants.DECREAMENT_COUNT, data: count })
const changeGreetingAction = (greeting = "MY GREETING") => ({ type: typeConstants.CHANGE_GREETING, data: greeting })


export { incrementAction, decrementAction, changeGreetingAction }