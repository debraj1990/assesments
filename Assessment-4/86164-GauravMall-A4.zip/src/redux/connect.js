import React, { Component } from 'react';
import store from './store';
import PropTypes from 'prop-types';

const connect = (mapStateToProps = null, mapDispatchToProps) => {
	return function (WrappedComponent) {
		let connectHOC = class connectHOC extends Component {
			constructor(props) {
				super(props);
				this.state = {
					storeState: store.getState(),
				}
			}

			componentDidMount() {
				this.unsubscribe = store.subscribe(() => {
					this.setState({
						storeState: store.getState()
					});
				});
			}

			componentWillUnmount(){
				this.unsubscribe();
			}

			render() {
				this.oldProps = typeof mapStateToProps === 'function' ? mapStateToProps(this.state.storeState, this.props) : {};
				const newProps = Object.assign(
					{},
					this.oldProps,
					mapDispatchToProps ? mapDispatchToProps(store.dispatch.bind(this)) : null,
				);
				return <WrappedComponent {...newProps} />
			}
		}
		connectHOC.contextTypes = {
			store: PropTypes.object
		};
		return connectHOC;
	}
};

export {
	connect,
};