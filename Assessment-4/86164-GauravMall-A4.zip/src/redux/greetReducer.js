import typeConstants from '../constants/typeConstants'

const greetReducer = (state = "HELLO DEFAULT", action) => {

    switch (action.type) {
        case typeConstants.CHANGE_GREETING:
            return action.data;
        default:
            return state;
    }
};

export default greetReducer;
