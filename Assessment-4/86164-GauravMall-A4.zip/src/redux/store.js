import { createStore, combineReducers } from './redux'
import countReducer from './countReducer'
import greetReducer from './greetReducer'

const rootReducer = combineReducers({
    greeting: greetReducer,
    counter: countReducer
})

export default createStore(rootReducer)