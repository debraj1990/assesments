// import { createStore, combineReducers } from './store/redux'
// import countReducer from './store/countReducer'
// import greetReducer from './store/greetReducer'
// import { incrementAction, decrementAction, changeGreetingAction } from "./store/Actions"

// const rootReducer = combineReducers({
//   greeting: greetReducer,
//   counter: countReducer
// })

// const store = createStore(rootReducer)
// store.dispatch(incrementAction())
// store.dispatch(incrementAction())
// console.log(store.getState())  // Greeting null & Counter 2
// store.dispatch(incrementAction())
// store.dispatch(incrementAction())
// store.dispatch(changeGreetingAction("SOME GREETING"))  // Greeting "SOME GREETING" & Counter 4
// console.log(store.getState())
// store.dispatch(decrementAction())
// store.dispatch(changeGreetingAction("NEW GREETING"))   // Greeting "NEW GREETING" & Counter 3
// console.log(store.getState())


import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';

ReactDOM.render(<App />, document.getElementById('root'));