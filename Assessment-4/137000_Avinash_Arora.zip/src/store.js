import {createStore, combineReducers} from './redux';
import { topicList, selectedTopic } from './reducer';

export default createStore(combineReducers({
  topicList,
  selectedTopic
}));
