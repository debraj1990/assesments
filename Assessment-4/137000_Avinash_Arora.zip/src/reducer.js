const initialTopicList = {};
export function topicList(state = initialTopicList, action) {
  switch(action.type) {
    case 'ADD_TOPIC':
      return Object.assign(state, {
        [action.topicName]: []
      });
    case 'ADD_COMMENT':
      console.log("----", state);
      if(!state[action.topicName]) {
        console.log("Topic not found");
        return state;
      }
      return Object.assign(state, {
        [action.topicName]: action.commentList
      });
    default:
      return state;
  }
}

// lastAction reducer
const initialSelectedTopic = '';

export function selectedTopic(state = initialSelectedTopic, action) {
  switch(action.type) {
    case 'SET_TOPIC':
      return action.topic;
    default:
      return state;
  }
}
