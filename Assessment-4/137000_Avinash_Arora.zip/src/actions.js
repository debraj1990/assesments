export function addTopic(topicName){
  return {
    type: 'ADD_TOPIC',
    topicName
  };
}

export function addComment(topicName, commentList){
  return {
    type: 'ADD_COMMENT',
    topicName,
    commentList
  };
}

export function selectTopic(topic){
  return {
    type: 'SET_TOPIC',
    topic,
  };
}
