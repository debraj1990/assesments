import React from 'react';
import { connect } from './connect';

class CommentList extends React.PureComponent {
  constructor(props){
    super(props);
  }

  render(){
    const { topics, selectedTopic } = this.props;
    if(!selectedTopic || !topics[selectedTopic]){
      return null;
    }
    const comments = topics[selectedTopic];
    return <div>
        <h2>Comments</h2>
        <ul>{comments.map(comment => <li key={comment}>{comment}</li>)}</ul>
      </div>
  }
}

const mapStateToProps = (state) => ({
  topics: state.topicList,
  selectedTopic: state.selectedTopic,
});


export default connect(mapStateToProps, null)(CommentList);
