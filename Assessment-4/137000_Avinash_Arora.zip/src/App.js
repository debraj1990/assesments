import React from 'react';
import store from './store';
import { addTopic, addComment } from './actions';
import TopicList from './TopicList';
import CommentList from './CommentList';

store.dispatch(addTopic("js"));
store.dispatch(addTopic("java"));

store.dispatch(addComment("js", ["comment 1 for JS", "JS comment 2"]));
store.dispatch(addComment("java", ["comment 1 for java", "java comment 2"]));
store.dispatch(addComment("new topic", ["comment 1 for java", "java comment 2"]));



const App = () => (<React.Fragment>
                      <TopicList />
                      <CommentList />
                    </React.Fragment>);

export default App;
