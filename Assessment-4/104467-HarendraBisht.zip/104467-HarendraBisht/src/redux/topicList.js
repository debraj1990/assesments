export const topicList = [{
	"title": "Javascript",
	"comments": [{
		"title": " Javascript comment 1"
	},{
		"title": "Javascript comment 2"
	},{
		"title": "Javascript comment 3"
	}]
},{
	"title": "HTML",
	"comments": [{
		"title": " HTML comment 1"
	},{
		"title": "HTML comment 2"
	},{
		"title": "HTML comment 3"
	}]
}];