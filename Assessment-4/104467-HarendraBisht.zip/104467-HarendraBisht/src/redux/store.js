import { createStore, combineReducers } from './redux';
import { topicReduer, commentReducer } from './reducer';

const rootReducer = combineReducers({
	topics: topicReduer,
	comments: commentReducer,
})

export default createStore(rootReducer);