import React, { Component } from 'react';
import { connect } from './redux/react-redux';
import {loadComment} from './redux/action';

class TopicList extends Component {
	constructor(){
		super();
		this.handleComment = this.handleComment.bind(this);
	}

	handleComment(comments) {
		const {loadComments} = this.props;
		loadComments(comments);
	}

	render() {
		const { topics } = this.props;
		const topicList = topics.map((topic, idx) => (
			<button
				key={idx}
				type="button"
				className="list-group-item"
				onClick={e => this.handleComment(topic.comments)}>{topic.title}</button>
		));
		return (
			<div className="list-group">
				{topicList}
			</div>
		)
	}
}

const mapStateToProps = (state) => ({ topics: state.topics });

const mapDispatchToProps = dispatch => ({
	loadComments: (comments)=> dispatch(loadComment(comments))
});

export default connect(mapStateToProps, mapDispatchToProps)(TopicList);