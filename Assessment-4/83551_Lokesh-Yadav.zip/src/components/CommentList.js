import React, {Component} from 'react';
import {connect} from '../redux/connect';

class CommentList extends Component {
	constructor(props) {
		super(props);
		this.unsubscribe = null;
	}
	componentDidMount() {
		this.unsubscribe = this.props.subscribe(state => {});
	}

	componentWillUnmount() {
		this.unsubscribe();
	}

	render() {
		const {topics, selectedTopic} = this.props;
		if (!selectedTopic || !topics[selectedTopic]) {
			return (
				<div className='container'>
					<div className='alert alert-warning'>Please choose one of the topic from above list to check the comments</div>
				</div>
			);
		}
		const comments = topics[selectedTopic];
		return (
			<div className='container'>
				{comments.map(comment => (
					<div className='alert alert-info' key={comment}>
						{comment}
					</div>
				))}
			</div>
		);
	}
}

const mapStateToProps = state => ({
	topics: state.topicList,
	selectedTopic: state.selectedTopic
});

export default connect(
	null,
	mapStateToProps
)(CommentList);
