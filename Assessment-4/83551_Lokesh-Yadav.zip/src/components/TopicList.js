import React, {Component} from 'react';
import {connect} from '../redux/connect';
import {selectTopic} from '../redux/action/action';

class TopicList extends Component {
	constructor(props) {
		super(props);
		this.unsubscribe = null;
		this.state = {
			selectedTopic: ''
		};
	}
	componentDidMount() {
		this.unsubscribe = this.props.subscribe(state => {});
	}

	componentWillUnmount() {
		this.unsubscribe();
	}

	handleTopic(topic) {
		this.setState(
			{
				selectedTopic: topic
			},
			() => {
				this.props.setTopic(topic);
			}
		);
	}

	render() {
		const {topics} = this.props || [];

		return (
			<div className='container'>
				<hr />
				<h4>Choose Your Topic</h4>
				<hr />
				<ul className='m-0 p-0'>
					{topics.map(topic => (
						<button
							className='btn btn-primary mr-3'
							key={topic}
							onClick={() => {
								this.handleTopic(topic);
							}}>
							{topic}
						</button>
					))}
				</ul>
				<hr />
				<h4>Comments:</h4>
				<hr />
			</div>
		);
	}
}

const mapStateToProps = state => ({
	topics: Object.keys(state.topicList)
});

const mapDispatchToProps = dispatch => ({
	setTopic: topic => {
		dispatch(selectTopic(topic));
	}
});

export default connect(
	mapDispatchToProps,
	mapStateToProps
)(TopicList);
