import React from 'react';
import {createStore, combineReducers} from './redux/redux';
import {topicList, selectedTopic} from './redux/reducer/reducer';
import {addTopic} from './redux/action/action';
import {Provider} from './redux/connect';
import TopicList from './components/TopicList';
import CommentList from './components/CommentList';

const store = createStore(
	combineReducers({
		topicList,
		selectedTopic
	})
);

store.dispatch(
	addTopic('Java', [
		'Java is a general-purpose computer-programming language that is concurrent, class-based, object-oriented, and specifically designed to have as few implementation dependencies as possible.'
	])
);
store.dispatch(addTopic('JavaScript', ['JS, is a high-level, interpreted programming language that conforms to the ECMAScript specification. ']));

store.dispatch(
	addTopic('React', [
		'React is a JavaScript library for building user interfaces. It is maintained by Facebook and a community of individual developers and companies. React can be used as a base in the development of single-page or mobile applications.'
	])
);

store.dispatch(
	addTopic('Angular', [
		'AngularJS is a JavaScript-based open-source front-end web framework mainly maintained by Google and by a community of individuals and corporations to address many of the challenges encountered in developing single-page applications. '
	])
);

const App = () => (
	<Provider store={store}>
		<TopicList />
		<CommentList />
	</Provider>
);

export default App;
