import React from 'react';

const Counter = (props) => {
	const {counter, increment, decrement} = props;
	return(
		<div className="counter">
            <h4>Counter Actions</h4>
            <button className="btn" onClick={decrement}>-</button>
            <button className="btn" onClick={increment}>+</button>
            <h4 className="badge">{`Current counter is: ${counter}`}</h4>
        </div>
	);
}


export default Counter;
