import React from 'react';


const Greeting = (props) => {
	const {greeting, changeGreeting} = props;
	return(
		<div className="greeting">
            <input id="greetingInput" type="text"></input>
            <button className="btn" onClick={() => {
                const greet = document.getElementById("greetingInput").value
                changeGreeting(greet)
            }}>Submit</button>
            <h4>{`My greeting says : ${greeting}`}</h4>
        </div>
	);
}


export default Greeting;
