import React, { Component } from 'react';
import { connect } from './redux/connect';
import Counter from './components/counter'
import Greeting from './components/greeting'
import { incrementAction, decrementAction, changeGreetingAction } from './redux/actions';

class App extends Component {
	constructor(){
		super();
	}
	render() {
		const { counter, greeting, decrement, increment, changeGreeting } = this.props;
		return (
			<div className="app">
				<h1>Counter Component</h1>
				<Counter 
					increment={increment} 
					decrement={decrement}
					counter={counter}
				/>
				<hr></hr>
				<h2>Greeting Component</h2>
				<Greeting 
					changeGreeting={changeGreeting} 
					greeting={greeting}
				/>
			</div>
		)
	}
}

const mapStateToProps = (state) => ({ 
	counter: state.counter,
	greeting: state.greeting
 });

const mapDispatchToProps = dispatch => ({
	increment: () => dispatch(incrementAction()),
	decrement: () => dispatch(decrementAction()),
	changeGreeting: (greet) => dispatch(changeGreetingAction(greet))
});

export default connect(mapStateToProps, mapDispatchToProps)(App);