export const topics = [
  {
    name: "Java",
    id: 1
  },
  {
    name: "JavaScript",
    id: 2
  },
  {
    name: "Ruby",
    id: 3
  }
];

export const comments = [
  {
    topicId: 1,
    list: [
      "This is first comment",
      "This is first comment ",
      "This is first comment"
    ]
  },
  {
    topicId: 2,
    list: [
      "This is second comment",
      "This is second comment",
      "This is second comment"
    ]
  },
  {
    topicId: 3,
    list: [
      "This is third comment",
      "This is third comment",
      "This is third comment"
    ]
  }
];
