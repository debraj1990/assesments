import React from "react";
import { loadTopics } from "../actions/topic";
import { loadComments } from "../actions/comment";
import { connect } from "react-redux";

class TopicList extends React.Component {
  componentDidMount() {
    this.props.loadTopics();
  }

  onHandleClick = e => {
    e.preventDefault();
    const topicId = parseInt(e.target.id);
    this.props.loadComments(topicId);
  };

  render() {
    const { topics, activeId } = this.props;
    return (
      <ul className="nav nav-tabs">
        {topics && activeId
          ? topics.map(topic => {
              return (
                <li key={topic.id} className="nav-item">
                  <a
                    href="#"
                    onClick={this.onHandleClick}
                    id={topic.id}
                    className={`nav-link ${
                      activeId.topicId === topic.id ? "active" : ""
                    }`}
                  >
                    {topic.name}
                  </a>
                </li>
              );
            })
          : null}
      </ul>
    );
  }
}

const mapStateToProps = state => ({
  topics: state.topics,
  activeId: state.comments
});

const mapDispatchToProps = dispatch => ({
  loadTopics: () => dispatch(loadTopics()),
  loadComments: id => dispatch(loadComments(id))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(TopicList);
