import React from "react";
import { loadComments } from "../actions/comment";
import { connect } from "react-redux";

class CommentList extends React.Component {
  componentDidMount() {
    this.props.loadComments(1);
  }

  render() {
    const { comments } = this.props;
    return (
      <div className="tab-content mt-3">
        <div className="tab-pane active" role="tabpanel">
          <ol>
            {comments.list
              ? comments.list.map((comment, idx) => (
                  <li key={idx}>{comment}</li>
                ))
              : ""}
          </ol>
        </div>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  comments: state.comments
});

const dispatchToProps = dispatch => ({
  loadComments: id => dispatch(loadComments(id))
});

export default connect(
  mapStateToProps,
  dispatchToProps
)(CommentList);
