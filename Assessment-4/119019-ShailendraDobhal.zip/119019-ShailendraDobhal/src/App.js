import React, { Component } from "react";
import Comment from "./component/CommentList";
import Topic from "./component/TopicList";

class App extends Component {
  render() {
    return (
      <div className="mt-5 ml-5">
        <Topic />
        <Comment />
      </div>
    );
  }
}

export default App;
