import { comments } from "../data";

export const LOAD_COMMENT = "LOAD_COMMENT";

export const loadComments = id => ({
  type: LOAD_COMMENT,
  comments: comments.find(comment => comment.topicId === id)
});
