import { topics } from "../data";

export const RECIEVE_TOPIC = "RECIEVE_TOPIC";

export const loadTopics = () => ({
  type: RECIEVE_TOPIC,
  topics: topics
});
