import { combineReducers } from "../redux";
import topics from "./topic";
import comments from "./comment";

export default combineReducers({
  topics,
  comments
});
