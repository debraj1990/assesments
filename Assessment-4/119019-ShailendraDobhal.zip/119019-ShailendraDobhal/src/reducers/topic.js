import { RECIEVE_TOPIC } from "../actions/topic";

export default function topics(state = [], action) {
  switch (action.type) {
    case RECIEVE_TOPIC:
      return action.topics;
    default:
      return state;
  }
}
