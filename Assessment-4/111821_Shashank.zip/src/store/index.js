import { createStore } from '../reduxlib';
import rootReducer from '../reducers/rootReducer'

let initialState = {
  topics: [],
  comments: []
}

export default createStore(rootReducer, initialState);