import React, { Component } from 'react'
import { loadComments } from '../actions/comments'
import CommentList from './CommentList'
import { connect } from '../reduxlib/react-redux'
import { bindActionCreators } from '../reduxlib'

class Topic extends Component {
  constructor(props) {
    super(props);
  }
  handleClick(topicId) {
    console.log('topicId = ', topicId);
    let { actions } = this.props;
    actions.loadComments(topicId);

  }
  render() {
    let { topic, comments } = this.props;
    return (
      <div>
        <h2 onClick={(e) => this.handleClick(topic.id)}>{topic.title}</h2>
        {comments ? <CommentList comments={comments} ref={topic.id}></CommentList> : ''}
      </div>
    )
  }
}
const mapStateToProps = (state, ownProps) => ({
  comments: state.comments
})

const mapDispatchToProps = dispatch => ({
  // ... normally is an object full of action creators
  actions: bindActionCreators({ loadComments }, dispatch)
})
export default connect(mapStateToProps, mapDispatchToProps)(Topic);
