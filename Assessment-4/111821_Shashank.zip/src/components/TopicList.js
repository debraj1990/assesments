import React, { Component } from 'react'
import Topic from './Topic';
import { loadTopics } from '../actions/topics'

import { connect } from '../reduxlib/react-redux'
import { bindActionCreators } from '../reduxlib'

class TopicList extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    let { actions } = this.props;
    actions.loadTopics();
  }
  renderTopics() {
    let { topics } = this.props;
    window.topics = topics;
    return topics.map((val, idx) => {
      return (<Topic topic={val} key={idx} ></Topic>)
    })
  }
  render() {
    return (
      <div>
        {this.renderTopics()}
      </div>
    )
  }
}
const mapStateToProps = (state, ownProps) => ({
  topics: state.topics
})

const mapDispatchToProps = dispatch => ({
  // ... normally is an object full of action creators
  actions: bindActionCreators({ loadTopics }, dispatch)
})
export default connect(mapStateToProps, mapDispatchToProps)(TopicList);