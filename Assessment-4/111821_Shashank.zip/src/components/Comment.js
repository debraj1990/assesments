import React, { Component } from 'react'

class Comment extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    let { comment } = this.props;
    return (
      <div>
        <h3>{comment.comment}</h3>
      </div>
    )
  }
}

export default Comment;