import React, { Component } from 'react'
import Comment from './Comment';
class CommentList extends Component {
  constructor(props) {
    super(props);

  }
  renderTopics() {
    let { comments } = this.props;
    return comments.map((val, idx) => {
      return <Comment comment={val} key={idx} ></Comment>
    })
  }
  render() {
    return (
      <div>
        {this.renderTopics()}
      </div>
    )
  }
}

export default CommentList;