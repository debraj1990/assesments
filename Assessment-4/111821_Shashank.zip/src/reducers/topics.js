
import { LOAD_TOPICS } from '../constants'

export function topicsReducer(state = [], action) {
    console.log("-topics-reducer-");
    switch (action.type) {
        case LOAD_TOPICS: {
            let { topics } = action
            return [...state, ...topics]
        }
        default:
            return state;
    }
}