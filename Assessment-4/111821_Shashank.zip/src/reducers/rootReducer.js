


import { topicsReducer } from './topics'
import { commentsReducer } from './comments'
import combineReducers from '../reduxlib/combineReducers'


const rootReducer = combineReducers({
    topics: topicsReducer,
    comments: commentsReducer,
});


export default rootReducer;

