export default function combineReducers(reducers) {

    return function (state = {}, action) {
        let newState = Object.assign({}, state);
        for (var key in reducers) {
            const reducer = reducers[key];
            newState[key] = reducer(state[key], action)
        }
        return newState
    }
}