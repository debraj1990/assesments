import React, { Component } from 'react';
import store from '../store';
//This is the Higher Order Component
export default function myConnect(mapStateToPropsFunc) {
  return function (WrappedComp) {
    var myHOC = class HOC extends Component {
      render() {
        //Now we access redux store using react context api as it will be passed by MyProvider automatically to all child components
        let myStore;
        if (this.context && this.context.store) {
          myStore = this.context.store.getState();
        } else {
          myStore = null;
        }
        //mapStateToPropsFunc is just used to structure the props required by the component so we pass to mapStateToPropsFunc the whole store and then it returns a mapped object with required props thats why it is well known by mapStateToProps
        var storeToBePassed = mapStateToPropsFunc(myStore);
        return (
          //We pass the result from executing mapStateToPropsFunc to the wrapped component and this is how the components get passed props from redux store
          <WrappedComp {...storeToBePassed} />
        )
      }
    }

    //We need to define contextTypes otherwise context will be empty
    // myHOC.contextTypes = {
    //   store: PropTypes.object
    // };

    //return new component that has access to redux store as props mapped using mapStateToProps function
    return myHOC;
  }
}