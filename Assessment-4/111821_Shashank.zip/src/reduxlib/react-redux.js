import React, { Component } from 'react';
const storeContext = React.createContext();

class Provider extends Component {
  constructor(props) {
    super(props);
    const { store } = props
    this.state = {
      store: props,
      storeState: store.getState()
    }
  }

  componentDidMount() {
    let { store } = this.props;
    this.unsubscribe = store.subscribe(() => {
      this.setState({
        storeState: store.getState()
      });
    });
  }

  componentWillUnmount() {
    this.unsubscribe();
  }

  render() {
    let { store } = this.state;
    return (
      <storeContext.Provider value={this.state}>
        {this.props.children}
      </storeContext.Provider>
    );
  }
}

const connect = (mapStateToPropsFunc, mapDispatchToPropsFunc) => {
  console.log("testing react-redux-lib");
  //console.log(store);
  return function (WrappedComp) {
    let HOC = class HOC extends Component {
      render() {

        let { store } = this.context.store,
          storeState = store.getState(),
          mapStateToProps = typeof mapStateToPropsFunc === 'function' ? mapStateToPropsFunc(storeState, this.props) : {},
          mapDispatchToProps = typeof mapDispatchToPropsFunc === 'function' ? mapDispatchToPropsFunc(store.dispatch) : {};
        const mergedProps = Object.assign(
          {},
          mapStateToProps,
          mapDispatchToProps
        );
        return <WrappedComp {...mergedProps} />
      }
    }
    HOC.contextType = storeContext;
    return HOC;
  }
}

export { Provider, connect };