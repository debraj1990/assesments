import React, { Component } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.css'
import 'font-awesome/css/font-awesome.css'

import TopicList from './components/TopicList';





class App extends Component {

  render() {

    return (
      <TopicList></TopicList>
    );
  }
}




export default App;
