import { LOAD_TOPICS } from '../constants'

const loadTopics = () => {
    let topics = [
        { id: 1, title: "JS" },
        { id: 2, title: "React" },
        { id: 3, title: "Angular" }
    ]

    return { type: LOAD_TOPICS, topics: topics }
}

export { loadTopics }