import { LOAD_COMMENTS } from '../constants'

const loadComments = (topicId) => {
    let comments = [
        { id: 1, topicId: 1, comment: "Nice JS" },
        { id: 2, topicId: 2, comment: "Nice React" },
        { id: 3, topicId: 3, comment: "Nice Angular" }
    ]

    let relComments = comments.filter((o) => o.topicId === topicId)


    return { type: LOAD_COMMENTS, comments: relComments }
}

export { loadComments }