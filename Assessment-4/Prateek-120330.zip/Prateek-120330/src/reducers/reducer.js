import {LOAD_TOPICS, LOAD_COMMENTS} from '../constants';

const topicReduer = (state=[], action) => {
	switch(action.type) {
		case LOAD_TOPICS:
			return [...state, ...action.data];
		default:
			return state;
	}
};

const commentReducer = (state=[], action) => {
	switch(action.type) {
		case LOAD_COMMENTS:
			return [ ...action.data];
		default:
			return state;
	}
}

export {
	topicReduer,
	commentReducer
}