import React, { Component } from 'react';
import { connect } from '../redux/react-redux';
import {loadComment} from '../actions/comment';

class TopicList extends Component {
	
	handleComment(id) {
		const {loadComments} = this.props;
		loadComments(id);
	}

	render() {
		const { topics } = this.props;
		const topicList = topics.map((topic, idx) => (
			<span
				key={idx}
				type="button"
				className="list-group-item"
				onClick={e => this.handleComment(topic.id)}>{topic.title}</span>
		));
		return (
			<div className="w-75 mx-auto">
				<h4 className="text-center">Topic</h4>
				<div className="list-group">
					{topicList}
				</div>
			</div>
		)
	}
}

const mapStateToProps = (state) => ({ topics: state.topics });

const mapDispatchToProps = dispatch => ({
	loadComments: (comments)=> dispatch(loadComment(comments))
});

export default connect(mapStateToProps, mapDispatchToProps)(TopicList);