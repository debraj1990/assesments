import React from 'react';
import { connect } from '../redux/react-redux';

const Comment = (props) => {
	const {comments} = props;

	const commentList = comments.map((comment, id)=>(
		<li key={id} className="list-group-item">{comment.description}</li>
	));
	
	return(
		<div className="w-75 mx-auto mt-4">
			<h4 className="text-center">Comments</h4>
			<div className="list-group">
				{commentList}
			</div>
		</div>
	);
}

const mapStateToProps = (state)=>({comments: state.comments});

export default connect(mapStateToProps, null)(Comment);
