import {LOAD_TOPICS} from '../constants';

export const loadTopic = () => {
    let topics = [
        { id: 1, title: "React" },
        { id: 2, title: "Vue" },
        { id: 3, title: "Javascript" },
        { id: 4, title: "SASS" }
    ]
    return { type: LOAD_TOPICS, data: topics }
}