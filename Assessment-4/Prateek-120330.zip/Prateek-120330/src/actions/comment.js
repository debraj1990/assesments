import {LOAD_COMMENTS} from '../constants';

export const loadComment = (id) => {
    let comments = [
        { id: 1, topicId: 1, description: "React 01" },
        { id: 2, topicId: 1, description: "React 02" },
        { id: 3, topicId: 2, description: "Vue " },
        { id: 4, topicId: 3, description: "Sass 01" },
        { id: 5, topicId: 3, description: "Sass 02" }
    ]

    let filteredComments = comments.filter(function(comment){
        if (comment.topicId === id) {
            return true;
        }
        return false;
    });

    return { type: LOAD_COMMENTS, data: filteredComments }
}