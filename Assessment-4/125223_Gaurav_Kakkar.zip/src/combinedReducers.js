import { createStore, combineReducers } from "./store/redux";

import { topicList, activeTopic } from "./components/TopicList/reducer";
import { commentList } from "./components/CommentList/reducer";

const store = createStore(
  combineReducers({
    activeTopic,
    topicList,
    commentList
  })
);

export default store;
