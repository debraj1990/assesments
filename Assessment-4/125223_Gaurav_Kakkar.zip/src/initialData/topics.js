export const dummyTopics = [
  {
    id: 1,
    title: "HTML"
  },
  {
    id: 2,
    title: "CSS"
  },
  {
    id: 3,
    title: "javaScript"
  }
];

export const dummyComments = [
  {
    topicId: 1,
    comments: [
      "HTML is easy.",
      "Powerful than what you think",
      "Hello From HTML",
      "World is great"
    ]
  },
  {
    topicId: 2,
    comments: [
      "CSS adds life to your pages.",
      "Styling is easy",
      "Are you really compiling this?"
    ]
  },
  {
    topicId: 3,
    comments: [
      "World is changing, JS is the new King.",
      "JS controls your DOM",
      "there is improvemrnt",
      "I want more"
    ]
  }
];

export default { dummyTopics, dummyComments };
