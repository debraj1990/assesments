import React from "react";
import { Provider } from "./store/connect";
import store from "./combinedReducers";

import { loadTopics } from "./components/TopicList/actions";
import { loadComments } from "./components/CommentList/actions";
import { dummyTopics, dummyComments } from "./initialData/topics";

import TopicList from "./components/TopicList/TopicList";
import CommentList from "./components/CommentList/CommentList";

store.dispatch(loadTopics(dummyTopics));
store.dispatch(loadComments(dummyComments));

const App = () => (
  <Provider store={store}>
    <div className="container">
      <div className="row">
        <h3 className="p-3">Assignment 4 - Topics and comment list</h3>
      </div>
      <div className="row">
        <div className="col-md-6">
          <TopicList />
        </div>
        <div className="col-md-6">
          <CommentList />
        </div>
      </div>
    </div>
  </Provider>
);

export default App;
