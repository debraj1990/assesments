export function loadComments(comments) {
  return {
    type: "LOAD_COMMENTS",
    comments
  };
}

