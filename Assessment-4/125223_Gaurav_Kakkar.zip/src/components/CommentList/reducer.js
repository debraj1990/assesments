
export function commentList(state = [], {type, comments}) {
  switch(type) {
    case 'LOAD_COMMENTS':
      return Object.assign(state, {
        ...comments
      });
    default:
      return state;
  }
}