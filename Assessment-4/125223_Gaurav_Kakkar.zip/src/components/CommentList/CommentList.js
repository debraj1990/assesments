import React from "react";
import { connect } from "./../../store/connect";

class CommentList extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  render() {
	const { commentList, activeTopic } = this.props;
	
	if(!activeTopic) return null;	
	const commentObject = commentList.find(comment => comment.topicId === activeTopic);
	
	if(!commentObject || !commentObject.comments.length) return null;
	
    return (
      <div className="border p-3">
        <h4>Comments</h4>
        <small>(Comments on topics)</small>
        <ul className="list-group mt-3 mb-3">
          {commentObject.comments.map(comment => (
            <li className="list-group-item" key={comment}>
              {comment}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

const mapStateToProps = state => ({
	activeTopic: state.activeTopic,
	commentList: state.commentList
});

export default connect(
  null,
  mapStateToProps
)(CommentList);
