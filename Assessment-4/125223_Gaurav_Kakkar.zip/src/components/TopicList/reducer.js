export function activeTopic(state = null, { type, activeTopic }) {
  switch (type) {
    case "ACTIVE_TOPIC":
      return activeTopic;
    default:
      return state;
  }
}

export function topicList(state = [], { type, topics }) {
  switch (type) {
    case "LOAD_TOPICS":
      return Object.assign(state, {
        ...topics
      });
    default:
      return state;
  }
}
