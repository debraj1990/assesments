

export function activeTopic(activeTopic){
  return {
    type: 'ACTIVE_TOPIC',
    activeTopic,
  };
}

export function loadTopics(topics){
  return {
    type: 'LOAD_TOPICS',
    topics
  };
}
