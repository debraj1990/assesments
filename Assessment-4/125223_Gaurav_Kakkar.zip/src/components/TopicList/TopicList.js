import React from "react";
import { connect } from "./../../store/connect";
import { activeTopic } from "./actions";

class TopicList extends React.PureComponent {
  constructor(props) {
    super(props);
  }

  loadComments(id) {
    this.props.activeTopic(id);
  }

  render() {
    const { topics } = this.props;
    if (!topics) {
      return null;
    }
    return (
      <div className="border p-3">
        <h4>Topics</h4>
        <small>(Click Topics to see comments)</small>
        <ul className="list-group mt-3 mb-3">
          {topics.map(topic => (
            <li
              className="list-group-item"
              key={topic.id}
              onClick={() => {
                this.loadComments(topic.id);
              }}
            >
              {topic.title}
            </li>
          ))}
        </ul>
      </div>
    );
  }
}

const mapStateToProps = state => ({ topics: state.topicList });

const mapDispatchToProps = dispatch => ({
  activeTopic: topicId => {
    dispatch(activeTopic(topicId));
  }
});

export default connect(
  mapDispatchToProps,
  mapStateToProps
)(TopicList);
