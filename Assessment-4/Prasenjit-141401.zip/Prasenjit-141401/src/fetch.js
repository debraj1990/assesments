import React from "react";
import { getState } from "./store";
import { users } from "./thunks";


function Loading() {
  return <h1 style={{ color: "red" }}>Loading</h1>;
}

class FetchData extends React.Component {
  

  render() {
    return (
      <div>
       
      </div>
    );
  }
}

export default FetchData;
