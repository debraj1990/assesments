const initialState = {
    num: 0,
    topicid:1,
    topics: [{
                "topicid":1,
                "title": "React"
            },{
                "topicid":2,
                "title": "Node"
            }],
    comments: [{
                "topicid":1,
                "comment": " React comment 1"
            },{
                "topicid":1,
                "comment": "React comment 2"
            },{
                "topicid":1,
                "comment": "React comment 3"
            },{
                "topicid":2,
                "comment": " Node comment 1"
            },{
                "topicid":2,
                "comment": "Node comment 2"
            },{
                "topicid":2,
                "comment": "Node comment 3"
            }]

}
function reducer(action, state =initialState ) {
    switch (action.type) {
        case "INC":
            return {
                ...state,
                num: state.num + 1
            };
        case "DEC":
            return {
                ...state,
                num: state.num - 1
            };
        case "UPDATE_TOPICID":
        return {
            ...state,
            topicid: action.topicid
        };

        case "GET_TOPIC":
            return {
                ...state,
                topics: action.topics
            };
        case 'GET_COMMENT':
            let { topicid } = action;
            let existingComments = state.topic[topicid] || [];
            let comments = [...existingComments];
            return {
                ...state,
                comments:comments
           }
        default:
            return state;
    }
}



export {reducer}