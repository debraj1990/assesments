import React from 'react';
import { getState, dispatch } from './store'
//import { connect } from './react-redux';
import CommentList from './commentList';

class Topiclist extends React.Component {
    handleTopic(tid) {
        let { topicid } = getState();
        getState().topicid=tid;
    }
    changeTab(tabIndex) {
        this.setState({ currentTab: tabIndex }, () => {
            if (tabIndex === 3) {
                let { item, actions } = this.props;
                actions.loadReviews(item.id)
            }
        })
    }
    renderComments() {
        let { comments, topicid } = getState();
        let panel;
        if (comments.length === 0)
            panel=( <span>No Comment</span>);
            
        else{
            panel=( 
                comments.map((item, idx) => {
                    if(item.topicid==topicid)
                    return <CommentList key={idx} item={item} />
                })
            )
            return panel;
        }
    }
    render() {
        return (
            <div>
                <ul>
                    {getState().topics.map((topic,idx) =>
                        <li key={idx}><button type="button" onClick={e=>this.handleTopic(topic.topicid)}>{topic.title}</button>
                        </li>
                    )}
                    {this.renderComments()}
                </ul>
                
            </div>
        )

    }
}


export default Topiclist;