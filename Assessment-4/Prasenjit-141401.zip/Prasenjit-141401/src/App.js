import React, { Component } from "react";
import Text from "./text";
import FetchData from "./fetch";
import Topiclist from "./topicList";
import { getState } from "./store";

class App extends Component {
  render() {
    return (
      <div className="App">
        <h3>Topic List</h3>
        <hr />
        <Topiclist/>
      </div>
    );
  }
}

export default App;
