
import React from 'react';

export default ({ item }) => {
    return (
        <div className="row">
            <div className="col-8 col-sm-12 col-md-12">
                <div className="alert alert-info">
                    <p><span>{item.comment}</span></p>
                    <hr />
                </div>
            </div>
        </div>
    )
};