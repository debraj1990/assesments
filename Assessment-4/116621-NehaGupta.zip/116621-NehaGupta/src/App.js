import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import TopicList from './components/TopicList';
import CommentsList from './components/CommentsList';

class App extends Component {
  render() {
    return (
      <div className="App">
        <TopicList />
        <CommentsList />
      </div>
    );
  }
}

export default App;
