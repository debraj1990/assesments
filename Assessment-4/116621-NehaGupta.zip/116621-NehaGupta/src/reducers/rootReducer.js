
import { topicsReducer } from './topics'
import { commentsReducer } from './comments'
import combineReducers from '../redux-lib/src/combineReducers'


const rootReducer = combineReducers({

    topics: topicsReducer,
    comments: commentsReducer
});


export default rootReducer;

