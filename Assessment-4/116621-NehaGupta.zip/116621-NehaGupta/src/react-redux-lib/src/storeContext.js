import React, { Component } from 'react';

const storeContext = React.createContext();

export default storeContext;