import { createStore } from '../redux-lib/src';
import rootReducer from '../reducers/rootReducer'

let initialState = {
    topics: [],
    comments: []
}

export default createStore(rootReducer, initialState);