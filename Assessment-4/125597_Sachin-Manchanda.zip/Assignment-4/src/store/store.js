import { createStore, combineReducers } from '../redux/redux';
import { topicReduer, commentReducer } from '../reducers/reducer';

const rootReducer = combineReducers({
	topics: topicReduer,
	comments: commentReducer,
})

export default createStore(rootReducer);