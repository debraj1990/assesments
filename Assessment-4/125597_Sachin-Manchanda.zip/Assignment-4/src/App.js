import React, { Component } from 'react';
import {connect} from './redux/react-redux';
import TopicList from './components/TopicList';
import Comment from './components/Comment';
import { loadTopic } from './actions/topic';
import 'bootstrap/dist/css/bootstrap.css';

class App extends Component {
  componentDidMount() {
    const {loadTopics} = this.props;
    loadTopics();
  }
  render() {
    return (
      <div>
        <TopicList />
        <Comment />
      </div>
    );
  }
}
const mapDispatchToProps = dispatch => ({
  loadTopics: (list) => dispatch(loadTopic(list))
});

export default connect(null, mapDispatchToProps)(App);
