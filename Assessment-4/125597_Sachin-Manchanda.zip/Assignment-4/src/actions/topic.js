import {LOAD_TOPICS} from '../constants';

export const loadTopic = () => {
    let topics = [
        { id: 1, title: "React" },
        { id: 2, title: "Angular" },
        { id: 3, title: "HTML" },
        { id: 4, title: "CSS" }
    ]
    return { type: LOAD_TOPICS, data: topics }
}