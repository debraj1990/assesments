import {LOAD_COMMENTS} from '../constants';

export const loadComment = (id) => {
    let comments = [
        { id: 1, topicId: 1, description: "React comment -1" },
        { id: 2, topicId: 1, description: "React comment -2" },
        { id: 3, topicId: 2, description: "Angular comment -1" },
        { id: 4, topicId: 3, description: "HTML comment -1" },
        { id: 5, topicId: 3, description: "HTML comment -2" }
    ]

    let filteredComments = comments.filter(function(comment){
        if (comment.topicId === id) {
            return true;
        }
        return false;
    });

    return { type: LOAD_COMMENTS, data: filteredComments }
}