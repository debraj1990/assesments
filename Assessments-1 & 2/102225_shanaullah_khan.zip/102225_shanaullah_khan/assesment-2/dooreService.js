
/*===================================================
	Door service 
	
	Observer Pattern

=================================================== */

class Door {
	constructor(num) {
		this.num = num;
		this.listeners = [];
	}

	notifyAll(data) {
		this.listeners.forEach(listener => listener(data));
	}

	open() {
		console.log("door is opened");
		let event = { num: this.num, type: 'open' };
		this.notifyAll(event);
	}

	close() {
		console.log("door is closed");
		let event = { num: this.num, type: 'close' };
		this.notifyAll(event)
	}

	subscribe(fn) {
		this.listeners.push(fn);
	}

	unSubscribe(fn) {
		this.listeners = this.listeners.filter(el => el !== fn);
	}

}

class Room {

	light(event) {
		if (event.type === "open") {
			console.log(`Light is turned On, door number :${event.num}`);
		}
		
        if (event.type === "close") {
         	console.log(`Light is turned Off, door number :${event.num}`);
        }
	}


	fan(event) {
		if (event.type === "open") {
			console.log(`Fan is turned On, door number :${event.num}`);
		}
		
        if (event.type === "close") {
         	console.log(`Fan is turned Off, door number :${event.num}`);
        }
	}

}




let door = new Door(101);
let room = new Room();

door.subscribe(room.light);
door.subscribe(room.fan);


door.open();
//door.unSubscribe(room.fan);

door.unSubscribe(room.light);
setTimeout(() => {
	door.close();
}, 5000);

