/*===================================================


Requirement

Music Player  = ( give me  a ‘name’ to this pattern )

Song => {title :string , duration: number}

Create list of songs, and getNextSong() function which can return next song based user sceduling strategy

Strategies
•	SDNS => shortest duration next song
•	LDNS => longest duration next song
•	FINS => first in next song

Condition: getSongNong() must be polymophic, strategy function must be parameter


=================================================== */



class MusicPlayer {
	constructor() {
		this.songs = [];
		this.currentIndex = 0;
	}
	
	addToPlayList(name, duration) {
		this.songs.push({name, duration});
	}
	getNextSong(){
		console.log(`super next song`);
		return (this.currentIndex == this.songs.length-1)?this.songs[this.currentIndex+1]:this.songs[0];
	}
	
}

class Strategy extends MusicPlayer {
    constructor () {
        super();
    }
	 
    getNextSong(option){
		console.log(`get next song ${option}`);
		
            if( option == 'SDNS') {
				console.log('SDNS');
                this.songs = this.songs.sort((a, b) => (a['duration'] < b['duration'] ? -1 : 1));
            }
            else if(option == 'LDNS') {
				console.log('LDNS');
                this.songs = this.songs.sort((a, b) => (a['duration'] > b['duration'] ? -1 : 1));
            }
            else{
				console.log('FINS');
				(this.currentIndex === this.songs.length-1)?this.currentIndex = 0:this.currentIndex += 1;
			}
		
            return this.songs[this.currentIndex];
    }
}

//const musicPlayer = new MusicPlayer();
const myPlayer = new Strategy();

myPlayer.addToPlayList('My Song 200', 200);
myPlayer.addToPlayList('My Song 100', 100);
myPlayer.addToPlayList('My Song 500', 500);
myPlayer.addToPlayList('My Song 400', 400);
myPlayer.addToPlayList('My Song 300', 300);

//console.log(myPlayer.getNextSong());

console.log(myPlayer.getNextSong('LDNS'));
//console.log(myPlayer.getNextSong());
//console.log(myPlayer.getNextSong('FINS'));
//console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong('SDNS'));
//console.log(myPlayer.getNextSong());


console.log(myPlayer.getNextSong());






