/*===================================================
	Appoint Vendor
=================================================== */

let mostWantedService = require('./most-wanted');


let appointVendor= (callback, data) => {
		console.log("Before service call");
		let startTime = new Date().getTime();
		try {
			console.log("Try block");
			callback(data);
		} catch (e) {
			console.log("Error caught - " + e.message);
		}
		let endTime = new Date().getTime();
		let totalTime = endTime - startTime;
		console.log(`After service call`);
		console.log(`total execution time ${totalTime}`);

}

//success call
appointVendor(mostWantedService, "One");

//Error call
appointVendor(mostWantedService);