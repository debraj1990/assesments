/*===================================================
	Non-unique Elements in an array
=================================================== */

let nonUniqueElements = (arr) => {
    return arr.filter(value => {
		return arr.indexOf(value) !== arr.lastIndexOf(value);
	});
}

nonUniqueElements([1, 2, 3, 4, 3, 7, 1, 8, 9, 9]);

