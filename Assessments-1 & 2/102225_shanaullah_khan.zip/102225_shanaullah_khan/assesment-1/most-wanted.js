/*===================================================
	The Most Wanted Letter
	
	The most frequent letter in lower case as a string.
	Example

=================================================== */


let mostWanted = (str) => {
    var count = 0,
        letter = '',
        x = 0;
    str = str.replace(/[^a-zA-Z]/g, '');
    let strArr = str.toLocaleLowerCase().split('').sort();

    for (let i = 0; i < strArr.length; i++) {
        x = str.match(new RegExp(strArr[i], 'gi')).length;
        if (strArr[i] !== letter && x > count) {
            letter = strArr[i];
            count = x;
        }
    }
    return letter;
}

//mostWanted("All is Well");

module.exports = mostWanted;

