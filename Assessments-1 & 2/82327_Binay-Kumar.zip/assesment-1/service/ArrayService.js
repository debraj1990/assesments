/**
Common service file used by 1-non-unique-elements and 2-most-wanted-letter
 */
class ArrayService {
    /**
    * @method nonUniqueElements - It filters non unique array items based on count; if count is more than 1 then its not unique 
    * @param {array}
    * @return {array} - Array of non unique items from array
    */
    nonUniqueElements(arrayInput) {
        let map = new Map();
        //count values for each 
        arrayInput.forEach(
            val => map.set(val, (map.get(val) || 0) + 1))
        //if count more than 1 then its non unique
        return arrayInput.filter(val => map.get(val) > 1);
    }
    
    /**
    * @method stringOnly - utility method to strip out all punctuation, numbers and space using regEx 
    * @param {string}
    * @return {stringOnly} - Punctuation, number and space less string
    */
    stringOnly(mixedStr) {
        let stringOnly = mixedStr.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()0-9]/g,"");//remove punctiationa and number
        return stringOnly.replace(/\s{1,}/g,"").toLowerCase(); //remove space
    }

    /**
    * @method mostWanted - It convert string into array and find max length of each item and returns the charecter used max times in input string
    * @param {string}
    * @return {maxChar} - Charecter which is used maximum times in passed string
    */
    mostWanted(string) {
        let max = 0,
            maxChar = '',
            stringInput = this.stringOnly(string);
        //create array of string items and loop through each item
        stringInput.split('').forEach(function(char){
            //if length is > max count
            if(char !== ' ' && stringInput.split(char).length >= max) {
                let charOrder = (maxChar && (max === 1 || max === stringInput.split(char).length)) ? [maxChar,char].sort() : [char];
                //cache maxChar
                max = stringInput.split(char).length;
                maxChar = charOrder[0];
            }
        });
        return maxChar;
    }

}

// export default ArrayService;
module.exports = ArrayService