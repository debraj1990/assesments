/**
Ex-3: Appoint Vendor  = ( give me  a ‘name’ to this pattern )
You are given a sample function which executes service logic. When we call that function,
(a) sould log before & after 
(b) should calculate total time it took to execute
(c) should catch error if any thrown

But we sould not implement these concerns in service function. Must be individual functions and compose them to achieve our goal.

TO RUN - node index.js
 */
const { PerformanceObserver, performance } = require('perf_hooks');

// 1. Wrapper is based on Imediate Invoking Function Expression (IIFE) and revealing patern
const wrapper = (function () {

    const _callFunc = function(fn) {
        try {
            fn()
        } catch (e) {
            console.log('Error while callback call: '+ e.message);
        }
    }

    const _ex = function(func) {
        
        console.log("PRE LOG --------------")
        let preTime = performance.now()
        _callFunc(func); //callback
        let postTime = performance.now()
        console.log("POST LOG --------------")
        
        console.log("Total Execution Time : " + (postTime - preTime)+ ' milliseconds')
    }
    
    return {ex:_ex};
    
})();



// 2. Service function passed as argument to wrapper method
wrapper.ex(function(){console.log('callback call')});
wrapper.ex(function(){throw new Error('js-error')});
