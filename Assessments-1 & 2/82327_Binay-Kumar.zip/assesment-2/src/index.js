//----------------------------------------------
// RUN - node index.js
//----------------------------------------------

const Ac = require('./components/Ac')
const Light = require('./components/Light')
const Door = require('./components/Door')

//room object containing status of light, ac and door = open/close 
let room ={
    light: 'close',
    ac: 'close',
    door: 'close'
}

// 1. create instance of door, light and ac 
const doorObj = new Door(room);
const acObj = new Ac(room);
const lightObj = new Light(room);



// 2. Subscribe to events with ID "action" triggered by door
doorObj.on('action', function(event) {
  //console.log('Received event', event);

  // On every action of door update AC and light
  acObj.doAction(event)
  lightObj.doAction(event)

  //logger
  console.log('---------ON DOOR '+event.type+'----------');
  console.info('AC: '+ room.ac);
  console.log('LIGHT: '+ room.light);
  //console.log('DOOR: '+ room.door);
});

// 3. Trigger door action which will emitt id 'action' 
doorObj.doAction('open', '1', '2');
doorObj.doAction('close', '1', '2');