//--------------------------------------
// Light Class 
// Initialized with room object containing status of light, ac and door = open/close 
//--------------------------------------
class Light {
  constructor(room) {
    this.room = room
  }

  // doAction - set the status of light according to door event
  doAction(event) {
    this.room.light = event.type
    //console.log('--LIGHT-- '+event.type);
  }
}

module.exports = Light;