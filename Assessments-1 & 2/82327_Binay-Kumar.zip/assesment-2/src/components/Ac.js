//--------------------------------------
// Ac Class 
// Initialized with room object containing status of light, ac and door = open/close 
//--------------------------------------
class Ac {
  constructor(room) {
    this.room = room
  }

  //doAction - set the status of AC according to door event
  doAction(event) {
    this.room.ac = event.type
    //console.log('--AC-- '+event.type, this.room);
  }
}

module.exports = Ac;