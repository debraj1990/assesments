const EventEmitter = require('events');
//--------------------------------------
// Light Class 
// Initialized with room object containing status of light, ac and door = open/close 
//--------------------------------------

class Door extends EventEmitter {
  constructor(room) {
    super()
    this.room = room
  }
  
  // doAction - It will trigger events with ID "action"; anyone subscribbed to door 'action' can listen to this and react on action 
  doAction(type, floor, door) {
    const event = {type: type, floorNum:floor, doorNum:door};
    this.room.door = type
    this.emit('action', event);    
  }
}

module.exports = Door;