import Door from './components/Door';
import light from './components/Light'
import AC from './components/AC'

let door = new Door(3, 301);
door.addDoorListener(light);
door.addDoorListener(AC);


setTimeout(() => {
    door.open();
    setTimeout(() => {
        door.close();
    }, 2000);
}, 2000)