const AC = {
    on(e) {
        console.log(`AC ON floor ${e.floorNum} with door-num ${e.doorNum} `);
    },
    off(e) {
        console.log(`AC OFF floor ${e.floorNum} with door-num : ${e.doorNum} `);
    }
};

export default AC;