
class Door {
    constructor(floorNum, doorNum) {
        this.floorNum = floorNum;
        this.doorNum = doorNum;
        this.listeners = [];
    }
    open() {
        let event = { floorNum: this.floorNum, type: 'open', doorNum: this.doorNum };
        this.listeners.forEach(listener => listener.on(event))
    }
    close() {
        let event = { floorNum: this.floorNum, type: 'close', doorNum: this.doorNum };
        this.listeners.forEach(listener => listener.off(event))
    }
    addDoorListener(listener) {
        this.listeners.push(listener)
    }
    removeListener(listener) {
        this.listeners = this.listeners.filter(l => l !== listener)
    }
}

export default Door;