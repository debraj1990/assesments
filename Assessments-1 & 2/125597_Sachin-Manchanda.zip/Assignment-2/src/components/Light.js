const Light = {
    on(e) {
        console.log(`Light ON floor ${e.floorNum} with door-num : ${e.doorNum} `);
    },
    off(e) {
        console.log(`Light OFF floor ${e.floorNum} with door-num : ${e.doorNum} `);
    }
};

export default Light;