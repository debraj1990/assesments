/**
 * Question-1: Non-unique Elements 
 * Solution 1: Without using loadash
 * Input: A list of integers.
 * Output: An iterable of integers.
 */

const nonUniqueElements = (inputArray = []) => {
	return inputArray.filter(item => {
		return inputArray.indexOf(item) !== inputArray.lastIndexOf(item);
	});
};


/**
 * Question-1: Non-unique Elements 
 * Solution 2: With using loadash
 * Input: A list of integers.
 * Output: An iterable of integers.
 */

 /*
 var _ = require('lodash');
 const nonUniqueElements = (inputArray = []) => {
    _.transform(_.countBy(inputArray), function(result, count, value) {
        console.log(result,count,value)
        if (count > 1) result.push(value);
    }, []);
 }
 */

console.log(nonUniqueElements([1, 2, 3, 1, 3]));
console.log(nonUniqueElements([1, 2, 3, 4, 5]));
console.log(nonUniqueElements([5, 5, 5, 5, 5]));
console.log(nonUniqueElements([10, 9, 10, 10, 9, 8]));


/**
 * Question-2: The Most Wanted Letter
 * Input: A text for analysis as a string.
 * Output: The most frequent letter in lower case as a string.
 */

function mostWanted(data) {
    let array = [];
    data.toLowerCase().match(/[a-z]/g).sort().map(i => array[i] = !array[i] ? 1 : array[i] + 1);

    let result = Object.keys(array)[0];
    for (let key in array)
        if (array[key] > array[result]) result = key;

    return result;
}

console.log(mostWanted("Hello World!"));
console.log(mostWanted("How do you do?"));
console.log(mostWanted("One"));
console.log(mostWanted("Oops!"));
console.log(mostWanted("AAaooo!!!!"));
console.log(mostWanted("abe"));

/**
 * Question-3: Appoint Vendor
 * 
 */

function executionService(service) {
	console.log('Service execution Starts here');
  	const time0 = performance.now();
  	try{
        service("Hello World!");
        service("How do you do?");
	} catch (e) {
		throw(e);
	}
	const time1 = performance.now();
	console.log('Total time taken by the Service => ', time1 - time0);
}
executionService(mostWanted);


/**
 * Question-4: Music Player
 * Strategies
 * •	SDNS => shortest duration next song
 * •	LDNS => longest duration next song
 * •	FINS => first in next song
 */
var _ = require('lodash');
class MusicPlayer {
	constructor() {
		this.songs = [];
		this.current = 0
	}
	createList(name, duration) {
		this.songs.push({name, duration});
	}
	
	getNextSong(strategy) {
        let nextSong = this.withStrategy(strategy)[this.current];
        _.remove(this.songs, function(song){
            return song === nextSong;
        })
		return nextSong;
    }
    
    withStrategy(strategy) {
        switch(strategy) {
           case 'SDNS' :  return this.songs.sort((a, b) => a.duration - b.duration);
           case 'LDNS' :  return this.songs.sort((a, b) => b.duration - a.duration);
           case 'FINS' :  return this.songs;
        }
    }
}

const myMusic = new MusicPlayer();
myMusic.createList('Song1', 1000);
myMusic.createList('Song2', 3000);
myMusic.createList('Song3', 2000);
myMusic.createList('Song4', 4000);
myMusic.createList('Song5', 1500);
console.log(myMusic.getNextSong('SDNS'));
console.log(myMusic.getNextSong('LDNS'));
console.log(myMusic.getNextSong('SDNS'));


