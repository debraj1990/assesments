
"use strict"

//---------------------------------------------------
// Ex-1: Non-unique Elements
//---------------------------------------------------
  console.log('------Ex-1: Non-unique Elements------------');
  console.log(`\n-----------------------------------------`);
  console.log('--------------Ex 01 start ----------------');
  console.log(`------------------------------------------\n \n`);

  const nonUniqueElements = (data) => {
    // initialise an empty array to store non-unique elements
    const nonUniqueArray = [];

    // function to check each elements of given data occurance
    const occurenceCheck = (element) => {
        const filteredArray = data.filter(item=>item===element);
      return filteredArray.length;
    }

    if(data && Array.isArray(data)){
      // looing over each element
      for(const element of data) {
        if(occurenceCheck(element)>1) nonUniqueArray.push(element);
      }
    }
    return nonUniqueArray;
  }

  console.log(nonUniqueElements([1, 2, 3, 1, 3])); // [1, 3, 1, 3]
  console.log(nonUniqueElements([1, 2, 3, 4, 5])); // []
  console.log(nonUniqueElements([5, 5, 5, 5, 5])); // [5, 5, 5, 5, 5]
  console.log(nonUniqueElements([10, 9, 10, 10, 9, 8])); // [10, 9, 10, 10, 9]

  console.log(`\n----------------------------------------`);
  console.log('--------------Ex 01 end ----------------');
  console.log('----------------------------------------\n');




//---------------------------------------------------
// Ex-2: The Most Wanted Letter
//---------------------------------------------------

console.log('------Ex-2: The Most Wanted Letter------------');
console.log(`\n----------------------------------------`);
console.log('--------------Ex 02 start ----------------');
console.log('----------------------------------------\n \n');


  const mostWanted = (statement) => {
    if(statement) {
      let sortedStatement = [];

      statement.toLowerCase()
              .match(/[a-z]/g)
              .sort()
              .map(alphabet => sortedStatement[alphabet] = !sortedStatement[alphabet] ? 1 : sortedStatement[alphabet] + 1);

      let frequentElement = Object.keys(sortedStatement)[0];

      for (let index in sortedStatement)
          if (sortedStatement[index] > sortedStatement[frequentElement]) frequentElement = index;
      return frequentElement;
    }
    return '';
  }

  console.log(mostWanted("Hello World!")); // "l"
  console.log(mostWanted("How do you do?")); // "o"
  console.log(mostWanted("One")); // "e"
  console.log(mostWanted("Oops!")); // "o"
  console.log(mostWanted("AAaooo!!!!")); // "a"
  console.log(mostWanted("abe")); // "a"

  console.log('\n----------------------------------------');
  console.log('--------------Ex 02 end ----------------');
  console.log('----------------------------------------\n');



//---------------------------------------------------
// Ex-3: Appoint Vendor
//---------------------------------------------------

console.log('------Ex-3: Appoint Vendor-----------------');
console.log(`\n----------------------------------------`);
console.log('--------------Ex 03 start ----------------');
console.log('----------------------------------------\n \n');

const serviceFuncWithOutError = () => {
  setTimeout(()=>console.log(`I'm done`), 3000);
};

const serviceFuncWithError = () => {
  throw new Error('oops')
};

const serviceFunctionCaller = (callback) => {
  console.log('-------before serviceFunc--------');
  console.time("Time this");
  try {
    callback();
  }catch(e) {
    console.log(`----Error happened: ${e}`);
  };

  console.timeEnd("Time this")
  console.log('-------after serviceFunc--------');

}

//serviceFunctionCaller(serviceFuncWithOutError);
serviceFunctionCaller(serviceFuncWithError);



console.log('\n----------------------------------------');
console.log('--------------Ex 03 end ----------------');
console.log('----------------------------------------\n');



//---------------------------------------------------
// Ex-4: Music Player
//---------------------------------------------------

console.log('------Ex-4: Music Player-------------------');
console.log(`\n----------------------------------------`);
console.log('--------------Ex 04 start ----------------');
console.log('----------------------------------------\n \n');


  class MusicPlayer {
    constructor() {
      this.strategies = ['SDNS', 'LDNS', 'FINS'];
      this.musicList = [];
    }

    addSongInList(song) {
      if(song && song.title && song.duration) {
        this.musicList.push(song)
      }
    }

    getNextSong(strategy) {
      if(strategy && this.strategies.includes(strategy) && this.musicList.length > 1) {
        return this[strategy]();
      }
      return {};
    }

    SDNS() {
      const durationArray = [];
      this.musicList.map((song)=> {
        durationArray.push(song.duration);
      });
      durationArray.sort((a, b)=>a>b);

      const filterdSong = this.musicList.filter((song)=>song.duration===durationArray[0]);

      return filterdSong[0];
    }

    LDNS() {
      const durationArray = [];
      this.musicList.map((song)=> {
        durationArray.push(song.duration);
      });
      durationArray.sort((a, b)=>a<b);

      const filterdSong = this.musicList.filter((song)=>song.duration===durationArray[0]);

      return filterdSong[0];
    }

    FINS() {
      return this.musicList[0];
    }

    getMusicList() {
      return this.musicList;
    }

  }


  const myMusic = new MusicPlayer();

  myMusic.addSongInList({ title: 'Abcd', duration: 5});
  myMusic.addSongInList({ title: 'Random Song', duration: 7});
  myMusic.addSongInList({ title: 'Top Song', duration: 3});
  myMusic.addSongInList({ title: 'Title Song', duration: 1})

  console.log('----- Music List ---');
  console.log(myMusic.getMusicList());
  console.log('----- Next Song SDNS---');
  console.log(myMusic.getNextSong('SDNS'));
  console.log('----- Next Song LDNS---');
  console.log(myMusic.getNextSong('LDNS'));
  console.log('----- Next Song FINS---');
  console.log(myMusic.getNextSong('FINS'));


  console.log('\n----------------------------------------');
  console.log('--------------Ex 04 end ----------------');
  console.log('----------------------------------------\n');




