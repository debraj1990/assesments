"use strict"

class Door {
  constructor(floor, number) {
    this.floor = floor;
    this.number = number;
    const action1 = new Light();
    this.listeners = [ { name: 'Light', value:  new Light() }, { name: 'Ac', value: new Ac() } ];
    this.activeDoors = [{
      floor: this.floor,
      number: this.number
    }];
  }

  openDoor(action) {
    if(!action || !this.listeners){
      return;
    }
    const targetaction = this.listeners.filter(actionItem=>actionItem.name===action);
    targetaction[0].value.open(this.floor, this.number);
    return;
  }

  closeDoor(action) {
    if(!action || !this.listeners){
      return;
    }
    const targetaction = this.listeners.filter(actionItem=>actionItem.name===action);
    targetaction[0].value.close(this.floor, this.number);
    return;
  }

  getActiveDoors() {
    return this.activeDoors;
  }
}

class Light {
  open(floor, number) {
    console.log(`Light has been swithed on at floor : ${floor} and room number: ${number}`);
  }

  close(floor, number) {
    console.log(`Light has been swithed off at floor : ${floor} and room number: ${number}`);
  }
}

class Ac {
  open(floor, number) {
    console.log(`Ac has been swithed on at floor : ${floor} and room number: ${number}`);
  }

  close(floor, number) {
    console.log(`Ac has been swithed off at floor : ${floor} and room number: ${number}`);
  }
}

const Room1 = new Door(1, 1);
Room1.openDoor('Light')
Room1.closeDoor('Light')
Room1.openDoor('Ac')
