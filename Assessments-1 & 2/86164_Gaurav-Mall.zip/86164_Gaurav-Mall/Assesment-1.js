document.body.innerHTML += `<h1>ASSESMENT 1</h1>`;
// Ex-1: Non-unique Elements
/* 
nonUniqueElements([1, 2, 3, 1, 3]) == [1, 3, 1, 3]
nonUniqueElements([1, 2, 3, 4, 5]) == []
nonUniqueElements([5, 5, 5, 5, 5]) == [5, 5, 5, 5, 5]
nonUniqueElements([10, 9, 10, 10, 9, 8]) == [10, 9, 10, 10, 9]
*/
const nonUniqueElements = (array) => {
    array = array || []
    return JSON.stringify(array.filter(function (arrayItem) {
        return array.indexOf(arrayItem) !== array.lastIndexOf(arrayItem)
    }));
}

document.body.innerHTML += `<div>
<h2>Ex-1: Non-unique Elements</h2>
[1, 2, 3, 1, 3] ==> ${nonUniqueElements([1, 2, 3, 1, 3])}<br>
[1, 2, 3, 4, 5] ==> ${nonUniqueElements([1, 2, 3, 4, 5])}<br>
[5, 5, 5, 5, 5] ==> ${nonUniqueElements([5, 5, 5, 5, 5])}<br>
[10, 9, 10, 10, 9, 8] ==> ${nonUniqueElements([10, 9, 10, 10, 9, 8])}<br>
null ==> ${nonUniqueElements(null)}<br>
undefined ==> ${nonUniqueElements(undefined)}<br>
[] ==> ${nonUniqueElements([])}
</div>`;


// =======================================================================


// Ex-2: The Most Wanted Letter
/*
mostWanted("Hello World!") == "l"
mostWanted("How do you do?") == "o"
mostWanted("One") == "e"
mostWanted("Oops!") == "o"
mostWanted("AAaooo!!!!") == "a"
mostWanted("abe") == "a"
*/

const mostWanted = (str) => {
    str = str || ''
    const letterArr = [];
    const sortedArray = str.toLowerCase().split('').sort();
    //finding occurences
    const occurObj = sortedArray.reduce((accum, item) => {
        /[a-zA-Z]/.test(item) && (accum[item] ? accum[item]++ : accum[item] = 1)
        return accum
    }, {});
    //ready to sort
    for (var letter in occurObj) {
        letterArr.push([letter, occurObj[letter]])
    }
    //sort by values
    letterArr.sort(function (first, second) {
        return second[1] - first[1]
    });
    //finding letter and fallback
    const foundLetter = ((letterArr.length > 1) && (letterArr[0][1] > letterArr[1][1]) ? letterArr[0][0] : Object.keys(occurObj)[0]) || (Object.keys(occurObj)[0] || "NONE FOUND")
    return (JSON.stringify(foundLetter));
}

document.body.innerHTML += `<div>
<h2>Ex-2 The Most Wanted Letter</h2>
Hello World! ===>   ${mostWanted("Hello World!")}<br>
How do you do? ===>   ${mostWanted("How do you do?")}<br>
One ===>   ${mostWanted("One")}<br>
Oops! ===>   ${mostWanted("Oops!")}<br>
AAaooo!!!! ===>   ${mostWanted("AAaooo!!!!")}<br>
abe ===>   ${mostWanted("abe")}<br>
z ===>   ${mostWanted("z")}<br>
null ===> ${mostWanted(null)}<br>
undefined ===> ${mostWanted(undefined)}
</div>`;


// =======================================================================


// Ex-3: Appoint Vendor  
// (a) sould log before & after 
// (b) should calculate total time it took to execute
// (c) should catch error if any thrown

// USED :::::::REVEALING MODULE PATTERN::::::::::

const logger = (function () {
    //private variables
    let startTime = 0;
    let endTime = 0;
    let functionName = "";
    //private function
    const reportExecutionTime = (executionTime) => {
        console.log(`Total Execution Time for ${functionName} is : ${executionTime}s`);
    }
    //private function
    const executeFunction = (fn) => {
        try {
            fn()
        }
        catch (err) {
            console.error(`Oops!! Function ${functionName} thown error :: message is "${err}"`)
        }
    }
    //private function
    const endLogging = () => {
        endTime = new Date().getTime();
        const delta = (endTime - startTime) / 1000;
        console.log(`===> ending logging of ${functionName}`);
        reportExecutionTime(delta)
    }
    //public function
    const startLogging = (fnCall) => {
        functionName = fnCall.name
        console.log(`===> started logging of ${functionName}`);
        startTime = new Date().getTime();
        executeFunction(fnCall);
        endLogging();
    }

    return {
        start: startLogging
    };

})();

// TESTING CASE FUNCTION 1
const dummyFunction1 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 1e6; i++) {
        randomize = (Math.floor(Math.random() * 5000) + 3000)
        output += (i + randomize);
    }
    return output;
}

// TESTING CASE FUNCTION 2
const errorFunction = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
        if (i > Math.pow(10, 5)) {
            throw "I cant handle big number"
        }
    }
    return output;
}

// TESTING CASE FUNCTION 3
const dummyFunction2 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 0xf4240; i++) {
        randomize = (Math.floor(Math.random() * 40000) + 3000)
        output += (i + randomize);
    }
    return output;
}

// TESTING CASE FUNCTION 4
const dummyFunction3 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
    }
    return output;
}

logger.start(dummyFunction1);
logger.start(errorFunction);
logger.start(dummyFunction2);
logger.start(dummyFunction3);
document.body.innerHTML += `<div>
<h2>Ex-3: Appoint Vendor  </h2>
<div>Open console</div>
</div>`;


// ========================================================================================
// NOTE ::: DRAFT 2 ==> Adding music in playlist keeping the strategy active (Also : NO LOOP)

// Ex-4: Music Player 
// •	SDNS => shortest duration next song
// •	LDNS => longest duration next song
// •	FINS => first in next song

// USED :::::::CONSTRUCTOR PATTERN::::::::::


const scheduling = {
	FINS: function(){return this._songs},
	SDNS: function(){return this._songs.sort((first, second) => first.duration - second.duration)},
	LDNS: function(){return this._songs.sort((first, second) => second.duration - first.duration)}
}

class MusicPlayer {
	constructor() {
        this._songs = []
        this._currentSong = 0
	}
	addToPlaylist(song, duration) {
		this._songs.push({
            song,
            duration
        })
        // ::NOTE:: maintaining the strategy for added songs/music
        this.setStrategy(this.strategy)
	}
	setStrategy(strategy) {
        if(strategy) {
            this.strategy = strategy
            this._songs = strategy.call(this)
        }
        if(!this._currentSong && this._songs.length) {
            this._currentSong = this._songs[0]
        }
	}
	getNextSong() {
        if(this._songs.length && this.strategy) {
            const newCI = this._songs.indexOf(this._currentSong)
            //return on last song (no looping)
            if(newCI === this._songs.length - 1)
                return "::::REACHED LAST SONG:::::";
                
            this._currentSong = this._songs[newCI+1]
        }
        return this._currentSong
	}
}

const randomDuration = () => ((Math.random() * 4) + 5).toFixed(2)


const myPlayer1 = new MusicPlayer()
myPlayer1.setStrategy(scheduling.FINS)
myPlayer1.addToPlaylist('Song1', randomDuration.call())
myPlayer1.addToPlaylist('Song2', randomDuration.call())
myPlayer1.addToPlaylist('Song3', randomDuration.call())
myPlayer1.addToPlaylist('Song4', randomDuration.call())
console.log('FINS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
myPlayer1.addToPlaylist('Song5', randomDuration.call())
myPlayer1.addToPlaylist('Song6', randomDuration.call())
console.log('FINS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())
myPlayer1.setStrategy(scheduling.SDNS)
console.log('SDNS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())


document.body.innerHTML += `<div>
<h2>Ex-4: Music Player </h2>
<div>Open console</div>
</div>`;
