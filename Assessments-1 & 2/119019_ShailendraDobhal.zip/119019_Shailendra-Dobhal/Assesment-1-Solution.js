//Ex-1: Non-unique Elements

//Solution

function nonUniqueElements(arr) {
  return arr.filter((element, index) => {
    let count = 0;
    for (let i = 0; i < arr.length; i++) {
      if(element === arr[i]) {
        count++;
      }
    }
    return count > 1;
  })
}


//Ex-2: The Most Wanted Letter

//Solution

function mostWanted(str) {
  let max = '';
  const newStr = str.toLowerCase();
  const total = [...newStr].reduce((acc, element) => {
     if (acc[element] && (/[a-z]/).test(element)) {
       acc[element] = acc[element] + 1;
     } else {
       acc[element] = 1;
     }
      
     if(max === '' || acc[element] > acc[max]) {
       max = element;
     } else if (acc[element] === acc[max]) {
       max = element < max ? element : max
     }
    
     return acc;
  }, {});
  
  return max;
}

//Ex-3: Appoint Vendor  = ( give me  a ‘name’ to this pattern )
// Pattern: Composition, HOF 
function logger(vendor) {
  console.group();
  console.log('Service funcion starts....');
  const startTime = performance.now();
  try {
    vendor();
  } catch(err) {
    console.error(err);
  }
  const endTime = performance.now();
  const totalTime = endTime - startTime;
  console.log(`This service took: ${totalTime} ms to execute.`);
  console.log('Service function ends.....')
  console.groupEnd();
}

const appointVendor = () => {
  //logic here
  for(let i = 0; i < 10000; i++) {
    if(i === 999) {
      //throw new Error('This is nicer');
    }
  }
}

logger(appointVendor);

//Ex-4: Music Player  = ( give me  a ‘name’ to this pattern )

class MusicPlayer {
  constructor() {
    this.listOfSongs = [],
    this.currentIndex = 0
  }

  addSong(title, duration) {
    this.listOfSongs.push({
      title,
      duration,
      played: false
    });
  }

  getNextSong(strategy, lists, index) {
    return strategy({lists, index});
  }

}

const SDNS = function({lists}) {
  let smallest = lists[0];
  let index = 0;
  for(let i = 0; i < lists.length; i++) {
    if(smallest.played === true) {
      smallest = lists[i];
      index = i;
    } else if ((lists[i].duration < smallest.duration) && lists[i].played === false) {
      smallest = lists[i];
      index = i;
    }
  }
  smallest.played = true;
  lists[index].played = true;
  return smallest;
}

const LDNS = function({lists}) {
  let largest = lists[0];
  let index = 0;
  for(let i = 0; i < lists.length; i++) {
    if(largest.played === true) {
      largest = lists[i];
      index = i;
    } else if((lists[i].duration > largest.duration) && lists[i].played === false) {
      largest = lists[i];
      index = i;
    }
  }
  largest.played = true;
  lists[index].played = true; 
  return largest;
}

const FINS = function({lists, index}) {
  return lists[index];
}


let musicPlayer = new MusicPlayer();
musicPlayer.addSong('aaaaaaaa', 2000);
musicPlayer.addSong('bbbbbbbb', 200);
musicPlayer.addSong('cccccccc', 200);
let listOfSongs = musicPlayer.listOfSongs;
let currentIndex = musicPlayer.currentIndex;
musicPlayer.getNextSong(LDNS, listOfSongs);
musicPlayer.getNextSong(SDNS, listOfSongs);
musicPlayer.getNextSong(FINS, listOfSongs, currentIndex++);
musicPlayer.getNextSong(FINS, listOfSongs, currentIndex++);






