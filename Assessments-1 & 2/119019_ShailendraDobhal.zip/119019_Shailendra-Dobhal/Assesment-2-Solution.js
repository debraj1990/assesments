class Door {
    constructor(floorNo, doorNo) {
        this.floorNo = floorNo;
        this.doorNo = doorNo;
        this.listeners = [];
    }

    addListener = function(listener) {
        this.listeners.push(listener);
        return {
            removeListener: () => {
                return this.listeners.filter(element => {
                    console.log(listener)
                    return element !== listener;
                })
            }
        }
    }

    open() {
        console.log('Floor No: ' + this.floorNo + ' Door No: ' + this.doorNo);
        this.listeners.forEach((list) => {
          list.on();
        });  
    }

    close(lists) {
        console.log('Floor No: ' + this.floorNo + ' Door No: ' + this.doorNo);
        this.listeners.forEach((list) => {
            list.off();
        });
    }
}

class Light {
    constructor() {
        console.log('LIGHT');
    }

    on() {
        console.log('Light on!')
    }

    off() {
        console.log('Light off');
    }
}

class AC {
    constructor() {
        console.log('AC');
    }

    on() {
        console.log('AC on!')
    }

    off() {
        console.log('AC off');
    }
}


const light = new Light();
const ac = new AC();

const door = new Door(14, 12);
door.addListener(light);
door.addListener(ac);


door.open();
door.close();