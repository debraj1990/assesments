const nonUniqueElements = array =>
  array.filter(
    arrayItem => array.indexOf(arrayItem) !== array.lastIndexOf(arrayItem)
  );
console.log('Output ', nonUniqueElements([10, 9, 11, 10, 9, 8]));
