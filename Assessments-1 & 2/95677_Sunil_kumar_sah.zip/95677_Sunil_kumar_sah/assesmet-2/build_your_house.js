//constants
const openDoor = 'OPEN_DOOR';
const closeDoor = 'CLOSE_DOOR';

//Pub/Sub utility
const events = (() => {
  const topics = {};
  return {
    subscribe: (topic, listener) => {
      if (!topics[topic]) topics[topic] = { queue: [] };
      let index = topics[topic].queue.push(listener) - 1;
      return ((topic, index) => {
        return {
          remove: () => {
            delete topics[topic].queue[index];
          }
        };
      })(topic, index);
    },
    publish: (topic, info) => {
      if (!topics[topic] || !topics[topic].queue.length) return;
      let items = topics[topic].queue;
      items.forEach(item => {
        item(info !== undefined ? info : {});
      });
    }
  };
})();

//Door module
class Door {
  constructor(doorNo, floorNo) {
    this.doorNo = doorNo;
    this.floorNo = floorNo;
  }

  open() {
    console.log('Open door', this.doorNo);
    events.publish(openDoor, { doorNo: this.doorNo });
  }

  close() {
    console.log('close door', this.doorNo);
    events.publish(closeDoor, { doorNo: this.doorNo });
  }
}

//Light module
class light {
  constructor() {
    this.On();
    this.Off();
  }
  On() {
    events.subscribe(openDoor, ({ doorNo }) => {
      console.log('light is on for door num', doorNo);
    });
  }

  Off() {
    events.subscribe(closeDoor, ({ doorNo }) =>
      console.log('light is off for', doorNo)
    );
  }
}

setTimeout(() => {
  const doorObj = new Door(3, 23);
  doorObj.open();
}, 2000);

const lightObj = new light();
