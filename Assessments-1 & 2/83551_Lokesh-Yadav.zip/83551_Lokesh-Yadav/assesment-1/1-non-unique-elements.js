// Ex-1: Non-unique Elements

function nonUniqueElements(arr) {
	return arr.filter((element, index) => {
		let count = 0;
		for (let i = 0; i < arr.length; i++) {
			if (element === arr[i]) {
				count++;
			}
		}
		return count > 1;
	});
}
