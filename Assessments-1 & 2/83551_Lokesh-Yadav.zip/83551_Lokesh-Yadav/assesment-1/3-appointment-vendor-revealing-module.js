// Ex-3: Appoint Vendor  = ( give me  a ‘name’ to this pattern )

const { performance } = require('perf_hooks');

// Revealing Module Pattern
const appointVendor = (function () {
	let preTime;
	let postTime;

    const _callFunc = function(fn) {
        try {
            fn()
        } catch (e) {
            console.log('Error: '+ e.message);
        }
	}

	const _timeLogger(func) {
		preTime = performance.now()
        _callFunc(func);
        postTime = performance.now()
	}

    const _logger = function(func) {
        console.log("Start");
        _timeLogger(func);
        console.log("End");
        console.log("Total Execution Time : " + (postTime - preTime)+ ' milliseconds')
    }

    return {log:_logger};

})();

appointVendor.log(function(){console.log('callback call')});
appointVendor.log(function(){throw new Error('js-error')});