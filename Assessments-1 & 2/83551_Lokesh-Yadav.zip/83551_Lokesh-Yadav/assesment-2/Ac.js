//--------------------------------------
// Ac Class
//--------------------------------------
class Ac {
  constructor(room) {
    this.room = room
  }

  //doAction - set the status of AC according to door event
  doAction(event) {
    this.room.ac = event.type
  }
}

module.exports = Ac;