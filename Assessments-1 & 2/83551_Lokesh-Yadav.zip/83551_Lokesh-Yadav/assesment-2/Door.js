const EventEmitter = require('events');
//--------------------------------------
// Light Class
//--------------------------------------

class Door extends EventEmitter {
  constructor(room) {
    super()
    this.room = room
  }

  // trigger events
  doAction(type, floor, door) {
    const event = {type: type, floorNum:floor, doorNum:door};
    this.room.door = type
    this.emit('action', event);
  }
}

module.exports = Door;