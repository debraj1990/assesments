//----------------------------------------------
// RUN - node index.js
//----------------------------------------------

const Door = require('./Door');
const Light = require('./Light');
const Ac = require('./Ac');

//room object containing status of light, ac and door = open/close
let room = {
	light: 'close',
	ac: 'close',
	door: 'close'
};

const doorObj = new Door(room);
const lightObj = new Light(room);
const acObj = new Ac(room);

doorObj.on('action', function(event) {
	acObj.doAction(event);
	lightObj.doAction(event);

	console.log('AC: ' + room.ac);
	console.log('LIGHT: ' + room.light);
});

doorObj.doAction('open', '1', '2');
doorObj.doAction('close', '1', '2');
