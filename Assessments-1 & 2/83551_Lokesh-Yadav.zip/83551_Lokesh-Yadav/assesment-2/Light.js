//--------------------------------------
// Light Class
//--------------------------------------
class Light {
  constructor(room) {
    this.room = room
  }

  doAction(event) {
    this.room.light = event.type
  }
}

module.exports = Light;