"use strict";

function mostWantedletter(str) {
    str = str.toLowerCase();
    let match = str.match(/[a-z]/g).sort();
    let charCount = {},
        maxCountChar = { char: match[0], count: 1 };
    match.forEach(element => {
        if (charCount[element]) {
            charCount[element]++;
            if (charCount[element] > maxCountChar["count"]) {
                maxCountChar.char = element;
                maxCountChar.count = charCount[element];
            }
        } else {
            charCount[element] = 1;
        }
    });
    return maxCountChar.char;
};

let mostWantedStr = mostWantedletter("Hello World!");
console.log(mostWantedStr);