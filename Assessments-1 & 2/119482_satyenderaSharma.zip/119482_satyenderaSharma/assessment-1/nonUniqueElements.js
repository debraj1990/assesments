"use strict";
function nonUniqueElements(arr) {
    let newArr = arr.filter(num => arr.indexOf(num) != arr.lastIndexOf(num));
    return newArr;
};
let outputArr = nonUniqueElements([5, 6, 6, 5, 19, 18])
console.log(outputArr);



// by loadash method

//_.filter(arr, (val, i, iteratee) => _.includes(iteratee, val, i + 1));

//without .uniq function
console.log(_([1, 1, 2, 2, 3]).groupBy().pickBy(x => x.length > 1).keys().value())



// with .uniq function
var array = [1, 1, 2, 2, 3];
var groupped = _.groupBy(array, function (n) {return n});
var result = _.uniq(_.flatten(_.filter(groupped, function (n) {return n.length > 1})));
console.log(result);