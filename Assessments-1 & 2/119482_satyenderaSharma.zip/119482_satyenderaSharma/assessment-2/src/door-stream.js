


import { Subject } from 'rxjs'

const doorStream = new Subject();  // multi-cast stream from reactive javascript

export default doorStream;

