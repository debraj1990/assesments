document.body.innerHTML += `<h2>ASSESMENT 1</h2>`;
// Exercise-1: Find non-unique Elements

const findNonUniqueElements = (arr) => {
    arr = arr || []
    return JSON.stringify(arr.filter(function (arrayItem) {
        return arr.indexOf(arrayItem) !== arr.lastIndexOf(arrayItem)
    }));
}

document.body.innerHTML += `<div>
<h2>Exercise -1: Find Non-unique Elements</h2>
[1, 2, 3, 4, 5] ----> ${findNonUniqueElements([1, 2, 3, 4, 5])}<br>
[1, 2, 3, 1, 3] ----> ${findNonUniqueElements([1, 2, 3, 1, 3])}<br>
[10, 9, 10, 10, 9, 8] ----> ${findNonUniqueElements([10, 9, 10, 10, 9, 8])}<br>
[5, 5, 5, 5, 5] ----> ${findNonUniqueElements([5, 5, 5, 5, 5])}<br>
null ----> ${findNonUniqueElements(null)}<br>
undefined ----> ${findNonUniqueElements(undefined)}<br>
[] ----> ${findNonUniqueElements([])}
</div>`;


// =======================================================================


// Exercise-2: The Most Wanted Letter

const findMostWantedLetter = (str) => {
    str = str || ''
    const arrLetter = [];
    const sortedArray = str.toLowerCase().split('').sort();
    
    //finding all the occurences
    const occurObj = sortedArray.reduce((accum, item) => {
        /[a-zA-Z]/.test(item) && (accum[item] ? accum[item]++ : accum[item] = 1)
        return accum
    }, {});
    
    
    for (var letter in occurObj) {
        arrLetter.push([letter, occurObj[letter]])
    }
    
    arrLetter.sort(function (first, second) {
        return second[1] - first[1]
    });
    
    
    
    const foundLetter = ((arrLetter.length > 1) && (arrLetter[0][1] > arrLetter[1][1]) ? arrLetter[0][0] : Object.keys(occurObj)[0]) || (Object.keys(occurObj)[0] || "NONE FOUND")
    return (JSON.stringify(foundLetter));
}

document.body.innerHTML += `<div>
<h2>Exercise-2 Find The Most Wanted Letter</h2>
Hello World! ---->   ${findMostWantedLetter("Hello World!")}<br>
How do you do? ---->   ${findMostWantedLetter("How do you do?")}<br>
One ---->   ${findMostWantedLetter("One")}<br>
Oops! ---->   ${findMostWantedLetter("Oops!")}<br>
ZZzooo!!!! ---->   ${findMostWantedLetter("ZZzooo!!!!")}<br>
abe ---->   ${findMostWantedLetter("abe")}<br>
z ---->   ${findMostWantedLetter("z")}<br>
null ----> ${findMostWantedLetter(null)}<br>
undefined ----> ${findMostWantedLetter(undefined)}
</div>`;


// =======================================================================


// Exercise-3: Appoint Vendor  


const logger = (function () {
    //private variables
    let startTime = 0;
    let endTime = 0;
    let functionName = "";
    //private function
    const getExecutionTime = (executionTime) => {
        console.log(`Total Execution Time ${functionName} is : ${executionTime}s`);
    }
    //private function
    const executeFn = (fn) => {
        try {
            fn()
        }
        catch (err) {
            console.error(`Error in...!! Function ${functionName} thown exception :: message is "${err}"`)
        }
    }
    //private function
    const endLogging = () => {
        endTime = new Date().getTime();
        const delta = (endTime - startTime) / 1000;
        console.log(`----> ending logging of ${functionName}`);
        getExecutionTime(delta)
    }
    //public function
    const doLogging = (fnCall) => {
        functionName = fnCall.name
        console.log(`---> started logging of ${functionName}`);
        startTime = new Date().getTime();
        executeFn(fnCall);
        endLogging();
    }

    return {
        start: doLogging
    };

})();

const UTFn1 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 1e6; i++) {
        randomize = (Math.floor(Math.random() * 5000) + 3000)
        output += (i + randomize);
    }
    return output;
}

const errorFunction = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
        if (i > Math.pow(10, 5)) {
            throw "I cant handle big number"
        }
    }
    return output;
}

const UTFn2 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 0xf4240; i++) {
        randomize = (Math.floor(Math.random() * 40000) + 3000)
        output += (i + randomize);
    }
    return output;
}


const UTFn3 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
    }
    return output;
}

logger.start(UTFn1);
logger.start(errorFunction);
logger.start(UTFn2);
logger.start(UTFn3);
document.body.innerHTML += `<div>
<h2>Ex-3: Appoint Vendor  </h2>
<div>Open console</div>
</div>`;


// Exercise-4: Music Player 

//Based on CONSTRUCTOR PATTERN//------------------


const scheduling = {
	FINS: function(){return this._songs},
	SDNS: function(){return this._songs.sort((first, second) => first.duration - second.duration)},
	LDNS: function(){return this._songs.sort((first, second) => second.duration - first.duration)}
}

class MusicPlayer {
	constructor() {
        this._songs = []
        this._currentSong = 0
	}
	addToPlaylist(song, duration) {
		this._songs.push({
            song,
            duration
        })
        this.setStrategy(this.strategy)
	}
	setStrategy(strategy) {
        if(strategy) {
            this.strategy = strategy
            this._songs = strategy.call(this)
        }
        if(!this._currentSong && this._songs.length) {
            this._currentSong = this._songs[0]
        }
	}
	getNextSong() {
        if(this._songs.length && this.strategy) {
            const newCI = this._songs.indexOf(this._currentSong)
            //return on last song (no looping)
            if(newCI === this._songs.length - 1)
                return " --- >REACHED LAST SONG <---";
                
            this._currentSong = this._songs[newCI+1]
        }
        return this._currentSong
	}
}

const randomDuration = () => ((Math.random() * 4) + 5).toFixed(2)


const myPlayer1 = new MusicPlayer()
myPlayer1.setStrategy(scheduling.FINS)
myPlayer1.addToPlaylist('Song1', randomDuration.call())
myPlayer1.addToPlaylist('Song2', randomDuration.call())
myPlayer1.addToPlaylist('Song3', randomDuration.call())
myPlayer1.addToPlaylist('Song4', randomDuration.call())
console.log('FINS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
console.log(myPlayer1.getNextSong())
myPlayer1.addToPlaylist('Song5', randomDuration.call())
myPlayer1.addToPlaylist('Song6', randomDuration.call())
console.log('FINS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())
myPlayer1.setStrategy(scheduling.SDNS)
console.log('SDNS', myPlayer1._songs)
console.log(myPlayer1.getNextSong())


document.body.innerHTML += `<div>
<h2>Exercise-4: Music Player </h2>
<div>Open console</div>
</div>`;
