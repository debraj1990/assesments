

//---------------- Events module...---


const Events =  {
    events: {},
    subscribe: (eventName, object, callback) => {
        Events.events[eventName] = Events.events[eventName] || [];
        Events.events[eventName].push({ object, callback });
    },

    unsubscribe: (eventName, object) => {
        if (Events.events[eventName]) {
            for (let i = 0; i < this.events[eventName].length; i++) {
                if (Events.events[eventName][i].object === object) {
                    Events.events[eventName].splice(i, 1);
                    break;
                }
            }
        }
    },
    publish : (eventName, data) => {
        if (Events.events[eventName]) {
            Events.events[eventName].forEach((instance) => {
                instance.callback(data);
            });
        }
    }
}

//-------- Door module...-------


const Door = {
    open: (floor, door) => {
        Events.publish("DOOR_OPEN", {
            floor, door
        });
    },

    close: (floor, door) => {
        Events.publish("DOOR_CLOSED", {
            floor, door
        });
    }
}



//--------- consumer module... Light

const Light = () => {
    Events.subscribe('DOOR_OPEN', {}, (data)=> {
        console.log('LIGHT is ON Now', 'floor num: '+ data.floor + " <<< Door num --- " + data.door);
    })

    Events.subscribe('DOOR_CLOSED', {}, ()=> {
        console.log('LIGHT is Off Now');
    })
}


//--------- consumer module... Fan...

const Fan = () => {
    Events.subscribe('DOOR_OPEN', {}, (data)=> {
        console.log('Fan is ON Now', 'floor num: '+ data.floor + " <<< Door num --- " + data.door);
    })

    Events.subscribe('DOOR_CLOSED', {}, ()=> {
        console.log('Fan is Off Now');
    })
}

Light();
Fan();


/// --- Intentionaly added set interval for demo purpose... do not consider as performance issue for now....

setInterval(()=> {
    Door.open(Math.floor(Math.random() * Math.floor(5)), Math.floor(Math.random() * Math.floor(5)));
}, 2000)

setInterval(()=> {
    Door.close(Math.floor(Math.random() * Math.floor(5)), Math.floor(Math.random() * Math.floor(5)));
}, 5000)


