// Ex-2: The Most Wanted Letter
function mostWanted (str = '') {
    let countObj = {};

    str = str.replace(/[^a-zA-Z]/g, '');
    let strArr = str.toLowerCase().split('').sort();

    strArr.map(item => {
    	if (countObj[item]) {
    		countObj[item].count++;
    	} else {
    		countObj[item] = {};
    		countObj[item].count = 1;
    	}
    });
    const keysSorted = Object.keys(countObj).sort((a,b) => countObj[b].count - countObj[a].count);

    return keysSorted[0];
}


console.log(mostWanted("Hello World!"));
console.log(mostWanted("How do you do?"));
console.log(mostWanted("One"));
console.log(mostWanted("Oops!"));
console.log(mostWanted("AAaooo!!!!"));
console.log(mostWanted("abe"));
