// Ex-4: Music Player 

class MusicPlayer {
    constructor() {
      this.strategy = 'FINS';
      this.songList = [];
      this.strategySongList = [];
      this.currentSong = 0; 
    }

    addSong(title, duration) {
    	this.songList.push({title, duration});
    }

    getNextSong() {
    	let song = this.strategySongList[this.currentSong];
    	this.currentSong = (this.currentSong !== this.strategySongList.length - 1) ? this.currentSong+1 : 0;
		return song;
	}

	setStrategy(strategy) {
		switch(strategy) {
			case 'SDNS':
				this.strategySongList = this.songList.slice().sort((a, b) => a.duration - b.duration); 
				break;
			case 'LDNS':
				this.strategySongList = this.songList.slice().sort((a, b) => b.duration - a.duration);
				break;
			case 'FINS':
			default: 
				this.strategySongList = this.songList.slice();
		}
		this.currentSong = 0;
	}
}

const player = new MusicPlayer();

player.addSong('Song 300', 300);
player.addSong('Song 200', 200);
player.addSong('Song 500', 500);
player.addSong('Song 100', 100);
player.addSong('Song 400', 400);

player.setStrategy('LDNS');
console.log(player.getNextSong());
console.log(player.getNextSong());

console.log("--------------------");

player.setStrategy('SDNS');
console.log(player.getNextSong());
console.log(player.getNextSong());

console.log("--------------------");

player.setStrategy('FINS');
console.log(player.getNextSong());
console.log(player.getNextSong());