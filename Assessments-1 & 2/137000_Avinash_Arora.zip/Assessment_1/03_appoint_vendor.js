// Ex-3: Appoint Vendor 

function addLogging(fn) {
	return function(data) {
		let startTime = new Date().getTime();
		console.log("---before---");
		try {
			console.log("--In try--");
			fn(data);
		} catch (e) {
			console.log("Error:" + e.message);
		}
		
		let endTime = new Date().getTime();
		console.log("---after---Time taken:", endTime-startTime);
	}
}

function appointVendor(vendor) {
	if(!vendor) {
		throw new Error("Vendor is missing");
	}
	console.log("--appointVendor--", vendor);
}

let loggingVendorFn = addLogging(appointVendor);

loggingVendorFn("Avi");
console.log("---------");
loggingVendorFn();
