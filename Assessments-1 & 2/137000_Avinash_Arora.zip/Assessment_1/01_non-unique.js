
// Ex-1: Non-unique Elements
function nonUniqueElements(arr = []) {
	return arr.filter(item => {
		return arr.indexOf(item) !== arr.lastIndexOf(item)
	});
}

console.log(nonUniqueElements([1, 2, 3, 1, 3]));
console.log(nonUniqueElements([1, 2, 3, 4, 5]));
console.log(nonUniqueElements([5, 5, 5, 5, 5]));
console.log(nonUniqueElements([10, 9, 10, 10, 9, 8]));
console.log(nonUniqueElements());
