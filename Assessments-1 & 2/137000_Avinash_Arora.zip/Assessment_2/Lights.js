class Lights {
  constructor(name = "Light") {
    this.name = name;
  }
  doOn(floor, number) {
    console.log(`${this.name} on floor ${floor} and number ${number} is ON`);
  }
  doOff(floor, number) {
    console.log(`${this.name} on floor ${floor} and number ${number} is OFF`);
  }
}

module.exports = Lights;
