class Door {
  constructor(floor, number) {
    console.log("init Door");
    this.floor = floor;
    this.number = number;
    this.dependents = [];
  }

  setDependents(dependent) {
    console.log("adding dependent");
    this.dependents.push(dependent);
  }

  removeDependents(dependent) {
    console.log("removing dependent");
    const index = this.dependents.findIndex(item => item === dependent);
    this.dependents.splice(index, 1);
  }

  doOpen() {
    console.log(`Door on floor ${this.floor} with number ${this.number} opened`);
    this.dependents.map((dependent)=> {
      dependent.doOn(this.floor, this.number);
    })
    console.log(`-------------------`);
  }

  doClose() {
    console.log(`Door on floor ${this.floor} with number ${this.number} closed`);
    this.dependents.map((dependent)=> {
      dependent.doOff(this.floor, this.number);
    });
    console.log(`-------------------`);
  }
}

module.exports = Door;
