
const Light = require("./Lights");
const Door = require("./Door");

const door = new Door("first", 1);
const light = new Light();
const light1 = new Light("Faaaaannnnn");

door.setDependents(light);
door.setDependents(light1);
door.doOpen();
door.doClose();
door.removeDependents(light);
console.log(`-------------------`);
door.doOpen();
