export const nonUniqueElements = (arrayList = []) => {
  return arrayList.filter((item,index) => {
      const searchIndex = arrayList.indexOf(item);
      if(searchIndex !== index) {
          return true;
      } else if(searchIndex === index) {
          const searchFurther = arrayList.indexOf(item, index+1);
          return searchFurther >= 0
      }
      return false;
  })
}

export const mostWanted = (textString = '') => {
    let mostWanted = '';
    let mostWantedCount = 0;
    let counter = 0;
    const text = textString.replace(/[^a-zA-Z]/g, '').toLowerCase().split('').sort();

    text.forEach((char,i) => {
        counter++;
        if(char != text[i+1]) {
            if(counter > mostWantedCount) {
                mostWantedCount = counter;
                mostWanted = char;
            }
            counter = 0;
        }
    });
    return mostWanted;
}

export const runAndLogPerformace = (func, ...args) => {
    let output;
    console.log("Executing function: " + func.name)
    console.log("Before Execution:" );
    console.time("Execution Time");
    try {
        output = func(...args);
        console.log("Function Executed Sucessfully!");
    } catch(e) {
        console.error("Execution Error: " + e.message);
    }
    console.timeEnd("Execution Time");
    console.log("After Execution:");
    console.log("--------------------------");
    return output;
}

export class musicPlayer {
    constructor() {
        this.songs = [];
        this.currentTrack = -1;
        this.strategy = null;
    }
    loadTracks(tracks = []) {
        this.songs.push(...tracks);
    }
    getNextSong(strategy) {
        if(strategy && strategy !== this.strategy) {
            strategy.call(this);
            this.currentTrack = 0;
            this.strategy = strategy;
            return this.songs[0];
        }
        this.currentTrack = this.songs.length > this.currentTrack + 1 ? this.currentTrack + 1 : 0;
        return this.songs[this.currentTrack];
    }
}

export const schedulingStrategies = {
	SDNS: function() {
		return this.songs.sort((a, b) => a.duration - b.duration);
	},
	LDNS: function() {
		return this.songs.sort((a, b) => b.duration - a.duration);
	},
	FINS: function() {
		return this.songs;
	}
};


export default nonUniqueElements;
