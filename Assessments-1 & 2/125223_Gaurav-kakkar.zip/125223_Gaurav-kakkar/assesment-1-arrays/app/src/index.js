import {
    nonUniqueElements,
    mostWanted,
    runAndLogPerformace,
    musicPlayer,
    schedulingStrategies,
} from './utils';

console.log("-----------------------------------------")
console.log("Non-unique Elements")
console.log("-----------------------------------------")
console.log(nonUniqueElements([1, 2, 3, 1, 3]));
console.log(nonUniqueElements([1, 2, 3, 4, 5]));
console.log(nonUniqueElements([5, 5, 5, 5, 5]));
console.log(nonUniqueElements([10, 9, 10, 10, 9, 8]));


console.log("-----------------------------------------")
console.log("Most Wanted Letter")
console.log("-----------------------------------------")
console.log("Hello World! => " + mostWanted("Hello World!"));
console.log("How do you do? => " + mostWanted("How do you do?"));
console.log("One => " + mostWanted("One"));
console.log("Oops! => " + mostWanted("Oops!"));
console.log("AAaooo!!!! => " + mostWanted("AAaooo!!!!"));
console.log("abe => " + mostWanted("abe"));


console.log("-----------------------------------------")
console.log("Appoint Vendor")
console.log("-----------------------------------------")
runAndLogPerformace(nonUniqueElements);
runAndLogPerformace(nonUniqueElements, [10, 9, 10, 10, 9, 8]);
runAndLogPerformace('no func', "apoint Vendor");
console.log(runAndLogPerformace(nonUniqueElements, [1, 2, 3, 4, 4]));


console.log("-----------------------------------------")
console.log("Music Player")
console.log("-----------------------------------------")
 const tracks = [
  { name: "Song 1 Title", duration: 200 },
  { name: "Song 2 Title", duration: 180 },
  { name: "Song 3 Title", duration: 170 },
  { name: "Song 4 Title", duration: 220 },
  { name: "Song 5 Title", duration: 210 },
  { name: "Song 6 Title", duration: 260 },
]
const {SDNS, LDNS, FINS } = schedulingStrategies;

const myPlayer = new musicPlayer();
myPlayer.loadTracks(tracks);
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong(SDNS));
console.log(myPlayer.getNextSong(SDNS));
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong(LDNS));
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong(LDNS));
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong());
console.log(myPlayer.getNextSong(FINS));
console.log(myPlayer.getNextSong());
