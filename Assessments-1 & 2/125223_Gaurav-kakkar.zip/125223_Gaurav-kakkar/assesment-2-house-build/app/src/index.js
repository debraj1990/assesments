

class Light {
  start() {
    console.log("Lights on!");
  }
  stop() {
    console.log("Lights off!");
  }
  listen(e) {
    switch(e.type) {
      case 'open':
        this.start();
        break;
      case 'close':
        this.stop();
        break;
    }
  }
}

class Cooler {
  start() {
    console.log("Cooler started!");
  }
  stop() {
    console.log("Cooler stopped!");
  }
  listen(e) {
    switch(e.type) {
      case 'open':
        this.start();
        break;
      case 'close':
        this.stop();
        break;
    }
  }
}

class Door {
  constructor(room, floor) {
    this.room = room;
    this.floor = floor;
    this.appliances = [];
  }
  open() {
    this.appliances.forEach(item => {
      item.listen({type: 'open', floorNum: this.floor, doorNum: this.door});
    });
  }
  close() {
    this.appliances.forEach(item => {
      item.listen({type: 'close', floorNum: this.floor, doorNum: this.door});
    });
  }
  addLister(appliance) {
    this.appliances.push(appliance);
  }
}

var room = new Door(2,1);
room.addLister(new Light());
room.addLister(new Cooler());
room.open();
room.close();
