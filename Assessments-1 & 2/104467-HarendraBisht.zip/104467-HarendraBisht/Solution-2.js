class Door {
	constructor(floor, roomNum){
		this.floor = floor;
		this.roomNum = roomNum;
		this.listners = [];
	}

	addListener(listner){
		this.listners.push(listner);
	}
	open() {
		this.listner.forEach((listner) => {
			listner.on();
		});
	}

	close() {
		this.listner.forEach((listner) => {
			listner.off();
		});
	}
}

class Light {
	on() {
		console.log('-----Light should ON----');
	}

	off() {
		console.log('---Light Should OFF -----');
	}
}


const light = new Light();
//--- initialize
const labRoom = new Door(2, 4);
labRoom.addListener(light);
labRoom.open();
labRoom.close();
