/**
 * Ex-1: Non-unique Elements
	nonUniqueElements([1, 2, 3, 1, 3]) == [1, 3, 1, 3]
	nonUniqueElements([1, 2, 3, 4, 5]) == []
	nonUniqueElements([5, 5, 5, 5, 5]) == [5, 5, 5, 5, 5]
	nonUniqueElements([10, 9, 10, 10, 9, 8]) == [10, 9, 10, 10, 9]
 */

const nonUniqueElements = (array = []) => {
	return array.filter(item => {
		return array.indexOf(item) !== array.lastIndexOf(item);
	});
};

/**
 * Ex-2: The Most Wanted Letter
 * mostWanted("Hello World!") == "l"
	mostWanted("How do you do?") == "o"
	mostWanted("One") == "e"
	mostWanted("Oops!") == "o"
	mostWanted("AAaooo!!!!") == "a"
	mostWanted("abe") == "a"
 */

const mostWanted = str => {
	let obj = {},
		repeatedWord = '',
		count = 1;
	// Create an object of char with its repeatation
	for (var i = 0; i < str.length; i++) {
		if (str[i] >= 'A' && str[i] <= 'z') {
			obj[str[i].toLowerCase()] = isNaN(obj[str[i].toLowerCase()]) ? 1 : obj[str[i].toLowerCase()] + 1;
		};
	}
	// create repeated word string
	for (let i in obj) {
		if (obj[i] > count) {
			count = obj[i];
			repeatedWord = i;
    	} else if (obj[i] === count) {
			repeatedWord += i;
		}
	}
	return repeatedWord.split('').sort()[0];
}

/**
 * Ex-3: Appoint Vendor
 * 
 */

function executionService(service) {
	console.log('Service execution Starts here');
  	const t0 = performance.now();
  	try{
		service();
	} catch (e) {
		throw(e);
	}
	const t1 = performance.now();
	console.log('Service Execution Ends Here ...');
	console.log('Total time taken by Service => ', t1 - t0);
}
executionService(nonUniqueElements);
/**
 * Ex-4: Music Player  = ( give me  a ‘name’ to this pattern )
 * Constructor Pattern
 */
class MusicPlayer {
	constructor() {
		this.songs = [];
		this.current = 0
	}
	createList(name, duration) {
		this.songs.push({name, duration});
	}
	setStrategy(strategy) {
		this.songs = strategy.call(this);
	}
	getNextSong() {
		return this.songs[this.current++];
	}
}

const strategy = {
	SDNS: function() {
		return this.songs.sort((a, b) => a.duration - b.duration);
	},
	LDNS: function() {
		return this.songs.sort((a, b) => b.duration - a.duration);
	},
	FINS: function() {
		return this.songs;
	}
};
const myMusic = new MusicPlayer();
myMusic.createList('Song1', 100);
myMusic.createList('Song2', 300);
myMusic.createList('Song3', 200);
myMusic.createList('Song4', 400);
myMusic.createList('Song5', 150);
myMusic.setStrategy(strategy.SDNS);
console.log(myMusic.getNextSong());
console.log(myMusic.getNextSong());



