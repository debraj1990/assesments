"use strict";

let songsList, songsByLD, songsBySD;
songsList = [
    { title: "Song 1", durationInSeconds: 180 },
    { title: "Song 2", durationInSeconds: 120 },
    { title: "Song 3", durationInSeconds: 60 },
    { title: "Song 4", durationInSeconds: 30 },
    { title: "Song 5", durationInSeconds: 210 }
];

songsByLD = songsList.slice(0).sort((song1, song2) => {
    return parseInt(song2.durationInSeconds) - parseInt(song1.durationInSeconds);
});

songsBySD = songsList.slice(0).sort((song1, song2) => {
    return parseInt(song1.durationInSeconds) - parseInt(song2.durationInSeconds);
});

function getNextSong(strategy, nextSongIndex) {
    let nextSong;
    switch (strategy) {
        case "SDNS":
            nextSong = songsBySD[nextSongIndex];
            break;
        case "LDNS":
            nextSong = songsByLD[nextSongIndex];
            break;
        case "FINS":
            nextSong = songsList[nextSongIndex];
            break;
        default:
            nextSong = songsList[nextSongIndex];
            break;
    }
    return nextSong;
}

function playNextSong(user) {
    user.currentSong += 1;
    let nextSong = getNextSong(user.strategy, user.currentSong);
    console.log("Playing " + nextSong.title + " for " + user.name);
}

let user1 = { name: "user 1", currentSong: -1, strategy: "LDNS" };
playNextSong(user1);
playNextSong(user1);
playNextSong(user1);

let user2 = { name: "user 2", currentSong: -1, strategy: "SDNS" };
playNextSong(user2);
playNextSong(user2);
playNextSong(user2);

