"use strict";

function getEmployees() {
    let promise = new Promise((resolve, reject) => {
        setTimeout(() => {
            let employees = ["employee 1", "employee 2", "employee 3", "employee 4"];
            resolve(employees);
            //reject("Empoyee list not available");
        }, 2000);
    });
    return promise;
}

function renderEmployees() {
    console.log("Getting employee list..");
    console.time('getEmployees');
    let employeesPromise = getEmployees();
    employeesPromise.then(employees => {
        console.log("Rendering empoyee list..");
        console.log(employees);
        console.log("=====Execution time=====");
        console.timeEnd('getEmployees');
    }, error => {
        console.log(error);
    });
}

renderEmployees();