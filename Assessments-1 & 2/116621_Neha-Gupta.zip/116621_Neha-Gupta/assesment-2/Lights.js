class Lights {
    constructor() {

    }
    lightsOn() {
        console.log("Lights on");
    }
    lightsOff() {
        console.log("Lights off");
    }
}

module.exports = Lights;