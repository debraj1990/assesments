class AirCooler {
    constructor() {

    }
    airCoolerOn() {
        console.log("airCoolerOn on");
    }
    airCoolerOff() {
        console.log("airCoolerOn off");
    }
}

module.exports = AirCooler;