const doorStream = require('./doorStream.js').stream;

class Door {
    constructor(floorNumber, doorNumber) {
        this.floorNumber = floorNumber;
        this.doorNumber = doorNumber;
    }
    openDoor() {
        console.log("Floor:" + this.floorNumber + ", Door:" + this.doorNumber + " opened");
        doorStream.next({
            type: 'open',
            floorNumber: this.floorNumber,
            doorNumber: this.doorNumber
        });
    }
    closeDoor() {
        console.log("Floor:" + this.floorNumber + ", Door:" + this.doorNumber + " closed");
        doorStream.next({
            type: 'closed',
            floorNumber: this.floorNumber,
            doorNumber: this.doorNumber
        });
    }
}

module.exports = Door;