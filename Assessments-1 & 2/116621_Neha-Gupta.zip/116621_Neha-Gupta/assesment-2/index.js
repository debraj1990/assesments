const door = require('./Door.js');
const lights = require('./Lights.js');
const airCooler = require('./AirCooler.js');
const doorStream = require('./doorStream.js').stream;

let doorInstance = new door('1', '1');
let lightsInstance = new lights();
let airCoolerInstance = new airCooler();

//subscibing lights
let lightSubscription = doorStream.subscribe((event) => {
    if (event.type === "open") {
        lightsInstance.lightsOn();
    } else if (event.type === "closed") {
        lightsInstance.lightsOff();
    }
});

//subscibing ac
let acSubscription = doorStream.subscribe((event) => {
    if (event.type === "open") {
        airCoolerInstance.airCoolerOn();
    } else if (event.type === "closed") {
        airCoolerInstance.airCoolerOff();
    }
});

//open door
doorInstance.openDoor();
// close door
doorInstance.closeDoor();

lightSubscription.unsubscribe();
doorInstance.openDoor();


