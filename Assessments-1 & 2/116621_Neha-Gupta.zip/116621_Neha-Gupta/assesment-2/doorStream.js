const { Subject } = require('rxjs');

let _stream = new Subject();

let doorStream = {
    stream: _stream
}

module.exports = doorStream;