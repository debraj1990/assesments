"use strict";

function nonUniqueElements(arr) {
    let newArr = arr.filter(num => arr.indexOf(num) != arr.lastIndexOf(num));
    return newArr;
};

//let outputArr = nonUniqueElements([1, 2, 3, 1, 3]);
//let outputArr = nonUniqueElements([1, 2, 3, 4, 5]);
//let outputArr = nonUniqueElements([5, 5, 5, 5, 5]);
let outputArr = nonUniqueElements([10, 9, 10, 10, 9, 8])

console.log(outputArr);