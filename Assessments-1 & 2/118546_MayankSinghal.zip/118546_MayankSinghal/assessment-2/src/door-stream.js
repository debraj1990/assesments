


import { Subject } from 'rxjs'

const doorStream = new Subject();  // multi-cast stream

export default doorStream;

