class Door {
  constructor(floorNum, doorNum){
    this.listener = {};
    this.floorNum = floorNum;
    this.doorNum = doorNum;
  }

  subscribe(id, callback){
    if(!id || typeof callback !== "function"){
      console.log('invalid listener');
    } else {
      this.listener[id] = callback;
      console.log(id + ' subscribed');
    }
  }

  unsubscribe(id) {
    this.listener[id] = null;
    console.log(id + ' unsubscribed');
  }

  open(){
    console.log('Door open');
    this.callListener(this.listener, "open");
  }

  close(){
    console.log('Door closed');
    this.callListener(this.listener, "close");
  }

  callListener(listeners, action){
    Object.keys(listeners).forEach(item => {
      if(typeof listeners[item] === "function"){
        listeners[item](action, this.floorNum, this.doorNum);
      }
    });
  }
}

class Light {
  constructor(id, door){
    this.id = id;
    this.handler = this.handler.bind(this);
    door.subscribe(id, this.handler);
  }
  handler(action, floorNum, doorNum){
    if(action === "open"){
      this.on(floorNum, doorNum);
    } else {
      this.off(floorNum, doorNum);
    }
  }
  on(floorNum, doorNum){
    console.log(`lights on for floor ${floorNum} as ${doorNum} opens`);
  }
  off(floorNum, doorNum){
    console.log(`lights off for floor ${floorNum} as ${doorNum} closes`);
  }
}

class AC {
  constructor(id, door){
    this.id = id;
    this.handler = this.handler.bind(this);
    this.door = door;
    door.subscribe(id, this.handler);
  }
  handler(action, floorNum, doorNum){
    if(action === "open"){
      this.on(floorNum, doorNum);
    } else {
      this.off(floorNum, doorNum);
    }
  }
  on(floorNum, doorNum){
    console.log(`AC on for floor ${floorNum} as ${doorNum} opens`);
  }
  off(floorNum, doorNum){
    console.log(`AC off for floor ${floorNum} as ${doorNum} closes`);
  }
  removeListening(){
    this.door.unsubscribe(this.id);
  }
}

const door = new Door(7, 1);

const light = new Light("light_1", door);

const ac = new AC("ac_1", door);

door.open();
door.close();
ac.removeListening();
door.open();


