
/**
 * Ex.1 Non Unique elements
 */
function nonUniqueElements(arr) {
  return arr.filter(key => arr.indexOf(key) !== arr.lastIndexOf(key))
}

console.log(nonUniqueElements([1, 2, 3, 1, 3]));
console.log(nonUniqueElements([1, 2, 3, 4, 5]));

/**
 * Ex.2 Most wanted character
 */
function mostWanted(str) {
  const strArray = str.toLowerCase().split("").filter(element => /[a-z]/.test(element)).sort();
  const strLen = strArray.length;
  let index = 0;
  let maxF = 0;
  let result = '';
  while(index < strLen){
    const currLastIndex = strArray.lastIndexOf(strArray[index]);
    const currF = (currLastIndex - index) + 1;
    if(currF > maxF) {
      maxF = currF;
      result = strArray[index];
    }
    index = currLastIndex + 1;
  }
  return result;
}

console.log(mostWanted("Hello World!"));
console.log(mostWanted("How do you do?"));
console.log(mostWanted("AAaooo!!!!"));

/**
 * Ex.3 AppointVendor
 */
function errorHandler(func){
  try {
    func();
  } catch (e) {
    console.log('error is ', e);
  }
}

function timeLogger(func) {
  console.time("timeLogger")
  errorHandler(func);
  console.timeEnd("timeLogger");
}

function log(func) {
  console.log("start");
  timeLogger(func);
  console.log("end");
}

function appointVendor(func) {
  log(func);
}

appointVendor(function(){
  console.log("sample function called");
});

appointVendor(function(){
  console.log("sample function called with error " + undefinedVariable);
});

/**
 * Ex.4 Music Player
 */
const musicPlayer = {
  songList: [{
    title: 'a',
    duration: 5
  },{
    title: 'b',
    duration: 10
  },{
    title: 'c',
    duration: 6
  }, {
    title: 'd',
    duration: 7
  }],
  currentSongIndex: 0,
  getNextSong: function(strategy){
    const nextSongList = this.songList.slice(this.currentSongIndex + 1);
    let nextSong;
    switch(strategy){
      case 'SDNS':
        nextSong = nextSongList.reduce((current, next) => {
          if(next.duration > current.duration) {
            return next;
          }
          return current;
        }, nextSongList[0]);
        break;
      case 'LDNS':
      nextSong = nextSongList.reduce((current, next) => {
          if(next.duration < current.duration) {
            return next;
          }
          return current;
        }, nextSongList[0]);
        break;
      case 'FINS':
        nextSong = nextSongList[0];
        break;
        default:;
    }
    return nextSong;
  }
}

console.log(musicPlayer.getNextSong('SDNS'));
console.log(musicPlayer.getNextSong('LDNS'));
console.log(musicPlayer.getNextSong('FINS'));
