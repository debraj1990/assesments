console.log('--index,js--');
//---------------
//Assessment Class
//---------------

//---------------
//Amenities Class
//---------------
class Amenities{
    constructor(amenities, floor){
        console.log(amenities+' Module init');
        this.amenities=amenities;
        this.floor=floor;
    }
    on(){
        console.log(this.amenities+' on for floor '+this.floor);
    }
    off(){
        console.log(this.amenities+ ' off for floor '+this.floor);
    }
}
//---------------
//Door Class
//---------------
class Door{
    constructor(floor){
        console.log('Door Module init');
        this.floor=floor;
        this.amenities=[];
    }
    addAmenities(item){
        this.amenities.push(item);
        this.amenities[this.amenities.length-1]=new Amenities(this.amenities[this.amenities.length-1],this.floor);
    }
    openDoor(){
        console.log('=================');
        console.log('Open Door for floor- '+this.floor);
        for(let i=0;i<this.amenities.length;i++){
            this.amenities[i].on();
        }
        console.log('---------------');
    }
    closeDoor(){
        console.log('Close Door for floor- '+this.floor);
        for(let i=0;i<this.amenities.length;i++){
            this.amenities[i].off();
        }
        console.log('=================');
    }
}
//---------------
//Execute Project
//---------------

let door1=new Door(1); // Object create of Door Class
door1.addAmenities('AC');  // Add new Amenities
door1.openDoor();	// Call openDoor function
door1.closeDoor();  // Call closeDoor function

door1.addAmenities('Light'); // Add new Amenities
door1.openDoor(); // Call openDoor function
door1.closeDoor(); // Call closeDoor function
