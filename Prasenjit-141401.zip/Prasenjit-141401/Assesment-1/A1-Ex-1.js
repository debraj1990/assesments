console.log('--index,js--');

//---------------
//nonUniqueElements Function 
//---------------
function nonUniqueElements(data) {
    array_elements = data.slice(); 
    array_elements.sort();
	array_elements[array_elements.length]=null;
    var current = array_elements[0];
    var cnt = 1;
    for (var i = 1; i < array_elements.length; i++) {
        if (array_elements[i] != current) {
            if (cnt > 0) {
				if (cnt === 1) {
					var index = data.indexOf(array_elements[i-1]);
					if (index > -1) {
					  data.splice(index, 1);
					}
				}
            }
            current = array_elements[i];
            cnt = 1;
        } else {
            cnt++;
			current = array_elements[i];
        }
    }
	console.log(data); // Print final array
	return data;	
}

//---------------
//Execute Function
//---------------
nonUniqueElements([1, 2, 3, 1, 3]);
nonUniqueElements([1, 2, 3, 4, 5]);
nonUniqueElements([5, 5, 5, 5, 5]);
nonUniqueElements([10, 9, 10, 10, 9, 8]);


