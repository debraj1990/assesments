console.log('--index,js--');

//---------------
//Music Player
//---------------
class Player{
	constructor(){
		this.strategy="FINS",
		this.currentSong=0,
		this.songList=[
		{title:"Song 1",duration:400},
		{title:"Song 2",duration:600},
		{title:"Song 3",duration:300},
		{title:"Song 4",duration:800},
		]
	}
	addSong(song){
		this.songList.push(song);
		this.sortSongList();
	}
	setStrategy(strategy){
		this.strategy=strategy;
		this.sortSongList();
	}
	getNextSong(){
		if(this.songList.length && this.strategy) {
            const newIntex = this.songList.indexOf(this.currentSong)
            //return on last song (no looping)
            if(newIntex === this.songList.length - 1){
				this.currentSong=0;
			}   
            this.currentSong = this.songList[newIntex+1]
        }
        return this.currentSong
	}
	sortSongList(){
		if(this.strategy=='LDNS'){
			return this.songList.sort((first, second) => second.duration - first.duration);
		}else if(this.strategy=='SDNS'){
			return this.songList.sort((first, second) => first.duration - second.duration);
		}else{
			return this.songList;
		}
	}
}

//---------------
//Execute Function
//---------------
let player1 =new Player(); // Create instance of Player class
console.log(player1.songList);

let newSong={title:"Song 10",duration:100}; // Add new Song in list
player1.addSong(newSong); 
console.log(player1.songList);

player1.setStrategy('LDNS'); // Change Strategy
console.log(player1.songList);

let playingSong=player1.getNextSong(); // Play Next Song
console.log(playingSong);
 
playingSong=player1.getNextSong(); // Play Next Song
console.log(playingSong);

player1.setStrategy('SDNS'); // Change Strategy
console.log(player1.songList);

playingSong=player1.getNextSong(); // Play Next Song
console.log(playingSong);
