console.log('--index,js--');

//---------------
//Appoint Vendor  Function 
//---------------
function testService(){
	console.log("Service Method Called");
}
function serviceVendor(service) {
	console.log('Service execution Starts here');
  	const timeStart = performance.now();
  	try{
		service();
	} catch (e) {
		throw(e);
	}
	const timeEnd = performance.now();
	console.log('Service Execution Ends Here ...');
	console.log('Total time taken by Service => ', timeEnd - timeStart);
}


//---------------
//Execute Function
//---------------
serviceVendor(testService);


