console.log('--index,js--');

//---------------
//mostWanted Function 
//---------------
function mostWanted(data) {
	array_elements = data.replace(/[^A-Z0-9]+/ig, "").toLowerCase().split('');
    array_elements.sort();
	array_elements[array_elements.length]=null;
    var current = array_elements[0];
    var count = 1;
	var maxcount=1;
	var character=array_elements[0];
    for (var i = 1; i < array_elements.length; i++) {
        if (array_elements[i] != current) {
            current = array_elements[i];
            count = 1;
        } else {
            count++;
			current = array_elements[i];
			if(count>maxcount){
				maxcount=count;
				character=array_elements[i];
			}
        }
    }
	console.log(character); // Print final array
	return data;	
}

//---------------
//Execute Function
//---------------
mostWanted("Hello World!");
mostWanted("How do you do?");
mostWanted("One");
mostWanted("Oops!");
mostWanted("AAaooo!!!!");
mostWanted("abe");




