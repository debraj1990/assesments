class WordCount extends HTMLElement {
  static get observedAttributes() {
    return ['disabled', 'showcount'];
  }

  constructor(){
    super();
    this.showCount = 'true';
    this.messageUpdateEvent = new CustomEvent('messageUpdated', {
      bubbles: true,
    });
    this.shadow = this.attachShadow({mode: "open"});
    const wrapper = document.createElement('div');
    this.counter = null;
    wrapper.classList.add('wrapper');
    const textarea = document.createElement('textarea');
    textarea.classList.add('textarea');
    const style = document.createElement('style');

    style.textContent = `
    .textarea {
      border: 1px solid #d3d3d3;
      height: 100px;
      width: 100%;
      resize: none;
    }
    .count-message {
      margin: 10px 0 0;
    }
    `

    wrapper.appendChild(style);
    wrapper.appendChild(textarea);
    this.shadow.appendChild(wrapper);
  }

  connectedCallback(){
    this.wrapper = this.shadow;
    this.textarea = this.wrapper.querySelector('textarea');
    this.getAttributeNames().forEach(attrName => {
      this.textarea.setAttribute(attrName, this.getAttribute(attrName));
    });
    if(this.hasAttribute('showcount')){
      this.showCount = this.getAttribute('showcount');
    }
    if(this.showCount === 'true'){
      this.showCountMessage();
    }
    this.textarea.addEventListener('input', (evt) => {
      if(this.counter){
        this.counter.innerText = `${evt.target.value.length}`;
      }
      this.dispatchEvent(this.messageUpdateEvent);
    });
  }

  attributeChangedCallback(name, oldValue, newValue) {
    if(name === 'showcount'){
      if(oldValue === 'false' && newValue === 'true'){
        this.showCount = true;
        this.showCountMessage();
      } else if (newValue === 'false' && this.shadow.querySelector('.count-message')) {
        this.shadow.querySelector('.count-message').remove();
      }
    }

  }

  showCountMessage(){
    const countWrapper = document.createElement('p');
    countWrapper.classList.add('count-message')
    countWrapper.innerText = "#Characters:";
    const count = document.createElement('span');
    count.setAttribute('data-count', true);
    countWrapper.appendChild(count);
    this.shadow.appendChild(countWrapper);
    const textarea = this.wrapper.querySelector('textarea');
    this.counter = this.wrapper.querySelector('[data-count]');
    this.counter.innerText = textarea.value.length;
  }
}

customElements.define('word-count', WordCount);
