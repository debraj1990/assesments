const template = document.createElement('template')
template.innerHTML = `
    <style>
        .rating-container {
            display: inline-block;
        }
        .star {
            height: 30px;
            display: inline-flex;
            text-align: center;
            cursor: pointer;
        }
        .star::after {
            content: '';
            width: 30px;
            background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0Ij48cGF0aCBkPSJNMTIgLjU4N2wzLjY2OCA3LjU2OCA4LjMzMiAxLjE1MS02LjA2NCA1LjgyOCAxLjQ4IDguMjc5LTcuNDE2LTMuOTY3LTcuNDE3IDMuOTY3IDEuNDgxLTguMjc5LTYuMDY0LTUuODI4IDguMzMyLTEuMTUxeiIvPjwvc3ZnPg==") center center  no-repeat;
            opacity: 0.2;
        }
        
        .star.full::after {
            content: '';
            width: 30px;
            background: url("data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgc3R5bGU9IiI+PHJlY3QgaWQ9ImJhY2tncm91bmRyZWN0IiB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4PSIwIiB5PSIwIiBmaWxsPSJub25lIiBzdHJva2U9Im5vbmUiLz48ZyBjbGFzcz0iY3VycmVudExheWVyIiBzdHlsZT0iIj48dGl0bGU+TGF5ZXIgMTwvdGl0bGU+PHBhdGggZD0iTTEyIC41ODdsMy42NjggNy41NjggOC4zMzIgMS4xNTEtNi4wNjQgNS44MjggMS40OCA4LjI3OS03LjQxNi0zLjk2Ny03LjQxNyAzLjk2NyAxLjQ4MS04LjI3OS02LjA2NC01LjgyOCA4LjMzMi0xLjE1MXoiIGlkPSJzdmdfMSIgY2xhc3M9InNlbGVjdGVkIiBmaWxsPSIjZTc2N2U3IiBmaWxsLW9wYWNpdHk9IjEiLz48L2c+PC9zdmc+") center center  no-repeat;
            opacity: 1;
            fill: red;
        }
    </style>
    <div class="rating-container"></div>
`

class StarRating extends HTMLElement {

    constructor() {
        super();

        this.number = this.number;
        this.root = this.attachShadow({ mode: 'closed' })
        this.root.appendChild(template.content.cloneNode(true))
        this.ratingElement = this.root.querySelector('div');

        for (let i = 0; i < this.number; i++) {
            let s = document.createElement('div');
            s.className = 'star';
            this.ratingElement.appendChild(s);
            this.stars.push(s);
        }

        this.ratingElement.addEventListener('click', e => {
            let box = this.getBoundingClientRect(),
                rateIndex = Math.floor((e.pageX - box.left) / box.width * this.stars.length);
            this.value = rateIndex + 1;
        });

    }

    highlight(index) {
        this.stars.forEach((starEl, i) => {
            starEl.classList.toggle('full', i <= index);
        });
    }

    get value() {
        return this.getAttribute('value') || 0;
    }

    set value(val) {
        this.setAttribute('value', val);
        this.highlight(this.value - 1);
        const rateEvent = new CustomEvent('rateValueChanged', { 
            detail: {
                val, 
                number: this.number
            } 
        });
        this.dispatchEvent(rateEvent);
    }

    get number() {
        return this.getAttribute('number') || 5;
    }

    set number(val) {
        this.setAttribute('number', val);
        this.stars = [];
        this.value = this.value;
    }

}

customElements.define('x-rating', StarRating);

export default StarRating