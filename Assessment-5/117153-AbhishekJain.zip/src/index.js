import StarRating from './rating';

var rating = document.querySelectorAll('x-rating');

rating.forEach(function(element) {
    element.addEventListener('rateValueChanged', e => {
        console.log(`Event Triggered for ---- #${element.id} ==>  Rating ---- ${e.detail.val}/${e.detail.number}`);
    })
});