// Date Range component

const component = document.createElement('template');
component.innerHTML = `
	<div class="dateRangePicker">
		<label for="start">Start:</label>
		<input type="date" name="startDate" id="startDate">
		<br>
		<label for="end">End:</label>
		<input type="date" name="endDate" id="endDate">
		<h3 id="range"></h3>
	</div>
`
class DateRangePicker extends HTMLElement {
	constructor() {
		super();
		this.root = this.attachShadow({ mode: 'closed' })
		this.root.appendChild(component.content.cloneNode(true))
		this.datePickerElm = this.root.querySelectorAll('[type="date"]');
		this.selectedRange = this.root.querySelector('#range');
		this.datePickerElm.forEach(element => {
			element.value= this.defaultValue();
			element.addEventListener('change', e => {
				this.onDateSelection(e);
			});
		});

		this.startDate = this.root.querySelector('#startDate').value;
		this.endDate = this.root.querySelector('#endDate').value;
	}

	defaultValue(){
		const now = new Date();
		const day = ("0" + now.getDate()).slice(-2);
		const month = ("0" + (now.getMonth() + 1)).slice(-2);

		return now.getFullYear()+"-"+(month)+"-"+(day) ;
	}

	onDateSelection(e) {
		const { name, value } = e.target;
		this[name] = value;
		const diff = new Date(this.endDate).getTime() -  new Date(this.startDate).getTime();
		if(diff < 0 ) {
			this.selectedRange.innerHTML = 'Invalid Range';
		} else {
			this.selectedRange.innerHTML = this.secondsToDhms(diff/1000);
		}
	}

	secondsToDhms(seconds) {
		seconds = Number(seconds);
		const d = Math.floor(seconds / (3600 * 24));
		const h = Math.floor(seconds % (3600 * 24) / 3600);
		const m = Math.floor(seconds % 3600 / 60);
		const s = Math.floor(seconds % 3600 % 60);

		const dDisplay = d > 0 ? d + (d == 1 ? " day, " : " days, ") : "";
		const hDisplay = h > 0 ? h + (h == 1 ? " hour, " : " hours, ") : "";
		const mDisplay = m > 0 ? m + (m == 1 ? " minute, " : " minutes, ") : "";
		const sDisplay = s > 0 ? s + (s == 1 ? " second" : " seconds") : "";
		return dDisplay + hDisplay + mDisplay + sDisplay;
	}
}

customElements.define('date-picker', DateRangePicker);

export default DateRangePicker;