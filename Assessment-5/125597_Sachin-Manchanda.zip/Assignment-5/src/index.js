import './counter';

const counter = document.querySelector('x-counter');
counter.addEventListener('valueChange', v => console.log(v));