const template = document.createElement('template');
template.innerHTML = `
    <style>
        .temp-conv{
            width: 600px;
            height:300px;
            margin: 50px auto;
            background-color: #eee;
            padding:30px;
        }
        .form-group, .equal{
            float:left;
            margin-right:10px;
        }
        .equal{
            font-size:26px;
        }
        .clearfix{
            clear:both;
        }
    </style>
    <div class="temp-conv">
        <h3>Temperature</h3> 
        <div class="form-group">
            <label for="fahrenheit">Fahrenheit</label>
            <input type="text" class="form-control" id="fahrenheit" placeholder="°F" />
        </div>
        <div class="equal">=</div>
        <div class="form-group">
            <label for="celcius">Celcius</label>
            <input type="text" class="form-control" id="celcius" placeholder="°C" />
        </div>
        <div class="clearfix"></div>
    </div>
`
class tempConv extends HTMLElement {

    constructor() {
        super();
        this.root = this.attachShadow({ mode: 'closed' })
        this.root.appendChild(template.content.cloneNode(true))
        this.fahrenheitInput = this.root.querySelector('#fahrenheit');
        this.celciusInput = this.root.querySelector('#celcius');

        this.fahrenheitInput.addEventListener('keyup', e => {
            let fVal = isNaN(e.target.value) ? "" : e.target.value;
            let cVal = fVal ? this.convertFToC(e.target.value) : "";
            this.celciusInput.value = cVal;
        });

        this.celciusInput.addEventListener('keyup', e => {
            let cVal = isNaN(e.target.value) ? "" : e.target.value;
            let fVal = cVal ? this.convertCToF(e.target.value) : "";
            this.fahrenheitInput.value = fVal;
        })
    }

    convertFToC(fval) {
        return (fval - 32) * 5 / 9;
    }

    convertCToF(cval) {
        return (cval * 9 / 5 + 32)
    }

}


customElements.define('temp-conv', tempConv);