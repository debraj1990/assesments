class Tooltip extends HTMLElement {
  constructor() {
    super();
    this.tooltipContainer;
    this.attachShadow({mode: 'open'});
    this.shadowRoot.innerHTML = `
    <style>
      div {
        border: 2px solid grey;
        color: black;
        background: white;
        position: absolute;
        z-index: 1;
        top: 2rem;
        padding: 1rem;
      }
      .icon {
        background: grey;
        padding: .25rem .5rem;
        color: white;
        font-weight: bold;
        cursor: pointer;
      }
    </style>
    <slot></slot><span class="icon">?</span>
    `;
  }

  connectedCallback() {
    this.tooltipContent = this.getAttribute('content');
    const icon = this.shadowRoot.querySelector('span');
    icon.addEventListener('mouseenter', this.showTooltip.bind(this));
    icon.addEventListener('mouseleave', this.hideTooltip.bind(this));
    this.shadowRoot.appendChild(icon);
  }

  showTooltip() {
    this.tooltipContainer = document.createElement('div');
    this.tooltipContainer.textContent = this.tooltipContent;
    this.shadowRoot.appendChild(this.tooltipContainer);
  }

  hideTooltip() {
    this.shadowRoot.removeChild(this.tooltipContainer);
  }
}

customElements.define('xt-tooltip', Tooltip);