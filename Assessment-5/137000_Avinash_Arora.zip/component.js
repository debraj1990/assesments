const component = document.createElement('template');
component.innerHTML = `
  <div id="container">
    <p class="timer-display">
        <span id="timer">0</span> seconds
    </p>
    <button id="startBtn">Start Timer</button>
    <button id="stopBtn">Stop Counter</button>
  </div>`

class CustomTimer extends HTMLElement {
  constructor() {
    super();
    this.elapsedSeconds = 0;

    this.root = this.attachShadow({ mode: 'closed' })
    this.root.appendChild(component.content.cloneNode(true));

    this.startBtn = this.root.querySelector('#startBtn');
    this.stopBtn = this.root.querySelector('#stopBtn');

    this.startBtn.addEventListener("click", this.startTimer.bind(this));
    this.stopBtn.addEventListener("click", this.stopTimer.bind(this));
  }
  connectedCallback() {
    this.startTimer();
  }

  disconnectedCallback() {
    this.stopTimer();
  }

  startTimer() {
    const timerDisplay = this.root.getElementById("timer");

    this.timer = setInterval(() => {
      this.elapsedSeconds++;
      timerDisplay.innerHTML = this.elapsedSeconds;
    }, 1000);
  }
  stopTimer() {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}
customElements.define('my-timer', CustomTimer);
