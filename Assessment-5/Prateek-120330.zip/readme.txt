Facing some issue with HTMLWebpackPlugin in Webpack. I tried all sorts of ways to make it work but keeps getting one error. Entrypoint undefined = index.html

Even not able to run the code committed by @Naga in Repo. Had to merge in .html file.