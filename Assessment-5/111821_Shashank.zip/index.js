
// Create a class for the element
class WordCount extends HTMLParagraphElement {
    constructor() {
        // Always call super first in constructor
        super();

        // count words in element's parent element
        const wcParent = this.parentNode;

        let prependText = this.getAttribute('prepend');

        let countWords = (node) => {
            const text = node.innerText || node.textContent;
            return text.split(/\s+/g).length;
        }

        const count = `${countWords(wcParent)}`;

        // Create a shadow root
        const shadow = this.attachShadow({ mode: 'open' });

        // Custom event
        this.checkEvent = new CustomEvent("check", {
            bubbles: true,
            cancelable: false,
        });

        // Create text node and add word count to it
        const text = document.createElement('span');
        text.setAttribute('class', 'word-counter');
        text.textContent = prependText + ' ' + count;

        // Append it to the shadow root
        shadow.appendChild(text);

        // Custom styling
        let style = document.createElement('style');
        style.textContent = `.word-counter {
                font: italic small-caps normal 18px/150% Arial, Helvetica, sans-serif;
                color: #f0f;
            `;
        shadow.appendChild(style);
    }
    connectedCallback() {
        // Event listner
        this.shadowRoot.addEventListener("click", function (e) {
            console.log(' listend to click event ', e);

        });
    }
}

// Define the new element
customElements.define('word-count', WordCount, { extends: 'p' });
