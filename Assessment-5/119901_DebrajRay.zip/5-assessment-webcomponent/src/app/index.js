/*
You Invent Your Own Component

Write any self-contained web-component / custom Element 
based on w3c specification APIs which can be re-used across web-pages or applications

	Private scoped CSS & Javascript behav
	Component should take properties and emit events


Imp-note:

No React.js or any other third-party’s libray to use

*/

const template = document.createElement('template');
template.innerHTML = `
    <style>
        .distance-converter fieldset{
            width: 40%;
            background-color: #eee;
        }
        .distance-converter input[type=text]{
            width: 200px;
        }
        .form-group, .equal{
            float:left;
            margin-right:10px;
        }
        .equal{
            font-size:24px;
        }
    </style>
    <div class="distance-converter">
        <fieldset class="form-group">
            <legend>
            <label for="unit1type">Select a distance/length Unit</label>
                <select id="unit1type">
                    <option value="mile">Mile</option>
                    <option value="km">Kilometer</option>
                </select>
            </legend>
            <input type="text" class="form-control" id="unit1value" unit1type="mile" placeholder="Enter Distance in selected unit" />
        </fieldset>
        <div class="equal">is equivalent to</div>
        <fieldset class="form-group">
            <legend>
            <label for="unit2type">Select a distance/length Unit</label>
                <select id="unit2type">
                <option value="km">Kilometer</option>
                    <option value="mile">Mile</option>
                </select>
            </legend>
            <input type="text" class="form-control" id="unit2value" unit2type="km" placeholder="Enter Distance in selected unit" />
        </fieldset>
    </div>
`
class DistanceConverter extends HTMLElement {

    constructor() {
        super();
        this.root = this.attachShadow({ mode: 'closed' })
        this.root.appendChild(template.content.cloneNode(true))
        this.unit1type = this.root.querySelector('#unit1type');
        this.unit2type = this.root.querySelector('#unit2type');
        this.unit1value = this.root.querySelector('#unit1value');
        this.unit2value = this.root.querySelector('#unit2value');

        this.unit1type.addEventListener('change', e => {
            let unit1typeSelected = e.target.value;
            let unit2typeSelected = this.unit2value.getAttribute('unit2type');
            this.unit1value.setAttribute('unit1type', unit1typeSelected);
            let unit2val = unit1typeSelected === unit2typeSelected ? this.unit1value.value : ((unit1typeSelected === 'mile' && unit2typeSelected === 'km') ? this.convertBigToSmall(this.unit1value.value, 1.609) : this.convertSmallToBig(this.unit1value.value, 1.609));
            this.unit2value.value = unit2val;
        });

        this.unit2type.addEventListener('change', e => {
            let unit2typeSelected = e.target.value;
            let unit1typeSelected = this.unit1value.getAttribute('unit1type');
            this.unit2value.setAttribute('unit2type', unit2typeSelected);
            let unit1val = unit1typeSelected === unit2typeSelected ? this.unit2value.value : ((unit2typeSelected === 'mile' && unit1typeSelected === 'km') ? this.convertBigToSmall(this.unit2value.value, 1.609) : this.convertSmallToBig(this.unit2value.value, 1.609));
            this.unit1value.value = unit1val;
        });

        this.unit1value.addEventListener('keyup', e => {
            let unit1typeSelected = this.unit1value.getAttribute('unit1type');
            let unit2typeSelected = this.unit2value.getAttribute('unit2type');
            let unit2val = unit1typeSelected === unit2typeSelected ? e.target.value : ((unit1typeSelected === 'mile' && unit2typeSelected === 'km') ? this.convertBigToSmall(e.target.value, 1.609) : this.convertSmallToBig(e.target.value, 1.609));
            this.unit2value.value = unit2val;
        });

        this.unit2value.addEventListener('keyup', e => {
            let unit1typeSelected = this.unit1value.getAttribute('unit1type');
            let unit2typeSelected = this.unit2value.getAttribute('unit2type');
            let unit1val = unit1typeSelected === unit2typeSelected ? e.target.value : ((unit2typeSelected === 'mile' && unit1typeSelected === 'km') ? this.convertBigToSmall(e.target.value, 1.609) : this.convertSmallToBig(e.target.value, 1.609));
            this.unit1value.value = unit1val;
        })
    }

    convertBigToSmall(bigUnitVal, conversionFactor) {
        return (bigUnitVal * conversionFactor);
    }

    convertSmallToBig(smallUnitVal, conversionFactor) {
        return (smallUnitVal / conversionFactor);
    }

}


customElements.define('distance-converter', DistanceConverter);