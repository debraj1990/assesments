export const dataJson = 
[
  {
    "title": "Java",
    "detail": "Programming language for backend"
  },
  {
    "title": "JS",
    "detail": "Programming language for frontend"
  }
];