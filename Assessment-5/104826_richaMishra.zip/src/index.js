// Date Range component
const DataJSON = require('./data');
const component = document.createElement('template');
component.innerHTML = `
	<style>
	.tab-sect{
		padding: 10px 0px 0px 10px;
	}
	.tab-sect ul{
		margin:0px;
		padding: 0px;
	}
	.tab-sect ul li {
		list-style: none;
		display: inline-block;
		width: 49%;
		border: 1px solid #333;
		border-left:none;
	}
	.tab-sect ul li.active {
		border-bottom : none;
	}
	.tab-sect ul li:first-child {
		border-left : 1px solid #333;
	}
	.tab-sect div.detail-sect {
		border: 1px solid #333;
		border-top: none;
		padding: 50px;
	}
	.tab-sect div.detail-sect div {
		display:none;
	}
	.tab-sect div.detail-sect div.show {
		display: block;
	}
	</style>
	<div class="tab-sect">
		<ul class="top-sect">
		</ul>
		<div class="detail-sect">
		</div>
	</div>
`
class TabSectionBuilder extends HTMLElement {
	constructor() {
		super();
		this.root = this.attachShadow({ mode: 'closed' })
		this.root.appendChild(component.content.cloneNode(true))
			let tabTitle = document.createElement('li');
			this.tabTopElement = this.root.querySelector('.tab-sect .top-sect');
		this.detailSectElement = this.root.querySelector('.tab-sect .detail-sect');
		const DataVal = DataJSON.dataJson;
		for( let [index,val] of DataVal.entries()){
			let tabTitle = document.createElement('li');
			tabTitle.id = 'tabBox-'+ index;
			let tabDesc = document.createElement('div');
			tabDesc.id = 'tabDesc-'+ index;
			tabTitle.innerHTML = val.title;
			tabDesc.innerHTML = val.detail;
			tabTitle.addEventListener('click', e => {this.tabClick(e)
			});
			this.tabTopElement.appendChild(tabTitle);
			this.detailSectElement.appendChild(tabDesc);
		}
		this.root.querySelector('.tab-sect .top-sect #tabBox-0').classList.add('active');
		this.root.querySelector('.tab-sect .detail-sect #tabDesc-0').classList.add('show');

	}
	tabClick(e) {
		let detailSect = this.root.querySelectorAll('.tab-sect .detail-sect div');
		let tabList = this.root.querySelectorAll('.tab-sect .top-sect li');
		tabList.forEach(element => {
			element.classList.remove('active');
		});		
		detailSect.forEach(element => {
			element.classList.remove('show');
		});
		e.currentTarget.classList.add('active');
		let currentActiveIndex = e.currentTarget.id.split('-')[1];
		let currentActiveId = 'tabDesc-' + currentActiveIndex;
		this.root.querySelector('#'+currentActiveId).classList.add('show');
	}
}

customElements.define('tab-section', TabSectionBuilder);

export default TabSectionBuilder;