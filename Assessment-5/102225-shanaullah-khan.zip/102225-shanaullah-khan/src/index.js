
import 'bootstrap/dist/css/bootstrap.css';

console.log("-index.js-");


// Template
const template = document.createElement('template');
template.innerHTML = `

    <style>
    .btn-success {
      color: #fff;
      background-color: #5cb85c;
      border-color: #4cae4c;
    }
    .btn-primary {
  color: #fff;
  background-color: #337ab7;
  border-color: #2e6da4;
}
    </style>

    Enter to add/remove todo: &nbsp;&nbsp; <input name="todo" id="todo" autocomplete="off" />
    <br><br>
    <div>
        <button class="btn btn-primary add-todo">Add Todo</button>
        <button class="btn btn-success remove-todo">Remove Todo</button>
    </div>
<br>
    <br>
    <ul id="todoList">
    </ul>
`

// Web compoennnt
class TodoApp extends HTMLElement {

    static get observedAttributes() {
        return ['value']
    }

    constructor() {
        super()

        this._value = "Please enter todos";
        this.todos = [];
        this.root = this.attachShadow({ mode: 'closed' })

        this.root.appendChild(template.content.cloneNode(true))

        this.todoElement = this.root.querySelector('#todo');
        this.incrementBtn = this.root.querySelectorAll('button')[0];
        this.decrementBtn = this.root.querySelectorAll('button')[1];
        this.todoList = this.root.querySelector('#todoList');


        this.incrementBtn.addEventListener('click', e => {
          if(this.todoElement.value){
            this.todos.push(this.todoElement.value);
          }
            this.renderTodo(this.todos);
        })

        this.decrementBtn.addEventListener('click', e => {
          if(this.todoElement.value){
            this.todos.push(this.todoElement.value)
          }
          this.todos = this.todos.filter( (element) => element !== this.todoElement.value );

          this.renderTodo(this.todos);
        })

        this.todoElement.addEventListener("keyup", e => {
          if (e.key === "Enter") {
            if(this.todoElement.value){
              this.todos.push(this.todoElement.value);
            }
              this.renderTodo(this.todos);
          }
      });

    }

    renderTodo(todos){
      let list = this.todos.map((element) => `<li> ${element} </li>`);
      this.todoList.innerHTML = list.join('');
    }

    set value(value) {
        this.todoList.innerHTML = value;
        this.dispatchEvent(new CustomEvent('valueChange', { detail: this._value }))
    }

    attributeChangedCallback(attrName, oldValue, newValue) {
        if (attrName === 'value') {
            this.todoList.innerHTML = this._value;
        }
    }
}

customElements.define('todo-app', TodoApp)


var todoApp = document.querySelector('todo-app');
todoApp.addEventListener('valueChange', e => {
    console.log(e.detail);
})
