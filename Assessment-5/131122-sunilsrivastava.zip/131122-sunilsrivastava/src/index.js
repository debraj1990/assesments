import "bootstrap/dist/css/bootstrap.css";
import "./style.css";

const templateGreet = document.createElement("template");
templateGreet.innerHTML = `
    <style>
        #greetMessage:not(:empty){
            padding:20px;
            margin:10px 0 20px;
            background-color:#DFDFDF;
            border-radius: 4px;
        }
        button{
            background: black;
            padding: 10px;
            border: none;
            cursor:pointer;
            color: #FFFFFF;
            border-radius: 4px;
        }
    </style>
    <div>

        <p id="greetMessage"></p>
        <button id="showbtn">Show greeting</button>
        <button id="hidebtn">Hide greeting</button>
    </div>
`;

class Greet extends HTMLElement {
  static get observedAttributes() {
    return ["message"];
  }

  constructor() {
    super();

    this._message = "bjhj";

    this.root = this.attachShadow({ mode: "closed" });

    this.root.appendChild(templateGreet.content.cloneNode(true));

    this.greetMessage = this.root.getElementById("greetMessage");
    this.showBtn = this.root.getElementById("showbtn");
    this.hidebtn = this.root.getElementById("hidebtn");
    this.greetMessage.style.display = "none";
    this.hidebtn.style.display = "none";

    this.showBtn.addEventListener("click", e => {
      this.greetMessage.style.display = "block";
      this.hidebtn.style.display = "block";
      this.showBtn.style.display = "none";
    });

    this.hidebtn.addEventListener("click", e => {
      this.greetMessage.style.display = "none";
      this.showBtn.style.display = "block";
      this.hidebtn.style.display = "none";
    });
  }

  attributeChangedCallback(attrName, oldValue, newValue) {
    if (attrName === "message") {
      this._message = newValue;
      this.greetMessage.innerText = this._message;
    }
  }
}

customElements.define("greet-me", Greet);
