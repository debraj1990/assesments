var localDb  = require('../db/localDb');
var todos = localDb.todos;

exports.create = (req, res) => {
	const { title, completed } = req.body;
	const userId = req.params.userid;
	todos.insert({
		id: Date.now().toString(),
		title,
		completed,
		userId,
	});
	res.json(todos.data)
};

exports.get = (req, res)=>{
	const todoList = todos.find({userId: req.params.userid});
	res.send(todoList);
}

exports.getById = (req, res) => {
	const { userid, id } = req.params;
	const todo = todos.findOne({ "id": id });
	res.json(todo);
}

exports.editById = (req, res) => {
	const { userid, id } = req.params;
	const { title, completed } = req.body;
	todos
		.chain()
		.find({ "userId": userid, "id": id})
		.update(obj => {
			obj.title = title || obj.title;
			obj.completed = completed || obj.completed;
		});
	res.status(201).send();
}

exports.deleteById = (req, res) => {
	const { userid, id } = req.params;
	todos.chain().find({ "userId": userid, "id": id }).remove();
	res.status(201);
}