var express = require('express');
var router = express.Router();
const todoController = require('../services/todo');

router
    .route('/:userid/todo/completeAll')
    .put(todoController.completeAll);

router
    .route('/:userid/todo/clearCompleted')
    .delete(todoController.clearCompleted);

router
    .route('/:userid/todo')
    .get(todoController.get)
    .post(todoController.create);

router
    .route('/:userid/todo/:filter')
    .get(todoController.get);

router
    .route('/:userid/todo/id/:id')
    .get(todoController.getById)
    .put(todoController.editById)
    .delete(todoController.deleteById);

router
    .route('/:userid/todo/id/:id/complete')
    .put(todoController.completeById);

module.exports = router;
