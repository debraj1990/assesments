var { todoItems } = require('../db/lokidb')


module.exports = {
	todoCreate: function (req, res, next) {
		const requestBody = req.body;
		const userId = req.params.user;
		const dateArray = requestBody.targetDate.split('/')
		todoItems.insert({
			id: Date.now(),
			title: requestBody.title,
			completed: requestBody.completed,
			targetDate_day: dateArray[1],
			targetDate_month: dateArray[0],
			targetDate_year: dateArray[2],
			userId
		});
		res.json(todoItems.data)
	},
	todoEdit: function (req, res, next) {
		// handle edit
		// handle complete
		const updateId = req.params.id;
		const userId = req.params.user;
		const requestBody = req.body;
		const bodyDate = requestBody.targetDate || "";
		const dateArray = (bodyDate != "") ? requestBody.targetDate.split('/') : "";
		const title = requestBody.title || "";
		if (dateArray != "" || title != "") {
			todoItems.chain().find({ "userId": userId, "id": parseInt(updateId) }).update(function (obj) {
				obj.title = requestBody.title || obj.title
				obj.targetDate_day = dateArray[1] || obj.targetDate_day
				obj.targetDate_month = dateArray[0] || obj.targetDate_month
				obj.targetDate_year = dateArray[2] || obj.targetDate_year
			})
		} else {
			todoItems.chain().find({ "userId": userId, "id": parseInt(updateId) }).update(function (obj) {
				obj.completed = (obj.completed == "completed") ? "active" : "completed"
			})
		}

		res.json(`Updated ITEM id ::::> ${updateId}`)
	},
	todoDelete: function (req, res, next) {
		const userId = req.params.user;
		const id = req.params.id;
		todoItems.chain().find({ "userId": userId, "id": parseInt(id) }).remove()
		res.json(`Deleted ITEM id ::::> ${id}`)
	},
	todoCompleteAll: function (req, res, next) {
		const userId = req.params.user;
		todoItems.chain().find({ "userId": userId }).update(function (obj) {
			obj.completed = "completed"
		})

		res.json(`Items UPDATED ::::> ${JSON.stringify(todoItems.data)}`)
	},
	todoClearCompleted: function (req, res, next) {
		const userId = req.params.user;
		todoItems.chain().find({ "userId": userId, "completed": "completed" }).remove()
		res.json("ACTION PERFORMED!!!")
	},
	todoGetBy: function (req, res, next) {
		const userId = req.params.user;
		const filters = req.query.type;
		const filterParam = req.query.param;
		switch (filters) {
			case "status": {
				res.json(todoItems.find({ "compelted": filterParam }))
				break;
			}
			case "active": {
				res.json(todoItems.find({ "compelted": "active" }))
				break;
			}
			case "date": {
				const dateArray = filterParam;
				res.json(todoItems.find({
					"targetDate_day": dateArray[1],
					"targetDate_month": dateArray[0],
					"targetDate_year": dateArray[2],
				}))
				break;
			}
			case "month": {
				res.json(todoItems.find({ "targetDate_month": filterParam }))
				break;
			}
			default: {
				res.json(todoItems.find({ "userId": userId }))
				break;
			}
		}
	}
};

