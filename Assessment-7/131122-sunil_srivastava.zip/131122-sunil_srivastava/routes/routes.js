const express = require('express');
const router = express.Router();

const controllers = require('./controllers');

const {add, search, searchWithId, update, remove } = controllers;

router
    .route('/:userid/todo')
    .get(search)
    .post(add);

router
    .route('/:userid/todo/:id')
    .get(searchWithId)
    .put(update)
    .delete(remove);

module.exports = router;