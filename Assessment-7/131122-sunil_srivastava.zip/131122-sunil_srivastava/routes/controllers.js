var localDb = require("../db/localDb");
var todos = localDb.todos;

exports.add = (req, res) => {
  const { title, completed } = req.body;
  const { user } = req.params;

  todos.insert({
    id: Date.now().toString(),
    title,
    completed,
    user
  });

  res.json(todos.data);
};

exports.search = (req, res) => {
  const todoList = todos.find({ user: req.params.user });
  res.send(todoList);
};

exports.searchWithId = (req, res) => {
  const { id } = req.params;
  const todo = todos.findOne({ id });
  res.json(todo);
};

exports.update = (req, res) => {
  const { user, id } = req.params;
  const { title, completed } = req.body;

  todos
    .chain()
    .find({ user, id })
    .update(obj => {
      obj.title = title || obj.title;
      obj.completed = completed || obj.completed;
    });

  res.status(201).send();
};

exports.remove = (req, res) => {
  const { user, id } = req.params;

  todos
    .chain()
    .find({ user, id })
    .remove();

  res.status(201);
};
