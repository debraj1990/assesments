var express = require('express');
var router = express.Router();
const todoController = require('./todoController');

router
    .route('/:userid/todo/completeAll')
    .put(todoController.completeAll);

router
    .route('/:userid/todo/clearCompleted')
    .delete(todoController.clearCompleted);

router
    .route('/:userid/todo')
    .get(todoController.get)
    .post(todoController.create);

router
    .route('/:userid/todo/:filter')
    .get(todoController.get);

router
    .route('/:userid/todo/:id')
    .get(todoController.getById)
    .put(todoController.editById)
    .delete(todoController.deleteById);

router
    .route('/:userid/todo/:id/complete')
    .put(todoController.completeById);

module.exports = router;
