var localDb  = require('../database/db');
var todos = localDb.todoApp;

const COMPLETED = 'completed';
const filters =  {
  ALL: 'all',
  COMPLETED,
  ACTIVE: 'active'
};

exports.create = (req, res) => {
	const { title, status } = req.body;
	const { userid:userId } = req.params;
	todos.insert({
		id: Date.now().toString(),
		title,
		status,
		userId,
	});
	res.json(todos.data)
};

exports.get = (req, res)=> {
  const { userid, filter = filters.ALL } = req.params;
  let todoList;
  if (filter === filters.ALL) {
    todoList = todos.find({ userId: userid });
  } else {
    todoList = todos.find({ "userId": userid, "status": filter });
  }

	res.send(todoList);
}

exports.getById = (req, res) => {
	const { userid, id } = req.params;
	const result = todos.findOne({ "id": id, "userId": userid });
	res.json(result);
}

exports.editById = (req, res) => {
	const { userid, id } = req.params;
	const { title, status } = req.body;
	todos
		.chain()
		.find({ "userId": userid, "id": id})
		.update(obj => {
			obj.title = title || obj.title;
			obj.status = status || obj.status;
		});
	res.status(201).send();
}

exports.completeById = (req, res) => {
	const { userid, id } = req.params;
  const result = todos.findOne({ "userId": userid, "id": id});
  result.status = COMPLETED;
  todos.update(result);
  res.json(result);
}

exports.deleteById = (req, res) => {
	const { userid, id } = req.params;
  const result = todos.chain().find({ "userId": userid, "id": id }).remove();
	res.status(201).send();
}

exports.completeAll = (req, res) => {
  const todoList = todos
    .chain()
    .find({userId: req.params.userid})
    .update(obj => {
      obj.status = COMPLETED
    });
    res.status(201).send();
}

exports.clearCompleted = (req, res) => {
  const { userid } = req.params;
  const todoList = todos.chain().find({ "userId": userid, "status": COMPLETED }).remove();
  res.status(201).send();
}
