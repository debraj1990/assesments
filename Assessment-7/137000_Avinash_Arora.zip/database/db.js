var loki = require('lokijs');

var db = new loki('./db/todo.json', {
	autosave: true,
	autoload: true,
	throttledSaves: true
});

exports.todoApp = db.addCollection('todoApp');
