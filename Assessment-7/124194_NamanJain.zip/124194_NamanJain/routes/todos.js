const express = require('express');
const router = express.Router();
const db = require('../db/db');

/**
 * To add new user
 */
router.post('/', (req, res) => {
  try{
    const id = db.addUser(req.body);
    res.json({
      status: 'SUCCESS',
      userAdded: id
    });
  } catch(e){
    res.json({
      status: 'ERROR',
      error: e.message
    })
  }
});

/**
 * To get all users
 */
router.get('/', (req, res) => {
  try{
    const users = db.getUsers();
    res.json({
      status: 'SUCCESS',
      data: users,
    });
  }catch(e){
    res.json({
      status: 'ERROR',
      data: e.message,
    });
  }
});

/**
 * To get all todos or based on filter query params
 */
router.get('/:userId/todos', (req, res) => {
  try {
    let todos;
    if(req.query.filter){
      todos = db.getTodos(req.params.userId, req.query.filter);
    }else{
      todos = db.getTodos(req.params.userId);
    }
    res.json({
      status: 'SUCCESS',
      data: todos
    });
  }catch(e){
    res.json({
      status: 'ERROR',
      data: e.message,
    });
  }
});

/**
 * To add new todo
 */
router.post('/:userId/todos', (req, res) => {
  try {
    const todoId = db.addTodo(req.params.userId, req.body);
    res.json({
      status: 'SUCCESS',
      todoAdded: todoId
    });
  }catch(e){
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

/**
 * To update existing todo
 */
router.put('/:userId/todos/:todoId', (req, res) => {
  try {
    const todoId = db.updateTodo(req.params.userId, req.params.todoId, req.body);
    res.json({
      status: 'SUCCESS',
      todoUpdated: todoId
    });
  }catch(e) {
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

/**
 * mark todo status as complete
 */
router.put('/:userId/todos/:todoId/complete', (req, res) => {
  try {
    const todos = db.completeTodo(req.params.userId, req.params.todoId);
    res.json({
      status: 'SUCCESS',
      data: todos
    });
  }catch(e) {
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

/**
 * mark all todos status as complete
 */
router.put('/:userId/todos/complete', (req, res) => {
  try {
    const todos = db.completeAllTodos(req.params.userId);
    res.json({
      status: 'SUCCESS',
      data: todos
    });
  }catch(e) {
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

/**
 * Delete a todo
 */
router.delete('/:userId/todos/:todoId', (req, res) => {
  try {
    const todoId = db.deleteTodo(req.params.userId, req.params.todoId);
    res.json({
      status: 'SUCCESS',
      todoDeleted: todoId
    });
  }catch(e) {
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

/**
 * Delete todos based on filter query param
 */
router.delete('/:userId/todos', (req, res) => {
  if(!req.query.filter){
    res.sendStatus(405);
  }
  try {
    db.deleteTodo(req.params.userId);
    res.json({
      status: 'SUCCESS',
    });
  }catch(e) {
    res.json({
      status: 'ERROR',
      data: e.message
    });
  }
});

module.exports = router;
