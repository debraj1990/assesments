module.exports = {
  ACTIVE: 'active',
  COMPLETED: 'completed',
  ALL: 'all'
}
