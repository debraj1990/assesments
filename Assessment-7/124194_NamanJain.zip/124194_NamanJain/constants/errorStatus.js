module.exports = {
  'EC400': 'Required params are missing',
  'EC404': 'Requested resource not found'
}
