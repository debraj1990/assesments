function User(user) {
  this.id = this.getNextId();
  this.name = user.name;
  this.email = user.email || '';
  this.todos = user.todos || [];

  this.getId = function(){
    return this.id;
  }
}
User.idCounter = 0;

User.prototype.getNextId = function(){
  return ++User.idCounter + '';
}
module.exports = User;
