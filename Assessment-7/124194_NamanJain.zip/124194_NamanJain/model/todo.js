const constants = require('../constants/todoStatus');

function Todo(todo) {
  this.id = this.getNextId();
  this.title = todo.title;
  this.status = todo.status || constants.ACTIVE;
  this.date = todo.date || new Date().toDateString();

  this.getId = function(){
    return this.id;
  }
}

Todo.idCounter = 0;

Todo.prototype.getNextId = function(){
  return ++Todo.idCounter + '';
}

module.exports = Todo;
