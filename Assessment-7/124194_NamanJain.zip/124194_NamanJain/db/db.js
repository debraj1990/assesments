const Loki = require('lokijs');
const db = new Loki('./user.json', {
  autosave: true,
	autoload: true,
  autosaveInterval: 1000,
});
const User = require('../model/user');
const Todo = require('../model/todo');
const errorMessages = require('../constants/errorStatus');
const todoStatus = require('../constants/todoStatus');
const users = db.addCollection('users');

/**
 * add a new user
 * @param {object} user
 */
function addUser(user){
    if(typeof user !== 'object'){
      throw new TypeError(errorMessages['EC400']);
    }
    const newUser = new User(user);
    users.insert(newUser);
    return newUser.getId();
}

/**
 * get all users
 */
function getUsers(){
  return users.data;
}

/**
 * add a new todo
 * @param {string} userId
 * @param {object} todo
 */
function addTodo(userId, todo) {
  if(!userId || typeof todo !== 'object'){
    throw new TypeError(errorMessages['EC400']);
  }
  const newTodo = new Todo(todo);
  const requiredUser = users.chain().find({
    id: userId
  });
  console.log('requiredUser', requiredUser, userId);
  const requiredUserData = requiredUser.data();
  console.log('requiredUserData', requiredUserData);
  if(requiredUserData instanceof Array && requiredUserData.length === 1){
    requiredUser.update(user => {
      user.todos.push(newTodo);
    });
    return requiredUser.data()[0].todos;
  }
  throw new TypeError(errorMessages['EC404']);
}

/**
 * update an existing todo
 * @param {string} userId
 * @param {string} todoId
 * @param {object} updatedTodo
 */
function updateTodo(userId, todoId, updatedTodo) {
  if(!userId || typeof updatedTodo !== 'object' ){
    throw new TypeError(errorMessages['EC400']);
  }
  const user = users.chain().find({
    id:userId
  });
  const userData = user.data();
  if(userData instanceof Array && userData.length === 1){
    const newTodos = userData[0].todos.map(t => {
      if(todoId){
        if(t.id === todoId){
          return Object.assign({}, t, updatedTodo);
        }
        return t;
      }
      return Object.assign({}, t, updatedTodo);
    });
    user.update(user => {
      user.todos = newTodos;
    });
    return newTodos;
  }
  throw new TypeError(errorMessages['EC404']);
}

/**
 * delete a todo
 * @param {string} userId
 * @param {string} todoId
 */
function deleteTodo(userId, todoId){
  if(!userId){
    throw new TypeError(errorMessages['EC400']);
  }
  const user = users.chain().find({
    id:userId
  });
  const userData = user.data();
  if(userData instanceof Array && userData.length === 1){
    const newTodos = userData[0].todos.filter(t => {
      if(!todoId){
        return t.status !== todoStatus.COMPLETED;
      }
      return t.id !== todoId;
    });
    user.update(user => {
      user.todos = newTodos;
    });
    return newTodos;
  }
  throw new TypeError(errorMessages['EC404']);
}

/**
 * get todos based on filters
 * @param {string} userId
 * @param {string} filter
 */
function getTodos(userId, filter = todoStatus.ALL) {
  if(!userId){
    throw new TypeError(errorMessages['EC400']);
  }
  const user = users.chain().find({
    id: userId
  }, true).data();
  if(user instanceof Array && user.length === 1){
    return user[0].todos.filter(t => {
      const daysDiff = Math.abs(new Date().getTime() - new Date(t.date).getTime());
      switch(filter){
        case "active":
        case "completed":
          return t.status === filter;
        case 'date':
          return daysDiff < 1;
        case 'week':
          return daysDiff < 7;
        case 'month':
          return daysDiff < 30;
        default:
          return true;
      }
    })
  }
  throw new TypeError(errorMessages['EC404']);
}

/**
 * set todo status to complete
 * @param {string} userId
 * @param {string} todoId
 */
function completeTodo(userId, todoId){
  return updateTodo(userId, todoId, {
    status: todoStatus.COMPLETED
  });
}

/**
 * complete all user's todo
 * @param {string} userId
 */
function completeAllTodos(userId) {
  return updateTodo(userId, '', {
    status: todoStatus.COMPLETED
  });
}

/**
 * remove completed todo
 * @param {string} userId
 */
function clearCompleted(userId){
  return deleteTodo(userId);
}

module.exports = {
  addUser,
  getUsers,
  addTodo,
  updateTodo,
  deleteTodo,
  completeTodo,
  completeAllTodos,
  clearCompleted,
  getTodos,
}
