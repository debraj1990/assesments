const express = require('express');
const router = express.Router();
const todoController = require('./controller');

router
    .route('/:userid/todo')
    .get(todoController.get)
    .post(todoController.create);

router
    .route('/:userid/todo/:id')
    .get(todoController.getById)
    .put(todoController.editById)
    .delete(todoController.deleteById);

module.exports = router;