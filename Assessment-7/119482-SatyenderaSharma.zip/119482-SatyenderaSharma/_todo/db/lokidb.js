
var loki = require('lokijs');

var db = new loki('./db/todo.json', { autosave: true, autoload: true, throttledSaves: true });


var todoItems = db.addCollection('todos');



module.exports = { todoItems };