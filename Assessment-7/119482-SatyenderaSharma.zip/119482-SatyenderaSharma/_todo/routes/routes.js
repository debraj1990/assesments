var {todoCreate, todoEdit, todoDelete, todoCompleteAll, todoClearCompleted, todoGetBy} = require('./todo');

module.exports = function(app, db) {
    

    /* TODO REST API / Controllers*/
    app.post('/todo/:user', todoCreate); //For creating Todo
    app.patch('/todo/:user/:id', todoEdit); //For editing Todo & completing todo
    app.post('/todos/:user/completeall', todoCompleteAll); //For complete all
    app.delete('/todos/:user/clearcompleted', todoClearCompleted); //For deleting completed items
    app.delete('/todo/:user/:id', todoDelete); //For Deleting single todo item
    app.get('/todos/:user/filters', todoGetBy); // for fetching todo with filters
};