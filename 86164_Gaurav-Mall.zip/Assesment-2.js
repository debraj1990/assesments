
// Ex-1:  Build your House
/* 
->	door should not tightly coupled with listeners
->	we can add/remove listener at any time
->	if we add/remove listenr , which should not affect out system
->	door must pass door-event to all listeners, and door-event should contains following properties

DoorEvent
-	type ( open | close )
-	floorNum
-	doorNum

:::::::::::::::::OBSERVER PATTERN:::::::::::::::
*/
document.body.innerHTML += `<h1>ASSESMENT 2</h1>`;

class Door {
    constructor(doorName) {
        this._observers = [];
        this._doorName = doorName;
    }

    subscribe(observer) {
        this._observers.push(observer);
    }

    unsubscribe(observer) {
        this._observers = this._observers.filter((obs) => {
            (observer == obs) && console.warn(`unsubscribing ${observer.name}`)
            return (observer !== obs)
        });
    }

    setState(change) {
        console.log(`::::: ${this._doorName} ${change} :::::`)
        this._observers.forEach(observer => {
            observer.update(change);
            console.log(`${observer.name}  state is currently ${observer.doorAfterEvent}`)
        });
    }
}

class Appliance {
    constructor(state) {
        this.doorAfterEvent = state;
        this.initialState = state;
        this.name = state;
    }

    update(change) {
        let state = this.doorAfterEvent;
        switch (change.toLowerCase()) {
            case 'open':
                this.doorAfterEvent = "on";
                break;
            case 'close':
                this.doorAfterEvent = "off";
                break;
            default:
                this.doorAfterEvent = "off";
        }
    }
}


const door1 = new Door("DOOR1")
const light1 = new Appliance("First Floor | => Light")
const ac1 = new Appliance("First Floor | => AC")
door1.subscribe(ac1)
door1.subscribe(light1)
door1.setState('open')
door1.setState('close')

const door2 = new Door("DOOR2")
const light2 = new Appliance("Second Floor | => Light1")
const light3 = new Appliance("Second Floor | => Light2")
const ac2 = new Appliance("Second Floor | => AC")
door2.subscribe(ac2)
door2.subscribe(light2)
door2.subscribe(light3)
door2.setState('open')
door2.setState('close')


door1.unsubscribe(light1);
door1.setState('open')

document.body.innerHTML += `<div>
<h2>Ex-1:  Build your House </h2>
<div>Open console</div>
</div>`