document.body.innerHTML += `<h1>ASSESMENT 1</h1>`;
// Ex-1: Non-unique Elements
/* 
nonUniqueElements([1, 2, 3, 1, 3]) == [1, 3, 1, 3]
nonUniqueElements([1, 2, 3, 4, 5]) == []
nonUniqueElements([5, 5, 5, 5, 5]) == [5, 5, 5, 5, 5]
nonUniqueElements([10, 9, 10, 10, 9, 8]) == [10, 9, 10, 10, 9]
*/
const nonUniqueElements = (array) => {
    array = array || []
    return JSON.stringify(array.filter(function (arrayItem) {
        return array.indexOf(arrayItem) !== array.lastIndexOf(arrayItem)
    }));
}

document.body.innerHTML += `<div>
<h2>Ex-1: Non-unique Elements</h2>
[1, 2, 3, 1, 3] ==> ${nonUniqueElements([1, 2, 3, 1, 3])}<br>
[1, 2, 3, 4, 5] ==> ${nonUniqueElements([1, 2, 3, 4, 5])}<br>
[5, 5, 5, 5, 5] ==> ${nonUniqueElements([5, 5, 5, 5, 5])}<br>
[10, 9, 10, 10, 9, 8] ==> ${nonUniqueElements([10, 9, 10, 10, 9, 8])}<br>
null ==> ${nonUniqueElements(null)}<br>
undefined ==> ${nonUniqueElements(undefined)}<br>
[] ==> ${nonUniqueElements([])}
</div>`;


// =======================================================================


// Ex-2: The Most Wanted Letter
/*
mostWanted("Hello World!") == "l"
mostWanted("How do you do?") == "o"
mostWanted("One") == "e"
mostWanted("Oops!") == "o"
mostWanted("AAaooo!!!!") == "a"
mostWanted("abe") == "a"
*/

const mostWanted = (str) => {
    str = str || ''
    const letterArr = [];
    const sortedArray = str.toLowerCase().split('').sort();
    //finding occurences
    const occurObj = sortedArray.reduce((accum, item) => {
        /[a-zA-Z]/.test(item) && (accum[item] ? accum[item]++ : accum[item] = 1)
        return accum
    }, {});
    //ready to sort
    for (var letter in occurObj) {
        letterArr.push([letter, occurObj[letter]])
    }
    //sort by values
    letterArr.sort(function (first, second) {
        return second[1] - first[1]
    });
    //finding letter and fallback
    const foundLetter = ((letterArr.length > 1) && (letterArr[0][1] > letterArr[1][1]) ? letterArr[0][0] : Object.keys(occurObj)[0]) || (Object.keys(occurObj)[0] || "NONE FOUND")
    return (JSON.stringify(foundLetter));
}

document.body.innerHTML += `<div>
<h2>Ex-2 The Most Wanted Letter</h2>
Hello World! ===>   ${mostWanted("Hello World!")}<br>
How do you do? ===>   ${mostWanted("How do you do?")}<br>
One ===>   ${mostWanted("One")}<br>
Oops! ===>   ${mostWanted("Oops!")}<br>
AAaooo!!!! ===>   ${mostWanted("AAaooo!!!!")}<br>
abe ===>   ${mostWanted("abe")}<br>
z ===>   ${mostWanted("z")}<br>
null ===> ${mostWanted(null)}<br>
undefined ===> ${mostWanted(undefined)}
</div>`;


// =======================================================================


// Ex-3: Appoint Vendor  
// (a) sould log before & after 
// (b) should calculate total time it took to execute
// (c) should catch error if any thrown

// USED :::::::REVEALING MODULE PATTERN::::::::::

const logger = (function () {
    //private variables
    let startTime = 0;
    let endTime = 0;
    let functionName = "";
    //private function
    const reportExecutionTime = (executionTime) => {
        console.log(`Total Execution Time for ${functionName} is : ${executionTime}s`);
    }
    //private function
    const executeFunction = (fn) => {
        try {
            fn()
        }
        catch (err) {
            console.error(`Oops!! Function ${functionName} thown error :: message is "${err}"`)
        }
    }
    //private function
    const endLogging = () => {
        endTime = new Date().getTime();
        const delta = (endTime - startTime) / 1000;
        console.log(`===> ending logging of ${functionName}`);
        reportExecutionTime(delta)
    }
    //public function
    const startLogging = (fnCall) => {
        functionName = fnCall.name
        console.log(`===> started logging of ${functionName}`);
        startTime = new Date().getTime();
        executeFunction(fnCall);
        endLogging();
    }

    return {
        start: startLogging
    };

})();


const dummyFunction1 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 1e6; i++) {
        randomize = (Math.floor(Math.random() * 5000) + 3000)
        output += (i + randomize);
    }
    return output;
}

const errorFunction = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
        if (i > Math.pow(10, 5)) {
            throw "I cant handle big number"
        }
    }
    return output;
}

const dummyFunction2 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= 0xf4240; i++) {
        randomize = (Math.floor(Math.random() * 40000) + 3000)
        output += (i + randomize);
    }
    return output;
}

const dummyFunction3 = () => {
    let output = "";
    let randomize;
    for (var i = 1; i <= Math.pow(10, 6); i++) {
        randomize = (Math.floor(Math.random() * 40000) + 6000000)
        output += (i + randomize);
    }
    return output;
}

logger.start(dummyFunction1);
logger.start(errorFunction);
logger.start(dummyFunction2);
logger.start(dummyFunction3);
document.body.innerHTML += `<div>
<h2>Ex-3: Appoint Vendor  </h2>
<div>Open console</div>
</div>`;


// =======================================================================


// Ex-4: Music Player 
// •	SDNS => shortest duration next song
// •	LDNS => longest duration next song
// •	FINS => first in next song

// USED :::::::CONSTRUCTOR PATTERN::::::::::

const playList = [
    {id: 1, title: "SONG1", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 2, title: "SONG2", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 3, title: "SONG3", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 4, title: "SONG4", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 5, title: "SONG5", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 6, title: "SONG6", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 7, title: "SONG7", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 8, title: "SONG8", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 9, title: "SONG9", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 10, title: "SONG10", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 11, title: "SONG11", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 12, title: "SONG12", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 13, title: "SONG13", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 14, title: "SONG14", duration: +((Math.random() * 4) + 5).toFixed(2)},
    {id: 15, title: "SONG15", duration: +((Math.random() * 4) + 5).toFixed(2)}
]

class MusicPlayer {
    constructor(playlist = [], scheduling) {
        scheduling = scheduling.toLowerCase() || ""
        this._playlist = [...playlist]
        this._scheduling = scheduling
        this.nextSong()
        this._current = this.firstSong()
        this.setScheduling = (sch) => {
            sch = sch.toLowerCase() || ""
            this._scheduling = sch
            this.sortedDuration(sch)
        };
    }
    firstSong() {
        const currentIndex = this._playlist.indexOf(this._current)
        const nextIndex = ((currentIndex - 1) < 0) ? this._playlist.length : (currentIndex - 1)
        return this._playlist[nextIndex]
    }
    sortedDuration(which) {
        this._playlist.sort(function (first, second) {
            return (which === 'sdns') ? (first.duration - second.duration) :(second.duration - first.duration)
        });
        const currentIndex = this._playlist.indexOf(this._current)
        const nextIndex = ((currentIndex + 1) === this._playlist.length) ? 0 : (currentIndex + 1)
        return this._playlist[nextIndex]
    }
    exactNext() {
        this._playlist.sort(function (first, second) {
            return first.id - second.id
        });
        const currentIndex = this._playlist.indexOf(this._current)
        const nextIndex = ((currentIndex + 1) === this._playlist.length) ? 0 : (currentIndex + 1)
        return this._playlist[nextIndex]
    }
    nextSong() {
        switch (this._scheduling) {
            case "sdns":
                this._current =  this.sortedDuration(this._scheduling);
                break;
            case "ldns":
                this._current =  this.sortedDuration();
                break;
            default:
                this._current =  this.exactNext();
                break;
        }
        return this._current;
    }
}

myPlayer1 = new MusicPlayer(playList, 'SDNS');
console.log(`==============MY PLAYER 1 "SDNS"=================`);
console.log(myPlayer1._playlist);
myPlayer1.nextSong();
myPlayer1.nextSong();
myPlayer1.nextSong();
console.log(myPlayer1._current);

console.log(`==============MY PLAYER 3 "FINS"=================`);
myPlayer3 = new MusicPlayer(playList, 'FINS ');
console.log(myPlayer3._playlist);
myPlayer3.nextSong();
myPlayer3.nextSong();
console.log(myPlayer3._current);

console.log(`==============MY PLAYER 2 "LDNS"=================`);
myPlayer2 = new MusicPlayer(playList, 'LDNS');
console.log(myPlayer2._playlist);
myPlayer2.nextSong();
myPlayer2.nextSong();
console.log(myPlayer2._current);

document.body.innerHTML += `<div>
<h2>Ex-4: Music Player </h2>
<div>Open console</div>
</div>`;
