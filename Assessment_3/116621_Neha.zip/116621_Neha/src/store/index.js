import { createStore } from '../redux-lib/src';
import rootReducer from '../reducers/rootReducer'

let initialState = {
    products: [],
    cart: []
}

export default createStore(rootReducer, initialState);