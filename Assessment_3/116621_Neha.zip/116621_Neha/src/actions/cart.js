import { BUY } from '../constants'

const buy = (item) => {
    let products = [
        { id: 1, title: "Product1" },
        { id: 2, title: "Product2" }
    ]

    return { type: BUY, item }
}

export { buy }