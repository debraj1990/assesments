import { LOAD_PRODUCTS } from '../constants'

const loadProducts = () => {
    let products = [
        { id: 1, title: "Product1" },
        { id: 2, title: "Product2" }
    ]

    return { type: LOAD_PRODUCTS, products: products }
}

export { loadProducts }