import store from './store'
import { LOAD_PRODUCTS, BUY } from './constants'
import { loadProducts } from './actions/products'
import { buy } from './actions/cart'


store.subscribe(function () {
    let state = store.getState()
    console.log("=======Products========")
    console.log(state.products)
});

store.subscribe(function () {
    let state = store.getState()
    console.log("=======cart========")
    console.log(state.cart)
});

store.dispatch(loadProducts())

store.dispatch(buy({ id: 1, title: "Product1" }))

store.dispatch(loadProducts())