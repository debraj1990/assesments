const counter = (state = 0, action)=> {
	switch (action.type) {
		case 'INCREMENT_CNT':
			state = state + 1;
			break;
		case 'DECREMENT_CNT':
			state = state - 1;
			break
		default:
			state = state;
	}
	return state;
};

export default counter;