import {createStore, combineReducers} from './redux';
import countReducer from './countReducer';

let store = createStore(countReducer);
store.subscribe(() => {
	console.log(store.getState());
});
store.dispatch({type: 'INCREMENT_CNT'});
store.dispatch({type: 'INCREMENT_CNT'});
store.dispatch({type: 'DECREMENT_CNT'});