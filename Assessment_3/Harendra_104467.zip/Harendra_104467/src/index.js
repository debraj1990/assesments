import {createStore, combineReducers} from './redux';
const counter = function (state = 0, action) {
	switch (action.type) {
		case 'INCREMENT':
			state = state + 1;
			break;
		case 'DECREMENT':
			state = state - 1;
			break
		default:
			state;
	}
	return state;
};

let store = createStore(counter);
store.subscribe(() => {
	console.log(store.getState());
});
store.dispatch({type: 'INCREMENT'});
store.dispatch({type: 'INCREMENT'});
store.dispatch({type: 'INCREMENT'});
store.dispatch({type: 'DECREMENT'});

///----------------- Combine Reducer ------------//

const shoppingList = (state = [], action) => {
	switch(action.type){
		case 'ADD_ITEM':
			return state.concat(action.item);
		case 'REMOVE_ITEM':
			let index = action.index;
			return state.filter((key, i)=> i !== index);
		default:
			return state;
	}
}

let combineReducer = combineReducers({
	counter,
	shoppingList,
})
let combineStore = createStore(combineReducer);
combineStore.subscribe(() => {
	console.log(combineStore.getState());
});
combineStore.dispatch({type: 'ADD_ITEM', item: 'BANANA'});
combineStore.dispatch({type: 'ADD_ITEM', item: 'MANGO'});
combineStore.dispatch({type: 'REMOVE_ITEM', index: 1});
combineStore.dispatch({type: 'INCREMENT'});
combineStore.dispatch({type: 'DECREMENT'});
