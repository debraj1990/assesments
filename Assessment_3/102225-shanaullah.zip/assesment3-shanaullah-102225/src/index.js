const counterNode = document.getElementById('count');
		const todoDiv = document.getElementById('show-todo');
		const addCount = document.getElementById('add-counter');
		const reduceCount = document.getElementById('reduce-counter');


		const counterReducer = function (state = 0, action) {
			switch (action.type) {
				case 'ADD_COUNT':
					state = state + 1;
					break;
				case 'SUBTRACT_COUNT':
					state = state - 1;
					break
				default:
					state;
			}
			return state;
		};
		
		
		const todoList = (state = [], action) => {
			switch(action.type){
				case 'ADD_TODO':
					return state.concat(action.language);
				case 'REMOVE_TODO':
					let index = action.index;
					return state.filter((key, i)=> key !== action.language);
				default:
					return state;
			}
		};
		
		
		const rootReducer = combineReducers({
			count: counterReducer,
			todo: todoList
		});

		const store = createStore(rootReducer);
		
		
		/*=========================================================
		== SUNSCRIBERs
		=========================================================*/
		store.subscribe(() => {
			const state = store.getState();
			const count = state.count;
			counterNode.innerHTML = count;
		});
		
		store.subscribe(() => {
			//setTimeout(function(){
				const { todo } = store.getState();
				let todoHtml = todo.map( (item)=>{
				return `<li>${item}</li>`
			})
				
			todoDiv.innerHTML = todoHtml.join(' ');
				
			//},1000)
		});
		
		
		
		
		/*=========================================================
		== TODOs Action
		=========================================================*/
		addTodo = (lang) => {
			store.dispatch({type: 'ADD_TODO', language: lang});
		}
		
		removeTodo = (lang) => {
			store.dispatch({type: 'REMOVE_TODO', language: lang});
		}
		
		

		/*=========================================================
		== COUNT Action
		=========================================================*/
		const add = () => {
			store.dispatch({type: 'ADD_COUNT'});
		}


		const subtract = () => {
			store.dispatch({type: 'SUBTRACT_COUNT'});
		}

		

		/*=========================================================
		== COUNT BUTTON click handler
		=========================================================*/
		addCount.addEventListener('click', function () {
			add();
		})

		reduceCount.addEventListener('click', function () {
			subtract();
		})
		
		
		
		/*=========================================================
		== Add TODO Action Creator called to add todos
		=========================================================*/
		
		
		setTimeout(function () {
			addTodo('JavaScript');
			setTimeout(function () {
				addTodo('DOT Net');
				setTimeout(function () {
					addTodo('JAVA');

					setTimeout(function () {
						addTodo('NodeJs');
						
							setTimeout(function () {

								removeTodo('JAVA');

								setTimeout(function () {
									removeTodo('DOT Net');
								}, 2000)

							}, 1000)
						
					}, 1000)

				}, 1000)
			}, 1000)
		}, 1000)
		
		