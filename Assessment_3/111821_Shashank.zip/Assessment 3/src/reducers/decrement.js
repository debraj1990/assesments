/**
 * 
 * @param {Object} action 
 * @param {Object} state 
 */
export default function decrementReducer(action, state = {}) {
  switch (action.type) {
    case "DEC":
      return {
        num: state.num - 1
      };

      default:
      return state;
  }
}
