/**
 * 
 * @param {Object} action 
 * @param {Object} state 
 */

export default function incrementReducer(action, state = {}) {
  switch (action.type) {
    case "INC":
      return {
        num: state.num + 1
      };
      default:
      return state;
  }
}