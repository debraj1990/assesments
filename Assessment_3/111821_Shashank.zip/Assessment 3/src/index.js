

import {store } from './store';

console.log('--index.js--');

store.subscribe(()=>{
	let currentNum = store.getState().num;
	console.log("currentState ", currentNum);
})

let incAction = { type: 'INC' };
store.dispatch(incAction);

//setInterval(() => {
  // dispatch({ type: 'INC' });
  // console.log(getState());
//}, 1000);





