import { rootReducer } from '../reducers';

const initalState = {
  num: 0
}

/**
 * @description Creating store with getState, dispatch & subscribe methods
 * @param {function} rootReducer 
 * @param {Object} initalState 
 */
const createStore = (rootReducer, initalState) => {

  let state = initalState;
  let listeners = [];

  const getState = () => {
    return state;
  };;

  const dispatch = action => {

    state = rootReducer(state, action);
    listeners.forEach(listener => listener(state));
  };

  const subscribe = listener => {
    listeners.push(listener);
  };

  dispatch({});

  return { getState, dispatch, subscribe };
};

// store creation
const store = createStore(rootReducer, initalState);

export { store };