import { reducer } from '../reducers/reducers';

let state;
const getState = () => state;
const listeners = [];

const dispatch = action => {
  state = reducer(action, state);
  listeners.forEach(listener => listener())
};

const subscribe = (listener) => {
  listeners.push(listener)
  return () => {
    listeners.filter(lis => lis !== listener)
  }
};

dispatch({});

const reducers = () => reducer;

reducers(); //getting the reducers



export { getState, dispatch,  subscribe };