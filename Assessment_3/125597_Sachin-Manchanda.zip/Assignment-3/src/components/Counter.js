import React, { Component } from 'react';
import Store from '../store';
import 'bootstrap/dist/css/bootstrap.css'

class Counter extends Component {
    constructor(props) {
        super(props)
        this.store = new Store(); 
        this.state = this.store.dispatch({type: 'START'});   
    }
    
    increment = () => {
        this.store.dispatch({ type: 'INCREMENT' });
        this.setState(this.store.getState());
    };
    
    decrement = () => {
        this.store.dispatch({ type: 'DECREMENT' });
        this.setState(this.store.getState());
    };
    render() {
        return (
            <div className='jumbotron'>
                <h1>Current counter : {this.state.value}</h1>
                <button className='btn btn-primary' onClick={this.increment}>+</button>
                <button className='btn btn-danger' onClick={this.decrement}>-</button>
            </div>
        )
    }
}

export default Counter;