const reducer = (state = { value: 0 }, action) => {
    switch (action.type) {
        case 'INCREMENT':
            return { value: state.value + 1 };
        case 'DECREMENT':
            return { value: state.value - 1 };
        default:
            return state;
    }
}

const validateAction = action => {
    if (!action || typeof action !== 'object' || Array.isArray(action)) {
        throw new Error('Action must be an object!');
    }
    if (typeof action.type === 'undefined') {
        throw new Error('Action must have a type!');
    }
};

const store = () => {
    let state = undefined;
    return {
        dispatch: (action) => {
        validateAction(action)
            state = reducer(state, action);
            return state;
        },
        getState: () => state
    };
};

export default store;